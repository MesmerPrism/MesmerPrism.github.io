import { useEffect, useRef, useState } from 'react';
import { boundTarget, createSurfaceGesture, dialTarget, padTarget, positionPadTarget } from './spatial-control.mjs';
import './spatial-controls.css';

const display = value => Number.isFinite(value) ? `${Number(value.toFixed(1))}°` : '—';
export function PrecisionField({ label, value, limit, disabled, onChange, unit = '°' }) {
  const formatted = Number.isFinite(value) ? String(Number(value.toFixed(1))) : '';
  const [draft, setDraft] = useState(formatted);
  const dirty = useRef(false);
  useEffect(() => { if (!dirty.current || disabled) { dirty.current = false; setDraft(formatted); } }, [formatted, disabled]);
  const commit = () => {
    if (!dirty.current) return;
    dirty.current = false;
    const next = draft.trim() === '' ? null : boundTarget(Number(draft), limit);
    if (next !== null && !disabled) { setDraft(String(next)); onChange(next); } else setDraft(formatted);
  };
  return <label className="spatial-precision"><span>{label}</span><input aria-label={`${label} target ${unit === '°' ? 'angle' : 'position in millimetres'}`} title="Enter or leave the field to apply" type="number" step="0.1" min={-limit} max={limit} value={draft} disabled={disabled || limit === 0} onChange={event => { dirty.current = true; setDraft(event.target.value); }} onBlur={commit} onKeyDown={event => {
    if (event.key === 'Enter') { event.preventDefault(); commit(); }
    if (event.key === 'Escape') { event.preventDefault(); dirty.current = false; setDraft(formatted); }
  }} /><span>{unit}</span></label>;
}

// All spatial gestures share the existing command path. Captured
// gestures expire on Stop/epoch, gate, visibility or focus changes.
function useSurfaceGesture({ disabled, contextKey, onChange }, map, onStart) {
  const live = useRef(null), gesture = useRef(null);
  live.current = { disabled, contextKey, onChange, map, onStart };
  if (!gesture.current) gesture.current = createSurfaceGesture({
    getContext: () => ({ ...live.current, hidden: document.hidden }),
    mapTarget: (event, start) => live.current.map(event, start),
    onChange: target => live.current.onChange(target),
    onStart: event => live.current.onStart?.(event),
  });
  const { cancel, ...handlers } = gesture.current;
  useEffect(() => { cancel(); }, [disabled, contextKey]);
  useEffect(() => {
    const hidden = () => { if (document.hidden) cancel(); };
    document.addEventListener('visibilitychange', hidden); window.addEventListener('blur', cancel);
    return () => { cancel(); document.removeEventListener('visibilitychange', hidden); window.removeEventListener('blur', cancel); };
  }, []);
  return handlers;
}

export function CameraAimSurface({ values, limits = { yaw: 20, pitch: 15 }, disabled, onChange, contextKey, children, className = '', hidden = false }) {
  const handlers = useSurfaceGesture({ disabled, contextKey, onChange }, event => padTarget(event.clientX, event.clientY, event.currentTarget.getBoundingClientRect(), limits));
  return <div hidden={hidden} className={`camera-aim-surface ${className}${disabled ? ' is-disabled' : ''}`} role="group" aria-label="Camera turn and nod control" aria-disabled={disabled} tabIndex={disabled || hidden ? -1 : 0} title="Drag the camera view to turn and nod" {...handlers} onKeyDown={event => {
    if (event.target !== event.currentTarget || disabled || document.hidden) return;
    const changes = { ArrowLeft: ['yaw', 1], ArrowRight: ['yaw', -1], ArrowUp: ['pitch', -1], ArrowDown: ['pitch', 1] };
    if (changes[event.key]) { event.preventDefault(); const [axis, direction] = changes[event.key]; onChange({ [axis]: boundTarget(values[axis] + direction * (event.shiftKey ? 5 : 1), limits[axis]) }); }
    if (event.key === 'Home') { event.preventDefault(); onChange({ yaw: 0, pitch: 0 }); }
  }}>{children}</div>;
}

export function PositionPad({ values, measured = {}, limits = { y: 10, z: 10 }, disabled, onChange, contextKey }) {
  const position = target => ({ left: `${50 - ((boundTarget(target.y, limits.y) ?? 0) / (limits.y || 1)) * 43}%`, top: `${50 - ((boundTarget(target.z, limits.z) ?? 0) / (limits.z || 1)) * 36}%` });
  const handlers = useSurfaceGesture({ disabled, contextKey, onChange }, event => positionPadTarget(event.clientX, event.clientY, event.currentTarget.getBoundingClientRect(), limits));
  return <div className="spatial-position-pad-control"><h3>Shift head</h3>
    <div className={`spatial-pad spatial-position-pad${disabled ? ' is-disabled' : ''}`} tabIndex={disabled ? -1 : 0} role="group" aria-label="Head sideways and vertical position pad" aria-disabled={disabled} {...handlers} onKeyDown={event => {
      if (disabled || document.hidden) return;
      const changes = { ArrowLeft: ['y', 1], ArrowRight: ['y', -1], ArrowUp: ['z', 1], ArrowDown: ['z', -1] };
      if (changes[event.key]) { event.preventDefault(); const [axis, delta] = changes[event.key]; onChange({ [axis]: boundTarget(values[axis] + delta * (event.shiftKey ? 5 : 1), limits[axis]) }); }
      if (event.key === 'Home') { event.preventDefault(); onChange({ y: 0, z: 0 }); }
    }}>
      <span className="pad-label pad-left">Left</span><span className="pad-label pad-right">Right</span><span className="pad-label pad-up">Up</span><span className="pad-label pad-down">Down</span><span className="pad-cross pad-cross-x" /><span className="pad-cross pad-cross-y" />
      {Number.isFinite(measured.y) && Number.isFinite(measured.z) && <span className="pad-measured" style={position(measured)} />}
      <span className="pad-target" style={position(values)}><svg viewBox="0 0 40 30" aria-hidden="true"><rect x="2" y="2" width="36" height="26" rx="10" /><circle cx="13" cy="14" r="4" /><circle cx="27" cy="14" r="4" /></svg></span>
    </div><p className="spatial-measured">Measured sideways {Number.isFinite(measured.y) ? measured.y.toFixed(1) : '—'} mm · height {Number.isFinite(measured.z) ? measured.z.toFixed(1) : '—'} mm</p>
  </div>;
}

export function OrientationPad({ values, measured = {}, limits = { yaw: 20, pitch: 15 }, disabled, onChange, contextKey }) {
  const position = target => ({ x: 50 - (limits.yaw ? boundTarget(target.yaw, limits.yaw) / limits.yaw : 0) * 43,
    y: 50 + (limits.pitch ? boundTarget(target.pitch, limits.pitch) / limits.pitch : 0) * 36 });
  const requested = position(values), actual = position(measured);
  const handlers = useSurfaceGesture({ disabled, contextKey, onChange }, event => padTarget(event.clientX, event.clientY, event.currentTarget.getBoundingClientRect(), limits));
  const key = event => {
    if (disabled || document.hidden) return;
    const amount = event.shiftKey ? 5 : 1;
    const changes = { ArrowLeft: ['yaw', amount], ArrowRight: ['yaw', -amount], ArrowUp: ['pitch', -amount], ArrowDown: ['pitch', amount] };
    if (!disabled && changes[event.key]) { event.preventDefault(); const [axis, delta] = changes[event.key]; onChange({ [axis]: boundTarget(values[axis] + delta, limits[axis]) }); }
    if (!disabled && event.key === 'Home') { event.preventDefault(); onChange({ yaw: 0, pitch: 0 }); }
  };
  return <div className="spatial-pad-control">
    <h3>Look direction</h3><p className="spatial-help">Drag to turn and nod. Directions are Reachy’s own.</p>
    <div className={`spatial-pad${disabled ? ' is-disabled' : ''}`} tabIndex={disabled ? -1 : 0} role="group" aria-label="Head turn and nod pad. Arrow keys adjust one degree, Shift adjusts five, Home centres turn and nod." aria-disabled={disabled} onKeyDown={key} {...handlers}>
      <span className="pad-label pad-left">Left</span><span className="pad-label pad-right">Right</span><span className="pad-label pad-up">Up</span><span className="pad-label pad-down">Down</span>
      <span className="pad-cross pad-cross-x" /><span className="pad-cross pad-cross-y" />
      {Number.isFinite(measured.yaw) && Number.isFinite(measured.pitch) && <span className="pad-measured" style={{ left: `${actual.x}%`, top: `${actual.y}%` }} />}
      <span className="pad-target" style={{ left: `${requested.x}%`, top: `${requested.y}%` }}><svg viewBox="0 0 40 30" aria-hidden="true"><rect x="2" y="2" width="36" height="26" rx="10" /><circle cx="13" cy="14" r="4" /><circle cx="27" cy="14" r="4" /></svg></span>
    </div>
    <div className="spatial-fields"><PrecisionField label="Turn" value={values.yaw} limit={limits.yaw} disabled={disabled} onChange={yaw => onChange({ yaw })} /><PrecisionField label="Nod" value={values.pitch} limit={limits.pitch} disabled={disabled} onChange={pitch => onChange({ pitch })} /></div>
    <p className="spatial-measured">Measured: turn {display(measured.yaw)} · nod {display(measured.pitch)}</p>
  </div>;
}

export function AngleControl({ label, value, measured, limit = 90, disabled, onChange, contextKey, kind = 'tilt' }) {
  const selectable = boundTarget(value, limit) ?? 0;
  // Front-view roll and top-view yaw are counterclockwise for positive angles.
  const direction = kind === 'antenna' ? 1 : -1;
  const angle = direction * selectable;
  const arcLimit = Math.min(limit, 90) * Math.PI / 180;
  const arcX = 72 * Math.sin(arcLimit), arcY = 86 - 72 * Math.cos(arcLimit);
  const handlers = useSurfaceGesture({ disabled: disabled || limit === 0, contextKey, onChange }, (event, start) => {
    const raw = dialTarget(event.clientX, event.clientY, event.currentTarget.getBoundingClientRect(), 90);
    if (raw === null) return null;
    return boundTarget(start ? start.value + direction * (raw - start.angle) : direction * raw, limit);
  }, event => {
    // Grabbing the glyph starts at its held pose, without an off-centre jump.
    const angle = dialTarget(event.clientX, event.clientY, event.currentTarget.getBoundingClientRect(), 90);
    return event.target.closest?.('g') && angle !== null ? { value: selectable, angle } : null;
  });
  const key = event => {
    if (disabled || limit === 0 || document.hidden) return;
    const delta = event.key === 'ArrowUp' ? 1 : event.key === 'ArrowDown' ? -1 : event.key === 'ArrowRight' ? direction : event.key === 'ArrowLeft' ? -direction : 0;
    if (delta || event.key === 'Home') { event.preventDefault(); onChange(event.key === 'Home' ? 0 : boundTarget(selectable + delta * (event.shiftKey ? 5 : 1), limit)); }
  };
  return <div className="spatial-angle-control">
    <h3>{label}</h3>
    <svg className={`spatial-dial${disabled ? ' is-disabled' : ''}`} style={{ height: 'auto', aspectRatio: '180 / 110' }} viewBox="0 0 180 110" role="slider" tabIndex={disabled ? -1 : 0} aria-label={`${label} target angle`} aria-valuemin={-limit} aria-valuemax={limit} aria-valuenow={selectable} aria-valuetext={`${display(value)} requested; ${display(measured)} measured`} aria-disabled={disabled} onKeyDown={key} {...handlers}>
      <path d={`M${90 - arcX} ${arcY} A72 72 0 0 1 ${90 + arcX} ${arcY}`} className="spatial-arc" /><path d="M90 10v8" className="spatial-ticks" />
      {Number.isFinite(measured) && <path d="M90 86V20" className="spatial-feedback-line" transform={`rotate(${direction * (boundTarget(measured, limit) ?? 0)} 90 86)`} />}
      <g transform={`rotate(${angle} 90 86)`}>
        {kind === 'tilt' ? <><rect x="59" y="33" width="62" height="44" rx="15" className="spatial-robot-face" /><circle cx="76" cy="53" r="7" className="spatial-eye" /><circle cx="104" cy="53" r="7" className="spatial-eye" /></> : kind === 'body' ? <><ellipse cx="90" cy="64" rx="30" ry="22" className="spatial-robot-face" /><path d="M90 66V28m-7 9 7-9 7 9" className="spatial-arrow" /></> : <><path d="M90 86V22" className="spatial-antenna" /><circle cx="90" cy="22" r="9" className="spatial-knob" /></>}
      </g><text x="7" y="106">{direction < 0 ? '+' : '−'}{limit}°</text><text x="143" y="106">{direction < 0 ? '−' : '+'}{limit}°</text>
    </svg>
    <PrecisionField label={label} value={value} limit={limit} disabled={disabled} onChange={onChange} />
    <p className="spatial-measured">Measured {display(measured)}</p>
    {Number.isFinite(value) && Math.abs(value) > limit && <p className="spatial-help">Held target is outside the selectable range.</p>}
  </div>;
}
