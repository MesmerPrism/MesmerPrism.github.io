# Reachy Mini browser control

A standalone browser app for Reachy Mini camera, audio, antenna and head controls,
emotes, and measured state. It uses Reachy's existing daemon and JavaScript SDK.
This independent prototype includes an original schematic viewer and a simulation.

Source home: [MesmerPrism/reachy-mini-browser-control](https://github.com/MesmerPrism/reachy-mini-browser-control).
Software license: [MIT](LICENSE). See [third-party notices](THIRD_PARTY_NOTICES.md)
for dependency and asset licenses.

## Try the browser app

Open [mesmerprism.com/reachy-mini](https://mesmerprism.com/reachy-mini/) or the
[hardware-free demo](https://mesmerprism.com/reachy-mini/#demo). The hosted app
controls Wireless through the pinned SDK without a local Node bridge. Select
**Local network** for a direct same-network connection without an account or
download, or **Account access** for Pollen's Hugging Face connection service.
Local access requires a browser that permits local WebSockets. Camera and
microphone features require the relevant permissions. Account tokens remain
in tab memory; they are not saved in browser storage or downloads.

Hosted Wireless control admits exact daemon **1.10.0** and **1.11.0** with the
pinned SDK 1.8.0 and the same identity, freshness and no-startup-motion gates.
The Connect page shows separate network, compatibility, local/account access and
session checks. Local probes are explicit read-only actions; Bluetooth discoveries carry
their address and identity into Connect in page memory. The local bridge and
motor experiments retain their separate 1.10.0 qualification. Read the dated
[status and verification limits](docs/STATUS.md) and [local connection details](docs/LOCAL_CONNECTION.md) before connecting hardware.
Read [head response and settling](docs/HEAD_RESPONSE.md) for acknowledgement,
joint feedback and the unresolved yaw plateau.
The [reversible I-gain trial](docs/I_GAIN_TRANSACTION.md) records an I0/I1 probe on
motor 15. An attended I0/I1/I0 comparison reduced one upward following error but
worsened the final return under I1; restored I0 reproduced baseline behavior.
Whole-head tilt remained. I0 is retained; this is not a tuning recommendation.
Its offline follow-up audits unrecorded I1 dwell and prepares a bounded serial
failure observer. After isolated ARM virtual-servo qualification, a native-only
installation passed disabled-device overhead checks. Moving-load validation
and the cause of the earlier physical parsing fault remain open.
The follow-up [single-upward-leg trial and monotonic log](docs/I_GAIN_TRANSACTION.md#single-upward-scope-and-monotonic-log-offline--october-20)
now pass host and isolated ARM PTY validation. The
[live owner adapter](docs/I_GAIN_TRANSACTION.md#live-owner-adapter-and-installation-preparation--october-20)
also passed an isolated I0/I1/I0 wire trial and read-only production transport
checks. The daemon patch is now installed and has passed
[disabled-only baseline/candidate overhead checks](docs/I_GAIN_TRANSACTION.md#single-upward-daemon-installation-and-disabled-checks--october-20).
The [single-upward I0/I1/I0 capture](docs/I_GAIN_TRANSACTION.md#single-upward-i0i1i0-capture--october-23)
is now complete, with A2's interrupted closure recovered separately. I1 produced
a delayed partial reduction of motor 15's error; restored I0 reproduced the
baseline shortfall. Original settings are retained. Whole-head error, stationary
admission rejections and serial reliability remain unresolved.
The [stationary-health diagnostic candidate](docs/I_GAIN_TRANSACTION.md#stationary-health-installation-and-disabled-checks--october-25)
now identifies Moving/velocity rejections from the current request without extra
bus reads or changed admission rules. Its isolated ARM qualification has passing
evidence for all 38 PTY cases across two batches and 21 daemon checks. One virtual
serial timeout remains recorded. The patch is now installed, with disabled-only
baseline/candidate overhead checks passed; physical reliability remains open.
The [teleoperation research guide](docs/research/README.md) connects the dated
engineering reports, reproducible offline comparators and next experiment gates.
Its planner recommendations remain proposals; it does not admit new hardware behavior.
The [repeatable six-axis comparison runner](docs/MOVEMENT_COMPARISON_MATRIX.md)
defines visible interior-range trials, scored returns, timing and visual feedback.
Its fourth approach is an offline-tested [persistent bounded follower](docs/BOUNDED_FOLLOWER.md).
`npm run compare:offline` runs all four paths with synthetic feedback only; no
robot connection or new browser motion mode is enabled by that command.

Guided setup offers explicit Bluetooth capability probes, a checked local Wi-Fi
API route, and robot-owned Settings/dashboard links. Unsupported Bluetooth,
unknown versions and browser access restrictions retain the robot-owned fallback.
The [reconnection guide](https://mesmerprism.com/reachy-mini/#recover) helps an
already configured robot recover through current status checks, official Bluetooth
maintenance or a physical power cycle. It explains browser support and uncertain
restart replies without automatically sending robot commands. Second-device checks
help distinguish browser access problems from shared network failures. The guide
also explains an observed OS routing fault and why daemon restart may not repair
it; the experimental networking patch is not installed or bundled. See [recovery](docs/RECOVERY.md).
Setup sends no motion or Wake commands. Its optional software updater requires
explicit readiness and submission; the complete fresh access-point workflow and
in-page update path still need attended hardware validation. See [setup](docs/SETUP.md).

The demo uses a synthetic panorama and simulated feedback. It is approximate
visualization, not calibrated sensing or physics. The real camera never substitutes
the panorama. See [demo asset provenance](public-site/DEMO_ASSETS.md).

Desktop controls prioritize the camera and head gestures beside a small measured
3D model. Drag the camera image to turn and nod with the same mapping as the look
pad. A separate **Shift head** pad moves sideways and vertically; forward/back
uses a small slider. Antennas have compact sliders inside the model panel, with
precise inputs and optional 3D dragging under its disclosure. Ordinary model
dragging orbits the view. Smaller screens
stack the panels. Audio, tracking, emotes, agent commands and WebXR remain available
in expandable controls on the same page.

In Demo, **Phone motion** uses Android phone turn/nod/tilt directly or through a
paired phone-to-PC connection. Sensor access, following and the held button are
explicit. Pairing uses two temporary private codes without a signaling server.
Phone inputs are simulation-only; they cannot control a physical robot. Read
[phone setup and limitations](docs/PHONE_CONTROL.md).

## Run locally

Use Node **24** (CI baseline; Vite also supports Node 22.12+). Clone this repository
or extract the reviewed source ZIP linked from the hosted page:

```sh
npm ci
npm run build
npm run demo
```

Open **http://localhost:18750** for simulation. For the guarded local robot bridge:

```sh
npm run setup
npm start
```

Setup performs read-only status discovery, requires daemon **1.10.0**, and saves
your daemon origin and hardware identity in ignored `local/config.json` after
confirmation. The bridge binds to loopback. Head movement is disabled by default;
`npm run setup -- --head-follow` records operator approval for attended head controls.
See [local setup and limits](docs/SETUP.md).

Robot actions require explicit user input. There is no startup movement or command
replay on reconnect. Requested targets and measured state are distinct. Local
Stop drains in-flight writes before holding fresh measured positions; hosted SDK
transport has different capabilities. **Stop is software control, not a hardware
emergency stop.** Closing the page does not automatically put the robot to sleep.

## Develop and build

```sh
npm test
npm run build
npm run build:pages
npm run build:pages -- --base /reachy-mini-browser-control/
```

Tests use offline fixtures and do not operate a robot. Both build commands prepare
verified Google webcam assets: the pinned face model downloads on first use and
the WASM runtime is copied from installed dependencies. They do not fetch private
CAD. Later builds can reuse the verified local model. Local builds
use the original schematic by default. `build:pages` writes the standalone hosted
projection to ignored `local/pages`, with relative asset URLs by default;
`--base` selects a deployment path. Building does not publish the app.
The website is a deployment target, not a runtime dependency.

Optional `npm run prepare:cad` downloads pinned official CAD for private staging.
To opt into that prepared model locally, build with `VITE_REACHY_MODEL=private-cad`.
Those hardware assets have separate, unresolved redistribution terms and are
excluded from public downloads. Review [third-party notices](THIRD_PARTY_NOTICES.md)
before sharing generated models. Keep configuration, credentials, robot identities,
network details and private evidence out of commits and public archives.

Compact head/antenna gestures, the in-page agent console and experimental WebXR
headset view share the same Controls page. Read [interaction and automation details](docs/SETUP.md#spatial-controls-page-console-and-webxr).

For read-only diagnostics, `npm run agent -- --help` lists bounded status,
offline guidance and publication-integrity commands. See [CLI details](docs/SETUP.md#agent-diagnostics-cli).
The hosted controller also exposes `window.reachyAgent.diagnostics()` and an
expandable **Connection & diagnostics** panel. Its copyable summary excludes
identity, addresses and credentials and reads the current tab snapshot only.
Head and antenna targets expire after 15 seconds without new input; discarding
unsent targets is separate from software Stop and does not prove physical arrival.
For project structure and changes, read [architecture](docs/ARCHITECTURE.md) and
[contributing](CONTRIBUTING.md).
