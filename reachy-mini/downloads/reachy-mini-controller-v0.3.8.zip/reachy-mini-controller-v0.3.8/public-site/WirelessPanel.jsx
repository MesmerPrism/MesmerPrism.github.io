import { useEffect, useRef, useState, lazy, Suspense } from 'react';
import { WirelessControl, WIRELESS_EMOTES } from '../src/wireless-control.mjs';
import { createWirelessTalk } from '../src/wireless-audio.mjs';
import FitText from './FitText.jsx';
import { OrientationPad, AngleControl, PrecisionField, PositionPad, CameraAimSurface } from '../src/SpatialControls.jsx';
import AgentConsole from '../src/AgentConsole.jsx';
import ControllerDiagnostics from './ControllerDiagnostics.jsx';
import PhoneMotionControls from './PhoneMotionControls.jsx';
import { createCommandFlight } from '../src/command-flight.mjs';
import { stageTarget, assessStagedTarget } from '../src/staged-target.mjs';
import ConnectionGuide from './ConnectionGuide.jsx';
import { connectionSteps } from '../src/connection-readiness.mjs';
import { createLocalWirelessSDK, localSignalingUrl } from '../src/local-wireless.mjs';
const WebXRControls = lazy(() => import('../src/WebXRControls.jsx'));
const RobotModel = lazy(() => import('../src/RobotModel.jsx'));
const SimulatedCamera = lazy(() => import('./SimulatedCamera.jsx'));
const zero = { yaw: 0, pitch: 0, roll: 0, x: 0, y: 0, z: 0 };
const names = { yaw: 'Turn', pitch: 'Nod', roll: 'Tilt', x: 'Forward / back', y: 'Left / right', z: 'Up / down' };
const degrees = value => Number.isFinite(value) ? value.toFixed(1) : '—';
function Slider({ label, value, min, max, measured, unit, disabled, onChange }) {
  return <div className="slider-row"><label><span className="slider-heading"><FitText>{label}</FitText><FitText>{`${value}${unit} requested`}</FitText></span><input type="range" min={min} max={max} step={1} value={value} disabled={disabled} onChange={event => onChange(Number(event.target.value))} aria-label={label} /></label><FitText as="p" className="measured">{`${degrees(measured)}${unit} measured`}</FitText></div>;
}
export default function WirelessPanel({ initialDemo = false, expectedVersion, evidence, onEvidence, loadSDK = () => import('@pollen-robotics/reachy-mini-sdk'), readinessNow = Date.now, initialConnectionMethod = 'local' }) {
  const control = useRef(null), latest = useRef({}), goal = useRef(null), tokenInput = useRef(null), video = useRef(null), webcam = useRef(null), tracker = useRef(null), follow = useRef(false), pose = useRef(null), talk = useRef(null), tickBusy = useRef(false), picker = useRef(null), generation = useRef(0), previewGeneration=useRef(0);
  const [status, setStatus] = useState({ connected: false }), [token, setToken] = useState(''), [consent, setConsent] = useState(false), [busy, setBusy] = useState(false), [error, setError] = useState(''), [message, setMessage] = useState('Disconnected'), [demo, setDemo] = useState(false), [choices, setChoices] = useState([]), [selection, setSelection] = useState(''), [head, setHead] = useState(zero), [antennas, setAntennas] = useState({ left: 0, right: 0 }), [listen, setListen] = useState(false), [listeningVolume, setListeningVolume] = useState(60), [volume, setVolume] = useState(40), [webcamState, setWebcamState] = useState('off'), [following, setFollowing] = useState(false), [tracked, setTracked] = useState(null), [micState, setMicState] = useState('off'), [held, setHeld] = useState(false), [speed, setSpeed] = useState(20);
  const mutationFlight = useRef(createCommandFlight()), xrContext = useRef(null), phoneContext = useRef(null);
  const [xrEngaged, setXrEngaged] = useState(false), [stopRevision, setStopRevision] = useState(0);
  const [phoneEngaged, setPhoneEngaged] = useState(false);
  const [connectionProgress, setConnectionProgress] = useState('idle');
  const [connectionMethod, setConnectionMethod] = useState(initialConnectionMethod);
  const [localEvidence, setLocalEvidence] = useState(evidence);
  const [, refreshConnectionClock] = useState(0);
  useEffect(() => { const timer = setInterval(() => refreshConnectionClock(value => value + 1), 5000); return () => clearInterval(timer); }, []);
  const currentEvidence = evidence ?? localEvidence, connectionNow = readinessNow();
  const recordEvidence = value => { setLocalEvidence(value); onEvidence?.(value); };
  const connectionBlocker = connectionSteps({ evidence: currentEvidence, status, progress: connectionProgress, now: connectionNow, method: connectionMethod }).find(step => ['version','account'].includes(step.id) && step.state === 'blocked');
  const localHost = currentEvidence?.host || 'reachy-mini.local';
  let localAddressValid = false; try { localSignalingUrl(localHost); localAddressValid = true; } catch { /* invalid address remains a visible blocker */ }
  latest.current = { status, busy, demo, speed, xrEngaged, phoneEngaged };
  const halt = () => { xrContext.current = null; phoneContext.current = null; setPhoneEngaged(false); goal.current = null; follow.current = false; setFollowing(false); talk.current?.disable(); };
  const stop = async () => { const gen=generation.current;setStopRevision(value => value + 1);halt();try { await performAction({ action: 'stop' }); } catch(error) { if(gen===generation.current)setError(error.message); } };
  const stopPreview=()=>{previewGeneration.current++;tracker.current?.stop();tracker.current=null;setWebcamState('off');};
  const disconnect = async () => { generation.current++; mutationFlight.current.clear(); halt(); stopPreview(); setListen(false); picker.current?.(null); picker.current = null; setChoices([]); const previous = control.current; control.current = null; await previous?.close(); setStatus({ connected: false }); setToken(''); setConnectionProgress('idle'); setMessage('Disconnected; requests were discarded'); };
  const [emote, setEmote] = useState(WIRELESS_EMOTES[0]);
  const performAction = async body => {
    const current = control.current, gen = generation.current;
    if (!current) throw Error('Connect first.');
    const flight = mutationFlight.current.begin(body.action === 'stop');
    halt(); setBusy(true); setError('');
    try {
      const result = await current.command({ ...body, epoch: current.snapshot().controlEpoch });
      if (gen !== generation.current || control.current !== current) throw Error('Connection changed while the command was pending.');
      if (result.queued === false) throw Error('Request was not queued.');
      if (flight.current()) setMessage(result.confirmed ? `${body.action}: daemon response received` : `${body.action}: queued, application unconfirmed`);
      return result;
    } finally {
      flight.release(); if (gen === generation.current) setBusy(mutationFlight.current.busy);
    }
  };
  const command = async body => { const gen = generation.current; try { await performAction(body); } catch (error) { if (gen === generation.current) setError(error.message); } };
  const connect = async isDemo => {
    const captured = token.trim(); setToken(''); setBusy(true); setError('');
    const disconnecting = disconnect(); const gen = ++generation.current; await disconnecting;
    if (gen !== generation.current) return;
    let next;
    try {
      const { ReachyMini } = isDemo ? { ReachyMini: (await import('./demo-sdk.mjs')).DemoWirelessSDK } : await loadSDK();
      if (gen !== generation.current) return;
      const local = !isDemo && connectionMethod === 'local';
      const SDK = local ? createLocalWirelessSDK(ReachyMini, { host: localHost }) : ReachyMini;
      next = new WirelessControl({ ReachyMini: SDK, connectionTimeoutMs: local ? 15000 : 5000, expectedVersion: isDemo ? '1.10.0' : expectedVersion, expectedHardwareId: isDemo ? null : currentEvidence?.expectedHardwareId || currentEvidence?.hardwareId }); control.current = next; setDemo(isDemo);
      let wasConnected = false;
      next.subscribe(value => {
        if (control.current !== next) return;
        setStatus(value);
        if (value.connected) wasConnected = true;
        else if (wasConnected) {
          halt(); setConnectionProgress('failed');
          setMessage('Connection ended; unsent requests discarded. Connect again explicitly.');
        }
      });
      await next.connect({ token: isDemo ? 'simulation' : local ? undefined : captured, video: video.current, onProgress: phase => {
        if (gen !== generation.current) return;
        setConnectionProgress(phase);
        const messages = { account: 'Checking the account with Pollen’s service…', selecting: 'Account accepted. Choose the intended robot…', negotiating: 'Opening the robot’s WebRTC session…', verifying: 'Checking robot identity and daemon version…', connected: 'Identity and daemon verified. Waiting for fresh telemetry…', failed: 'Connection incomplete' };
        setMessage(local && phase === 'account' ? 'Opening Reachy’s local signaling service…' : local && phase === 'selecting' ? 'Local service replied. Selecting Reachy…' : messages[phase] || 'Connecting…');
      }, pickRobot: robots => new Promise(resolve => {
        setChoices(robots); setSelection(robots[0]?.id || ''); picker.current = resolve;
      }) });
      if (gen !== generation.current) { await next.close(); return; }
      setChoices([]); picker.current = null; next.subscribePose();
      const measured = next.snapshot().measured; if (measured) { setHead(Object.fromEntries(Object.keys(zero).map(axis => {return [axis,measured.head[axis]];}))); setAntennas({ left: measured.antennas.left, right: measured.antennas.right }); }
      talk.current = createWirelessTalk({ sdk: next.robot, allowed: () => { const state = next.snapshot(); return !document.hidden && state.connected && state.ready && state.awake && !state.measured?.running && control.current === next; }, capture: () => navigator.mediaDevices.getUserMedia({ audio: { echoCancellation: true, noiseSuppression: true, autoGainControl: true }, video: false }), onState: (state, held) => { setMicState(state); setHeld(held); }, onError: error => setError(error.message) });
      if (!isDemo) {
        // Volume is explicitly a requested value until Apply. SDK 1.8 shares
        // one uncorrelated get/set reply slot; a startup read can hang setup or
        // misidentify a later write acknowledgement. Do not issue that read.
        if (!next.snapshot().connected) throw Error('The robot session ended during setup. Start a new connection explicitly.');
      }
      setMessage(isDemo ? 'Simulation: no robot, microphone or camera connection' : 'Connected; press Wake explicitly to move Reachy');
    } catch (error) { await next?.close(); if(gen===generation.current){if(control.current===next)control.current=null;setConnectionProgress('failed');setError(error.message);setStatus({connected:false});} } finally { if (gen === generation.current) setBusy(false); }
  };
  useEffect(() => {
    const timer = setInterval(async () => {
      const current = control.current; if (!current) return;
      const state = current.snapshot(); setStatus(state);
      if (goal.current && goal.current.epoch !== state.controlEpoch) goal.current = null;
      if (!state.connected || !state.ready || !state.awake || state.measured?.running || document.hidden) { goal.current = null; if (follow.current) { follow.current = false; setFollowing(false); } talk.current?.release(); return; }
      if (goal.current && !follow.current) {
        const assessment = assessStagedTarget(goal.current, { now: Date.now(), epoch: state.controlEpoch, measured: state.measured });
        if (assessment !== 'send') {
          goal.current = null;
          if (assessment === 'expired') setMessage('Target send deadline reached; unsent requests discarded. Compare measured values before a new request.');
          else if (assessment === 'converged') setMessage('Later measured values are within target tolerance; application remains unconfirmed.');
          else setMessage('Target discarded because its control context or telemetry changed.');
        }
      }
      if (tickBusy.current) return;
      let target = goal.current;
      if (follow.current) {
        const tracked = pose.current;
        if (!tracked?.tracked || !tracked.calibrated || performance.now() - tracked.receivedAt + tracked.ageMs > 250) { follow.current = false; setFollowing(false); void stop(); return; }
        target = { action: 'head-manual', pose: { ...state.measured.head, yaw: Math.max(-20,Math.min(20,tracked.yaw)), pitch: Math.max(-15,Math.min(15,tracked.pitch)) } };
      }
      if (!target || latest.current.busy) return;
      tickBusy.current = true;
      try { const result = await current.command({ ...target, epoch:state.controlEpoch, speed: latest.current.speed }); if (!result.queued) throw Error('Motion request was not queued'); if(control.current===current && current.snapshot().controlEpoch===state.controlEpoch && (goal.current === target || follow.current))setMessage('Target queued; compare the measured values'); }
      catch (error) { if(control.current===current && current.snapshot().controlEpoch===state.controlEpoch){ if(goal.current === target)goal.current = null; follow.current = false; setFollowing(false); setError(error.message); } }
      finally { tickBusy.current = false; }
    }, 50);
    const hide = () => { if (document.hidden) { void disconnect(); } };
    const blur = () => { if (goal.current || follow.current) void stop(); else talk.current?.release(); };
    const exit = () => { generation.current++; halt(); stopPreview(); void control.current?.close(); };
    document.addEventListener('visibilitychange', hide); window.addEventListener('blur', blur); window.addEventListener('pagehide', exit);
    return () => { clearInterval(timer); document.removeEventListener('visibilitychange', hide); window.removeEventListener('blur', blur); window.removeEventListener('pagehide', exit); exit(); };
  }, []);
  useEffect(() => { if (initialDemo) void connect(true); }, []);
  useEffect(() => { const node = video.current; if (node) { node.muted = !listen; node.volume = listeningVolume / 100; control.current?.robot?.setAudioMuted(!listen); if (listen) void node.play().catch(error => setError(error.message)); } }, [listen, listeningVolume]);
  const startWebcam = async () => {
    const requested=++previewGeneration.current;
    setError(''); setWebcamState('starting');
    try { const { createHeadTracker } = await import('../src/head-tracker.js'); if(requested!==previewGeneration.current)return; const next = createHeadTracker({ video: webcam.current, onState: setWebcamState, onError: error => setError(error.message), onPose: value => { pose.current = { ...value, receivedAt: performance.now() }; setTracked(value); if (!value.tracked && follow.current) void stop(); } }); tracker.current = next; await next.start(); }
    catch (error) { if(requested===previewGeneration.current){setWebcamState('off');setError(error.message);} }
  };
  const canMove = status.connected && status.ready && status.awake && !status.measured?.running && !busy;
  const submitHead = (partial, merge = true, owner = 'manual') => {
    const current = control.current, state = current?.snapshot();
    if (!state?.ready || !state.awake || state.measured?.running || latest.current.busy || mutationFlight.current.busy || document.hidden || follow.current) throw Error('Head control is not ready.');
    if ((phoneContext.current && owner !== 'phone') || (xrContext.current && owner !== 'xr')) throw Error('Another input owns head control.');
    if (!partial || !Object.keys(partial).length || Object.entries(partial).some(([axis, value]) => !Object.hasOwn(zero, axis) || !Number.isFinite(value) || Math.abs(value) > (axis === 'yaw' ? 20 : ['pitch', 'roll'].includes(axis) ? 15 : 10))) throw Error('Head target exceeds the selected controls.');
    const staged = stageTarget(goal.current, { action: 'head-manual', pose: partial, epoch: state.controlEpoch }, { now: Date.now(), measuredAt: state.measured.receivedAt, merge });
    setHead(value => ({ ...value, ...partial }));
    goal.current = staged;
    return { queued: true, confirmed: false, controlEpoch: state.controlEpoch, message: 'Target staged for the bounded controller loop.' };
  };
  const submitAntennas = (partial, merge = true) => {
    const state = control.current?.snapshot();
    if (!state?.ready || !state.awake || state.measured?.running || latest.current.busy || mutationFlight.current.busy || document.hidden || follow.current || xrContext.current || phoneContext.current) throw Error('Antenna control is not ready.');
    if (!partial || !Object.keys(partial).length || Object.entries(partial).some(([axis, value]) => !['left', 'right'].includes(axis) || !Number.isFinite(value) || Math.abs(value) > 90)) throw Error('Antenna target exceeds 90 degrees.');
    const staged = stageTarget(goal.current, { action: 'antennas', targets: partial, epoch: state.controlEpoch }, { now: Date.now(), measuredAt: state.measured.receivedAt, merge });
    setAntennas(value => ({ ...value, ...partial }));
    goal.current = staged;
    return { queued: true, confirmed: false, controlEpoch: state.controlEpoch };
  };
  const executeAgent = async (request, epoch) => {
    const current = control.current;
    if (!current || current.snapshot().controlEpoch !== epoch || (request.name !== 'stop' && (mutationFlight.current.busy || latest.current.busy || follow.current || xrContext.current || phoneContext.current))) throw Error('This connection is busy or the command epoch expired.');
    if (request.name === 'head') return submitHead(request.values, false);
    if (request.name === 'antennas') return submitAntennas(request.values, false);
    if (request.name === 'stop') setStopRevision(value => value + 1);
    return performAction({ action: request.name });
  };
  // Stable receipt conversion: reusing one packet must never fabricate an
  // older monotonic timestamp through Date.now()/performance.now() rounding.
  const modelControl = { session: { mode: demo ? 'demo' : 'wireless', token:`${generation.current}:${status.hardwareId || 'pending'}` }, status: { ...status, headPose: status.measured?.headMatrix, bodyYaw: status.measured?.bodyYawRad, antennas: status.measured?.antennas, diagnostics: { snapshot: { startAgeMs: status.measured ? Date.now() - status.measured.receivedAt : Infinity } } }, statusReadAt: status.measured ? status.measured.receivedAt-performance.timeOrigin : -Infinity };
  const antennaKey = `${generation.current}:${status.hardwareId || 'none'}`;
  const antennaContext = { sessionKey: antennaKey, controlEpoch: status.controlEpoch };
  const verifyAntennaContext = context => {
    const current = control.current;
    if (!context || context.sessionKey !== `${generation.current}:${current?.snapshot().hardwareId || 'none'}` || context.controlEpoch !== current?.snapshot().controlEpoch || mutationFlight.current.busy || latest.current.busy || follow.current || xrContext.current || phoneContext.current) throw Error('Antenna control context changed.');
  };
  const antennaControl = { targets: antennas, measured: status.measured?.antennas, disabled: !canMove || following || xrEngaged || phoneEngaged,
    ...antennaContext, onChange: (side, value, context) => { verifyAntennaContext(context); return submitAntennas({ [side]: value }); },
    onCenter: context => { verifyAntennaContext(context); return submitAntennas({ left: 0, right: 0 }); } };
  const headGestureKey = `${antennaKey}:${status.controlEpoch}:${stopRevision}`;
  const manualHead = partial => {
    try {
      if (xrContext.current || phoneContext.current || control.current?.snapshot().controlEpoch !== status.controlEpoch) throw Error('Head control context changed.');
      return submitHead(partial);
    } catch (problem) { setError(problem.message); return false; }
  };
  return <>
    {!initialDemo && <div className="connection-form"><label htmlFor="connection-method">Connection method</label><select id="connection-method" value={connectionMethod} disabled={busy || status.connected} onChange={event => { setConnectionMethod(event.target.value); setToken(''); setError(''); setConnectionProgress('idle'); }}><option value="local">Local network · no account or download</option><option value="account">Account access · Hugging Face</option></select></div>}
    {!initialDemo && <details className="connection-guide" open={!status.connected}><summary>{status.ready ? 'Connection verified' : 'Connection steps and blockers'}</summary><ConnectionGuide evidence={currentEvidence} onEvidence={recordEvidence} status={status} progress={connectionProgress} busy={busy} now={connectionNow} method={connectionMethod} /></details>}
    {!status.connected && initialDemo && <div className="actions"><button type="button" disabled={busy} onClick={() => void connect(true)}>Start simulation</button></div>}
    {!status.connected && !initialDemo && <form className="connection-form" onSubmit={event => { event.preventDefault(); void connect(false); }}>
      {connectionMethod === 'account' ? <><label htmlFor="hf-token">Hugging Face read token</label><input ref={tokenInput} id="hf-token" type="password" autoComplete="off" spellCheck={false} value={token} onChange={event => setToken(event.target.value)} disabled={busy} placeholder="Paste your own read token" />
      <label className="checkbox"><input type="checkbox" checked={consent} onChange={event => setConsent(event.target.checked)} />Connect through Pollen’s signaling service. My token stays in this tab’s memory.</label>
      </> : <p>Connect directly to {localHost}. No account credentials are sent. Wake remains a separate action.</p>}
      <button className="primary" disabled={busy || (connectionMethod === 'account' ? !token.trim() || !consent : !localAddressValid) || !!connectionBlocker}>{connectionMethod === 'local' ? 'Connect locally' : 'Connect to my robot'}</button>
      {connectionBlocker && <p>Connection is blocked at “{connectionBlocker.title}”. Complete that step above, then check the robot again.</p>}
    </form>}
    {choices.length > 0 && <div className="connection-form"><label htmlFor="robot-picker">Choose a robot</label><select id="robot-picker" value={selection} onChange={event => setSelection(event.target.value)}>{choices.map(robot => <option key={robot.id} value={robot.id}>{robot.meta?.name || robot.id}</option>)}</select><button onClick={() => picker.current?.(selection)}>Start selected session</button><button onClick={() => picker.current?.(null)}>Cancel connection</button></div>}
    <div className="controller-bar">
      <p className="status" aria-live="polite">{`${demo && status.connected ? 'Simulated · ' : ''}${message}${status.connected ? ` · ${status.ready ? status.awake ? 'Awake' : 'Asleep' : 'Waiting for fresh verified state'}` : ''}`}</p>
      {status.connected && <div className="actions"><button className="stop" onClick={() => void stop()}>Stop motion requests</button><button disabled={busy || !status.ready || status.awake} onClick={() => void command({action:'wake'})}>Wake</button><button disabled={busy || !status.ready || !status.awake} onClick={() => { talk.current?.disable(); void command({action:'sleep'}); }}>Sleep</button><button onClick={() => void disconnect()}>Disconnect</button></div>}
    </div>
    {error && <p className="error" role="alert">{error}</p>}
    <div className="connected-surface" hidden={!status.connected}>
      <div className="controller-workspace">
        <section className="control-section operator-camera"><h2>{initialDemo || demo ? 'Simulated camera' : 'Reachy camera'}</h2>
          <CameraAimSurface values={head} hidden={initialDemo || demo && status.connected} disabled={!canMove || following || xrEngaged || phoneEngaged || demo} onChange={manualHead} contextKey={headGestureKey}>
            <video ref={video} autoPlay muted playsInline hidden={initialDemo || demo && status.connected} />
          </CameraAimSurface>
          {demo && status.connected && <Suspense fallback={<p>Loading simulated camera…</p>}><SimulatedCamera measured={status.measured} compact aimControl={{values:head,disabled:!canMove || following || xrEngaged || phoneEngaged,onChange:manualHead,contextKey:headGestureKey}} /></Suspense>}
          <p className="camera-aim-help">Drag the camera view to turn and nod.</p>
          {!demo && <p className="media-note">Live WebRTC feed · audio off until enabled.</p>}
          <details className="camera-options"><summary>Listening & camera details</summary>
            <label className="checkbox"><input type="checkbox" checked={listen} disabled={!status.connected || demo} onChange={event => setListen(event.target.checked)} />Listen to Reachy’s microphone</label>
            <Slider label="Listening volume" value={listeningVolume} min={0} max={100} unit="%" disabled={!listen} onChange={setListeningVolume} />
            <p>{demo ? 'Simulation has no microphone stream.' : 'Listening plays the robot microphone on this computer. It does not enable the computer microphone.'}</p>
          </details>
        </section>
        <Suspense fallback={<section className="control-section"><h2>Reachy in 3D</h2><p>Loading model…</p></section>}><RobotModel control={modelControl} schematic Text={FitText} antennaControl={antennaControl} /></Suspense>
        <section className="control-section operator-head"><h2>Head movement</h2>
          <div className="spatial-orientation"><OrientationPad contextKey={headGestureKey} values={head} measured={status.measured?.head} disabled={!canMove || following || xrEngaged || phoneEngaged} onChange={manualHead} /><AngleControl contextKey={headGestureKey} label="Tilt" value={head.roll} measured={status.measured?.head.roll} limit={15} disabled={!canMove || following || xrEngaged || phoneEngaged} onChange={roll => manualHead({ roll })} /></div>
          <button disabled={!canMove || following || xrEngaged || phoneEngaged} onClick={() => manualHead({ yaw: 0, pitch: 0, roll: 0 })}>Center orientation</button>
          <p className="spatial-help">Solid = requested · dashed = measured. Directions are Reachy’s own.</p>
          <div className="spatial-translation"><PositionPad values={head} measured={status.measured?.head} limits={{y:10,z:10}} disabled={!canMove || following || xrEngaged || phoneEngaged} onChange={manualHead} contextKey={headGestureKey} /><div className="translation-depth"><label>Forward / back · {head.x.toFixed(1)} mm<input type="range" min={-10} max={10} step={.1} value={head.x} disabled={!canMove || following || xrEngaged || phoneEngaged} aria-label="Head forward and back position" onChange={event => manualHead({x:Number(event.target.value)})} /></label><p className="spatial-measured">Measured {degrees(status.measured?.head.x)} mm</p><button disabled={!canMove || following || xrEngaged || phoneEngaged} onClick={() => manualHead({x:0,y:0,z:0})}>Center position</button></div></div>
          <details className="spatial-position"><summary>Position & speed</summary><p>Head position in millimetres from the neutral origin.</p><div className="spatial-position-fields">{['x','y','z'].map(axis => <PrecisionField key={axis} label={names[axis]} value={head[axis]} limit={10} unit="mm" disabled={!canMove || following || xrEngaged || phoneEngaged} onChange={value => submitHead({ [axis]: value })} />)}</div><button disabled={!canMove || following || xrEngaged || phoneEngaged} onClick={() => submitHead({ x: 0, y: 0, z: 0 })}>Center position</button><label className="compact-speed">Angular speed <input type="number" aria-label="Angular speed limit" min={5} max={30} value={speed} onChange={event => {const next=Number(event.target.value);if(Number.isFinite(next)&&next>=5&&next<=30)setSpeed(next);}} /> °/s</label><p>Translation is capped at 10 mm/s.</p></details>
        </section>
      </div>
      <div className="controller-options">
        <details className="control-section"><summary>Emotes</summary><label htmlFor="emote-picker">Official emotion library</label><select id="emote-picker" value={emote} onChange={event=>setEmote(event.target.value)}>{WIRELESS_EMOTES.map(name=><option key={name}>{name}</option>)}</select><button disabled={!canMove || demo || following || xrEngaged || phoneEngaged} onClick={()=>void command({action:'emote',name:emote})}>Play selected emote</button><p>Playback is queued only. The robot must have the official emotion library available.</p></details>
        <details className="control-section"><summary>Speaker & push to talk</summary>
          <Slider label="Reachy speaker volume" value={volume} min={0} max={100} unit="%" disabled={!status.connected || !status.ready || busy} onChange={setVolume} />
          <div className="actions"><button disabled={!status.ready || busy} onClick={() => void command({action:'volume',value:volume})}>Apply speaker volume</button><button disabled={!status.ready || busy} onClick={() => {setVolume(0);void command({action:'volume',value:0});}}>Mute speaker</button></div>
          <p>{`Computer microphone: ${micState}${held ? ' · transmitting while held' : ''}`}</p>
          <div className="actions"><button disabled={!canMove || demo || micState==='enabling'} onClick={() => void talk.current?.enable()}>Enable computer microphone</button><button disabled={micState==='off'} onClick={() => talk.current?.disable()}>Disable microphone</button><button className="push-talk" aria-pressed={held} disabled={!canMove || demo || micState!=='ready'} onPointerDown={event => {event.currentTarget.setPointerCapture(event.pointerId);void talk.current?.press();}} onPointerUp={() => talk.current?.release()} onPointerCancel={() => talk.current?.release()} onLostPointerCapture={() => talk.current?.release()} onKeyDown={event => {if ([' ','Enter'].includes(event.key)&&!event.repeat){event.preventDefault();void talk.current?.press();}}} onKeyUp={event=>{if([' ','Enter'].includes(event.key)){event.preventDefault();talk.current?.release();}}} onBlur={() => talk.current?.release()}>Hold to talk through Reachy</button></div>
        </details>
        <details className="control-section tracking-options"><summary>Webcam tracking</summary><div className="media-grid"><video ref={webcam} autoPlay playsInline muted /><div><p>{`Webcam: ${webcamState} · ${following ? 'Following your head' : 'Preview does not move Reachy'}`}</p><p>{tracked?.tracked && tracked?.calibrated ? `Turn ${degrees(tracked.yaw)}° · Nod ${degrees(tracked.pitch)}°` : 'Look forward and set a neutral pose.'}</p><div className="actions"><button disabled={webcamState!=='off'&&webcamState!=='idle'} onClick={() => void startWebcam()}>Start webcam preview</button><button disabled={!tracked?.tracked || following} onClick={() => {if(!tracker.current?.calibrate())setError('Wait for a fresh face frame.');}}>Set neutral pose</button><button disabled={!canMove || xrEngaged || phoneEngaged || !tracked?.tracked || !tracked.calibrated || following} onClick={() => {goal.current=null;follow.current=true;setFollowing(true);}}>Follow my head</button><button disabled={!following} onClick={() => void stop()}>Stop following</button><button disabled={webcamState==='off'||webcamState==='idle'} onClick={() => {void stop();stopPreview();}}>Turn webcam off</button></div></div></div></details>
        <details className="control-section xr-options"><summary>WebXR headset</summary><Suspense fallback={<p>Loading WebXR controls…</p>}><WebXRControls snapshot={{ ...status, headAngles: status.measured?.head }} requested={head} allowed={canMove && !following && !phoneEngaged} demo={demo} onHeadChange={partial => { const ctx=xrContext.current;if(!ctx || control.current!==ctx.control || ctx.control.snapshot().controlEpoch!==ctx.epoch || phoneContext.current)throw Error('XR control context expired.');return submitHead(partial, false, 'xr'); }} onStop={() => { if(xrContext.current?.control===control.current)void stop(); }} onEngagementChange={value => { if(value && phoneContext.current)throw Error('Phone motion owns head control.');xrContext.current=value && control.current ? {control:control.current,epoch:control.current.snapshot().controlEpoch} : null;setXrEngaged(value); }} connectionKey={antennaKey} stopRevision={stopRevision} videoElement={video.current} /></Suspense></details>
        {demo && <PhoneMotionControls key={antennaKey} demo={demo} allowed={canMove && !following && !xrEngaged}
          getSnapshot={() => ({ ...(control.current?.snapshot() || { connected: false }), busy: mutationFlight.current.busy || latest.current.busy })} connectionKey={antennaKey} stopRevision={stopRevision}
          onEngagementChange={value => {
            if (!value) { if(phoneContext.current?.key===antennaKey){phoneContext.current=null;goal.current=null;setPhoneEngaged(false);}return true; }
            const current=control.current,state=current?.snapshot();
            if(!latest.current.demo || !state?.connected || !state.ready || !state.awake || state.measured?.running || follow.current || xrContext.current || phoneContext.current || mutationFlight.current.busy || latest.current.busy || document.hidden)return false;
            goal.current=null;phoneContext.current={control:current,epoch:state.controlEpoch,key:antennaKey};setPhoneEngaged(true);return true;
          }} onHeadChange={partial => {
            const context=phoneContext.current;
            if(!latest.current.demo || !context || context.key!==antennaKey || context.control!==control.current || context.epoch!==context.control.snapshot().controlEpoch)throw Error('Phone simulation context expired.');
            return submitHead(partial,false,'phone');
          }} onStop={() => {
            const context=phoneContext.current;
            if(latest.current.demo && context?.key===antennaKey && context.control===control.current && context.epoch===context.control.snapshot().controlEpoch)void command({action:'stop'});
          }} />}
        <AgentConsole snapshot={() => control.current?.snapshot() || { connected: false }} diagnosticsContext={{ transport: demo || initialDemo ? 'simulation' : 'wireless' }} execute={executeAgent} onDisarm={() => { goal.current = null; }} sessionKey={antennaKey} disabled={!status.connected || busy || following || xrEngaged || phoneEngaged} />
      </div>
    </div>
    <div className="controller-options"><ControllerDiagnostics key={antennaKey} snapshot={status} demo={demo || initialDemo} /></div>
  </>;
}
