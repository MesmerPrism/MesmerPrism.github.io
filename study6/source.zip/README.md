# Study 6 WebXR stimulus

Standalone browser implementation of the Study 6 particle stimulus. It contains 1,024 sampled particles on each hand and 2,562 sphere particles, the original hand rigs and feather mask, GPU oscillator integration, DHS/SHD selection and all four coherence/energy conditions.

Only same-axis neighbour phase coupling is implemented. Each oscillator component reads that component of its neighbours. Final 3D displacement assembly and magnitude limiting are separate from phase coupling. Experiment flow, questionnaires, physiology and data collection are outside this app.

## Run locally

Requires Node.js 20.19+ or 22.12+ and a WebGL2 browser with floating-point render targets.

```sh
npm install
npm run dev
```

Open the address printed by Vite, normally http://127.0.0.1:5176/. Desktop mode is explicitly labelled **Synthetic hand preview**. Drag the canvas to look around. The preview skins the real rig and samples the real surface; it is not a recording.

```sh
npm test
npm run build
```

The production app is in `dist/`. It is static files and needs no application backend. Serve the complete directory over HTTPS. Relative build and asset URLs support deployment at a subdirectory as well as the origin root. For a local production check, use `npm run preview`.

For publication, use the static exporter described in [static export](docs/STATIC_EXPORT.md). It builds from a clean committed source and adds the corresponding source archive, license, notices and a byte-hash manifest to the static app.

## Use on a headset

Open the HTTPS address in a WebXR browser with articulated hands and `local-floor` support, then select **Enter VR**. The application requests real hands for VR and switches the visible input selection accordingly. A plain HTTP LAN address is insufficient. Loopback localhost is useful for desktop testing but is not the computer's address from a headset.

Missing live hands are hidden and their dynamics pause until valid tracking returns. Frequencies are captured from each hand's first valid surface after starting or resetting its configuration; preview poses are not retained as live configuration. Exiting VR restores the explicitly selected desktop mode.

- **DHS:** dynamic hand particles and a static white sphere.
- **SHD:** static white hand particles that still follow tracking, and a dynamic sphere.
- **Coherence / Energy:** select the four original stimulus profiles.
- **Pause motion:** freezes oscillators while current hand poses continue to update.
- **Reset motion:** starts the deterministic oscillators again using fresh valid hand surfaces.
- **Recenter:** captures the current head centre/orientation. Automatic movement beyond 0.3 m translates the sphere while preserving its captured orientation.

No live hands are replaced by synthetic input. A graphics context failure stops the app with a reload instruction. Browser visibility interruptions pause simulation time; exceptionally long frame intervals are capped to avoid an uncontrolled single-step jump. This is a stimulus player, not a timed experiment runner.

## Implementation

- `src/hands/`: named WebXR joint intake, exact rig skinning and pinned barycentric sampling.
- `src/dynamics/`: deterministic CPU reference and WebGL2 ping-pong GPU integration.
- `src/renderer.js`: instanced eye-facing particle quads with native mask, size, depth and colour treatment.
- `src/main.js`: scene and XR lifecycle; one simulation update per frame before stereo rendering.
- `public/assets/`: only runtime rigs, samples, graphs, sphere data and mask, with SHA-256 manifests.

There is no synchronous GPU readback in the production frame loop. `?debug=1` exposes developer inspection and reset hooks for local QA. Diagnostic readback is opt-in and is not a performance measurement.

## Validation and limits

See [validation](docs/VALIDATION.md), [hand provenance](docs/HAND_PROVENANCE.md) and [dynamics provenance](docs/DYNAMICS_PROVENANCE.md). Automated tests cover numerical integration, axis independence, exact assets, invalid tracking, surface sampling and lifecycle state. Rendered browser checks cover all eight variant/profile combinations, pause/reset, missing live hands, mobile layout and GPU/CPU comparisons.

The current build has **not yet been qualified on a physical headset**. Real-hand alignment, wearer-visible depth/appearance, repeated headset session entry/exit and sustained Quest performance require attended testing on the target browser/device. Desktop screenshots and numerical agreement do not establish those results.

Source and assets retain the provenance and terms described in [NOTICE.md](NOTICE.md) and [LICENSE.md](LICENSE.md). The public-ready subset does not include native app history or excluded coupling behavior.
