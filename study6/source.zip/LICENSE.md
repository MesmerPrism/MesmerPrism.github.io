# License

SPDX-License-Identifier: AGPL-3.0-only

The application source is licensed under the GNU Affero General Public License, version 3 only. The canonical license text is available from the [Free Software Foundation](https://www.gnu.org/licenses/agpl-3.0.html).

Third-party components and runtime assets retain their applicable original licenses and terms. See NOTICE.md and the provenance manifests.
