# Study 6 WebXR stimulus

Standalone browser stimulus owner. The native application and its lifecycle remain unchanged. The accepted design is in docs/DESIGN.md; bounded implementation tasks are in docs/IMPLEMENTATION.md. Those notes derive from the user-approved scope, not a replacement for native acceptance.

Keep only same-axis neighbor phase coupling. Do not import cross-axis equations, parameters, shader code, controls, private experiment flows, sensor/storage code, or native Git history. Preserve hand rigs, sample ordering and particle appearance. Use synthetic input only when explicitly labeled; never silently substitute it for missing live tracking. Public-ready source does not imply publication or headset acceptance.

Run npm test and npm run build. Rendered changes require a browser check; live XR claims require actual headset evidence. Keep machine paths and test captures in ignored local/. Other agents are active; keep one writer per assigned file and preserve their work. Use Node's test runner for meaningful numerical and tracking/lifecycle behavior tests. No source changes outside this new repository.

