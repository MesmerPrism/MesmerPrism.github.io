// SPDX-License-Identifier: AGPL-3.0-only
/** Runtime-only hand surface pipeline. See docs/HAND_PROVENANCE.md. */
const JOINT_COUNT = 26;
const SAMPLE_COUNT = 1024;
const EPSILON = 1e-12;

// WebXR has no palm joint. Explicit names prevent dependence on XRHand iteration order.
export const WEBXR_JOINT_NAMES = Object.freeze([
  'wrist', 'thumb-metacarpal', 'thumb-phalanx-proximal', 'thumb-phalanx-distal', 'thumb-tip',
  'index-finger-metacarpal', 'index-finger-phalanx-proximal', 'index-finger-phalanx-intermediate', 'index-finger-phalanx-distal', 'index-finger-tip',
  'middle-finger-metacarpal', 'middle-finger-phalanx-proximal', 'middle-finger-phalanx-intermediate', 'middle-finger-phalanx-distal', 'middle-finger-tip',
  'ring-finger-metacarpal', 'ring-finger-phalanx-proximal', 'ring-finger-phalanx-intermediate', 'ring-finger-phalanx-distal', 'ring-finger-tip',
  'pinky-finger-metacarpal', 'pinky-finger-phalanx-proximal', 'pinky-finger-phalanx-intermediate', 'pinky-finger-phalanx-distal', 'pinky-finger-tip',
]);
const COMPACT_ROWS = new Uint8Array([0, 1, 2, 3, 4, 6, 7, 8, 9, 11, 12, 13, 14, 16, 17, 18, 19, 21, 22, 23, 24]);
const TIP_ROWS = new Uint8Array([5, 10, 15, 20, 25]);
const PARENTS = new Uint8Array([1, 1, 1, 2, 3, 4, 1, 6, 7, 8, 9, 1, 11, 12, 13, 14, 1, 16, 17, 18, 19, 1, 21, 22, 23, 24]);
const FILE_LAYOUT = Object.freeze({ bindVertices: ['f32', 4080], bindNormals: ['f32', 4080], triangles: ['u32', 6942], vertexJointIndices: ['u32', 5440], vertexJointWeights: ['f32', 5440], bindJointPoses: ['f32', 182], bindJointSources: ['u32', 104], sampleTriangles: ['u32', 1024], sampleBarycentric: ['f32', 3072] });

function checkSide(side) {
  if (side !== 'left' && side !== 'right') throw new Error('Hand side must be left or right');
}

function writePose(target, offset, x, y, z, qx, qy, qz, qw) {
  const squared = qx * qx + qy * qy + qz * qz + qw * qw;
  if (!Number.isFinite(x) || !Number.isFinite(y) || !Number.isFinite(z) || !Number.isFinite(squared) || squared <= EPSILON) return false;
  const scale = 1 / Math.sqrt(squared);
  qx *= scale; qy *= scale; qz *= scale; qw *= scale;
  const xx = qx * qx, yy = qy * qy, zz = qz * qz, xy = qx * qy, xz = qx * qz, yz = qy * qz;
  const xw = qx * qw, yw = qy * qw, zw = qz * qw;
  target[offset] = 1 - 2 * (yy + zz); target[offset + 1] = 2 * (xy + zw); target[offset + 2] = 2 * (xz - yw); target[offset + 3] = 0;
  target[offset + 4] = 2 * (xy - zw); target[offset + 5] = 1 - 2 * (xx + zz); target[offset + 6] = 2 * (yz + xw); target[offset + 7] = 0;
  target[offset + 8] = 2 * (xz + yw); target[offset + 9] = 2 * (yz - xw); target[offset + 10] = 1 - 2 * (xx + yy); target[offset + 11] = 0;
  target[offset + 12] = x; target[offset + 13] = y; target[offset + 14] = z; target[offset + 15] = 1;
  return Number.isFinite(target[offset + 12]) && Number.isFinite(target[offset + 13]) && Number.isFinite(target[offset + 14]);
}

function bindMatrices(poses) {
  if (poses.length !== JOINT_COUNT * 7) throw new Error('Expected 26 bind poses');
  const matrices = new Float32Array(JOINT_COUNT * 16);
  for (let j = 0; j < JOINT_COUNT; j++) {
    const p = j * 7;
    if (!writePose(matrices, j * 16, poses[p], poses[p + 1], poses[p + 2], poses[p + 3], poses[p + 4], poses[p + 5], poses[p + 6])) throw new Error('Invalid bind position or quaternion');
  }
  return matrices;
}

/** Load only the hash-pinned runtime rig and exact 1,024 triangle/barycentric samples. */
export async function loadHandRig(side, { fetcher = globalThis.fetch, baseUrl = '/assets/hands/' } = {}) {
  checkSide(side);
  const base = baseUrl.endsWith('/') ? baseUrl : `${baseUrl}/`;
  const response = await fetcher(`${base}${side}.manifest.json`);
  if (!response.ok) throw new Error(`Cannot load ${side} hand manifest: ${response.status}`);
  const manifest = await response.json();
  if (manifest.schema !== 'study6.webxr.hand-rig.v1' || manifest.side !== side || manifest.vertexCount !== 1360 || manifest.triangleCount !== 2314 || manifest.bindJointCount !== JOINT_COUNT || manifest.sampleCount !== SAMPLE_COUNT) throw new Error('Unsupported hand rig manifest');
  const rig = { side, vertexCount: manifest.vertexCount, triangleCount: manifest.triangleCount, sampleCount: SAMPLE_COUNT, manifest };
  await Promise.all(Object.entries(FILE_LAYOUT).map(async ([field, [type, count]]) => {
    const entry = manifest.files?.[field];
    if (!entry || !/^[a-z0-9-]+\.(f32|u32)\.bin$/.test(entry.file) || entry.type !== type || entry.count !== count || !/^[a-f0-9]{64}$/.test(entry.sha256)) throw new Error(`Invalid hand asset entry: ${field}`);
    const asset = await fetcher(`${base}${entry.file}`);
    if (!asset.ok) throw new Error(`Cannot load hand asset: ${entry.file}`);
    const bytes = await asset.arrayBuffer();
    if (bytes.byteLength !== count * 4) throw new Error(`Hand asset size mismatch: ${field}`);
    const digest = new Uint8Array(await globalThis.crypto.subtle.digest('SHA-256', bytes));
    const hash = Array.from(digest, x => x.toString(16).padStart(2, '0')).join('');
    if (hash !== entry.sha256) throw new Error(`Hand asset digest mismatch: ${field}`);
    const view = new DataView(bytes), values = type === 'f32' ? new Float32Array(count) : new Uint32Array(count);
    for (let i = 0; i < count; i++) values[i] = type === 'f32' ? view.getFloat32(i * 4, true) : view.getUint32(i * 4, true);
    rig[field] = values;
  }));
  validateRig(rig);
  rig.bindJointMatrices = bindMatrices(rig.bindJointPoses);
  rig.previewLocalMatrices = makePreviewLocals(rig.bindJointMatrices);
  return rig;
}

function validateRig(rig) {
  checkSide(rig.side);
  const n = rig.bindVertices?.length;
  if (!n || n % 3 || rig.bindNormals?.length !== n || rig.vertexCount !== n / 3 || rig.vertexJointIndices?.length !== rig.vertexCount * 4 || rig.vertexJointWeights?.length !== rig.vertexCount * 4) throw new Error('Invalid hand vertex/influence counts');
  if (rig.bindJointSources?.length !== JOINT_COUNT * 4 || rig.bindJointPoses?.length !== JOINT_COUNT * 7) throw new Error('Invalid bind joint count');
  if (!rig.triangles?.length || rig.triangles.length % 3 || rig.sampleTriangles?.length !== SAMPLE_COUNT || rig.sampleBarycentric?.length !== SAMPLE_COUNT * 3) throw new Error('Invalid hand sample/topology counts');
  for (let i = 0; i < n; i++) if (!Number.isFinite(rig.bindVertices[i]) || !Number.isFinite(rig.bindNormals[i])) throw new Error('Non-finite bind surface');
  for (let i = 0; i < rig.vertexJointWeights.length; i++) {
    const weight = rig.vertexJointWeights[i], joint = rig.vertexJointIndices[i];
    if (!Number.isFinite(weight) || weight < 0) throw new Error('Invalid skin weight');
    if (!Number.isInteger(joint) || joint < 0 || joint >= JOINT_COUNT) throw new Error('Invalid skin joint index');
    if (joint === 0 && weight > 0) throw new Error('WebXR rig must not weight the unmeasured palm');
  }
  for (const index of rig.triangles) if (!Number.isInteger(index) || index < 0 || index >= rig.vertexCount) throw new Error('Invalid triangle vertex');
  for (let i = 0; i < SAMPLE_COUNT; i++) {
    const t = rig.sampleTriangles[i], b = i * 3;
    if (!Number.isInteger(t) || t < 0 || t >= rig.triangles.length / 3) throw new Error('Invalid sample triangle');
    let sum = 0;
    for (let j = 0; j < 3; j++) { const value = rig.sampleBarycentric[b + j]; if (!Number.isFinite(value) || value < 0 || value > 1) throw new Error('Invalid barycentric weight'); sum += value; }
    if (Math.abs(sum - 1) > .001) throw new Error('Barycentric weights must sum to one');
  }
  for (let j = 0; j < JOINT_COUNT; j++) {
    const s = j * 4, kind = rig.bindJointSources[s];
    if (kind === 0) { if (rig.bindJointSources[s + 1] >= COMPACT_ROWS.length) throw new Error('Invalid compact joint source'); }
    else if (kind === 1) { if (rig.bindJointSources[s + 2] >= 5 || rig.bindJointSources[s + 3] >= COMPACT_ROWS.length) throw new Error('Invalid tip joint source'); }
    else throw new Error('Invalid bind source kind');
  }
}

/** All output buffers and inverse-bind influence vectors are allocated once. */
export function createHandState(rig) {
  validateRig(rig);
  const bind = bindMatrices(rig.bindJointPoses);
  const state = { rig, valid: false, positions: new Float32Array(rig.vertexCount * 3), normals: new Float32Array(rig.vertexCount * 3), origins: new Float32Array(SAMPLE_COUNT * 3), tangents: new Float32Array(SAMPLE_COUNT * 3), bitangents: new Float32Array(SAMPLE_COUNT * 3), anchorNormals: new Float32Array(SAMPLE_COUNT * 3),
    localPositions: new Float32Array(rig.vertexCount * 12), localNormals: new Float32Array(rig.vertexCount * 12), normalizedWeights: new Float32Array(rig.vertexCount * 4), currentMatrices: new Float32Array(JOINT_COUNT * 16) };
  for (let v = 0; v < rig.vertexCount; v++) {
    const p = v * 3, influence = v * 4;
    let sum = 0;
    for (let j = 0; j < 4; j++) sum += rig.vertexJointWeights[influence + j];
    for (let j = 0; j < 4; j++) {
      const i = influence + j, m = rig.vertexJointIndices[i] * 16, b = i * 3;
      state.normalizedWeights[i] = sum > 0 ? rig.vertexJointWeights[i] / sum : 0;
      const x = rig.bindVertices[p] - bind[m + 12], y = rig.bindVertices[p + 1] - bind[m + 13], z = rig.bindVertices[p + 2] - bind[m + 14];
      const nx = rig.bindNormals[p], ny = rig.bindNormals[p + 1], nz = rig.bindNormals[p + 2];
      for (let axis = 0; axis < 3; axis++) {
        const c = m + axis * 4;
        state.localPositions[b + axis] = bind[c] * x + bind[c + 1] * y + bind[c + 2] * z;
        state.localNormals[b + axis] = bind[c] * nx + bind[c + 1] * ny + bind[c + 2] * nz;
      }
    }
  }
  return state;
}

function usableMatrix(values, b) {
  for (let j = 0; j < 16; j++) if (!Number.isFinite(values[b + j])) return false;
  if (Math.abs(values[b + 3]) > .001 || Math.abs(values[b + 7]) > .001 || Math.abs(values[b + 11]) > .001 || Math.abs(values[b + 15] - 1) > .001) return false;
  for (let c = 0; c < 3; c++) {
    const d = b + c * 4;
    if (Math.abs(values[d] ** 2 + values[d + 1] ** 2 + values[d + 2] ** 2 - 1) > .003) return false;
    for (let e = c + 1; e < 3; e++) if (Math.abs(values[d] * values[b + e * 4] + values[d + 1] * values[b + e * 4 + 1] + values[d + 2] * values[b + e * 4 + 2]) > .003) return false;
  }
  const determinant = values[b] * (values[b + 5] * values[b + 10] - values[b + 9] * values[b + 6]) - values[b + 4] * (values[b + 1] * values[b + 10] - values[b + 9] * values[b + 2]) + values[b + 8] * (values[b + 1] * values[b + 6] - values[b + 5] * values[b + 2]);
  return Math.abs(determinant - 1) < .003;
}

function normalized(target, b, x, y, z, fx, fy, fz) {
  const squared = x * x + y * y + z * z;
  if (!Number.isFinite(squared) || squared <= EPSILON) { target[b] = fx; target[b + 1] = fy; target[b + 2] = fz; }
  else { const inv = 1 / Math.sqrt(squared); target[b] = x * inv; target[b + 1] = y * inv; target[b + 2] = z * inv; }
}

/** Skin raw world poses in one common scene basis, then evaluate pinned samples. */
export function updateHand(state, jointMatrices) {
  state.valid = false;
  if (!(jointMatrices instanceof Float32Array) || jointMatrices.length !== JOINT_COUNT * 16) return false;
  for (let j = 1; j < JOINT_COUNT; j++) if (!usableMatrix(jointMatrices, j * 16)) return false;
  const { rig, currentMatrices: matrices } = state;
  for (let j = 0; j < JOINT_COUNT; j++) {
    const source = j * 4, b = j * 16, kind = rig.bindJointSources[source];
    const row = COMPACT_ROWS[rig.bindJointSources[source + (kind === 0 ? 1 : 3)]], m = row * 16;
    for (let k = 0; k < 16; k++) matrices[b + k] = jointMatrices[m + k];
    if (kind === 1) {
      const tip = TIP_ROWS[rig.bindJointSources[source + 2]] * 16;
      const length = Math.hypot(jointMatrices[tip + 12] - jointMatrices[m + 12], jointMatrices[tip + 13] - jointMatrices[m + 13], jointMatrices[tip + 14] - jointMatrices[m + 14]);
      matrices[b + 12] -= matrices[b + 8] * length; matrices[b + 13] -= matrices[b + 9] * length; matrices[b + 14] -= matrices[b + 10] * length;
    }
  }
  for (let v = 0; v < rig.vertexCount; v++) {
    let px = 0, py = 0, pz = 0, nx = 0, ny = 0, nz = 0, total = 0;
    const influence = v * 4, p = v * 3;
    for (let j = 0; j < 4; j++) {
      const i = influence + j, weight = state.normalizedWeights[i];
      if (weight <= 0) continue;
      const m = rig.vertexJointIndices[i] * 16, b = i * 3;
      const x = state.localPositions[b], y = state.localPositions[b + 1], z = state.localPositions[b + 2];
      const a = state.localNormals[b], c = state.localNormals[b + 1], d = state.localNormals[b + 2];
      px += (matrices[m] * x + matrices[m + 4] * y + matrices[m + 8] * z + matrices[m + 12]) * weight;
      py += (matrices[m + 1] * x + matrices[m + 5] * y + matrices[m + 9] * z + matrices[m + 13]) * weight;
      pz += (matrices[m + 2] * x + matrices[m + 6] * y + matrices[m + 10] * z + matrices[m + 14]) * weight;
      nx += (matrices[m] * a + matrices[m + 4] * c + matrices[m + 8] * d) * weight;
      ny += (matrices[m + 1] * a + matrices[m + 5] * c + matrices[m + 9] * d) * weight;
      nz += (matrices[m + 2] * a + matrices[m + 6] * c + matrices[m + 10] * d) * weight;
      total += weight;
    }
    normalized(state.normals, p, rig.bindNormals[p], rig.bindNormals[p + 1], rig.bindNormals[p + 2], 0, 0, 1);
    if (total > 0) { state.positions[p] = px / total; state.positions[p + 1] = py / total; state.positions[p + 2] = pz / total; normalized(state.normals, p, nx, ny, nz, state.normals[p], state.normals[p + 1], state.normals[p + 2]); }
    else { state.positions[p] = rig.bindVertices[p]; state.positions[p + 1] = rig.bindVertices[p + 1]; state.positions[p + 2] = rig.bindVertices[p + 2]; }
    if (!Number.isFinite(state.positions[p]) || !Number.isFinite(state.positions[p + 1]) || !Number.isFinite(state.positions[p + 2])) return false;
  }
  sampleSurface(state);
  state.valid = true;
  return true;
}

function sampleSurface(state) {
  const { rig, positions: p, normals: n, tangents: t, bitangents: b, anchorNormals: normal, origins } = state;
  for (let i = 0; i < SAMPLE_COUNT; i++) {
    const s = i * 3, tri = rig.sampleTriangles[i] * 3, a = rig.triangles[tri] * 3, c = rig.triangles[tri + 1] * 3, d = rig.triangles[tri + 2] * 3;
    const wa = rig.sampleBarycentric[s], wb = rig.sampleBarycentric[s + 1], wc = rig.sampleBarycentric[s + 2];
    for (let axis = 0; axis < 3; axis++) origins[s + axis] = p[a + axis] * wa + p[c + axis] * wb + p[d + axis] * wc;
    const abx = p[c] - p[a], aby = p[c + 1] - p[a + 1], abz = p[c + 2] - p[a + 2], acx = p[d] - p[a], acy = p[d + 1] - p[a + 1], acz = p[d + 2] - p[a + 2];
    normalized(t, s, abx, aby, abz, 1, 0, 0);
    normalized(normal, s, aby * acz - abz * acy, abz * acx - abx * acz, abx * acy - aby * acx, 0, 0, 1);
    normalized(normal, s, n[a] * wa + n[c] * wb + n[d] * wc, n[a + 1] * wa + n[c + 1] * wb + n[d + 1] * wc, n[a + 2] * wa + n[c + 2] * wb + n[d + 2] * wc, normal[s], normal[s + 1], normal[s + 2]);
    normalized(b, s, normal[s + 1] * t[s + 2] - normal[s + 2] * t[s + 1], normal[s + 2] * t[s] - normal[s] * t[s + 2], normal[s] * t[s + 1] - normal[s + 1] * t[s], 0, 1, 0);
  }
}

/** A failed locate poisons the buffer, so a later update cannot reuse stale poses. */
export function readWebXrJoints(xrFrame, inputSource, referenceSpace, target) {
  if (!(target instanceof Float32Array) || target.length !== JOINT_COUNT * 16) return false;
  target.fill(NaN);
  if (!xrFrame?.getJointPose || !inputSource?.hand || !referenceSpace || (inputSource.handedness !== 'left' && inputSource.handedness !== 'right')) return false;
  try {
    for (let j = 0; j < WEBXR_JOINT_NAMES.length; j++) {
      const joint = inputSource.hand.get(WEBXR_JOINT_NAMES[j]);
      const pose = joint && xrFrame.getJointPose(joint, referenceSpace), p = pose?.transform?.position, q = pose?.transform?.orientation;
      if (!p || !q || !writePose(target, (j + 1) * 16, p.x, p.y, p.z, q.x, q.y, q.z, q.w)) { target.fill(NaN); return false; }
    }
    // The rig has no positive palm weights. WebXR supplies wrist, not palm.
    for (let i = 0; i < 16; i++) target[i] = target[16 + i];
    return true;
  } catch { target.fill(NaN); return false; }
}

function makePreviewLocals(bind) {
  const local = new Float32Array(JOINT_COUNT * 16);
  for (let j = 2; j < JOINT_COUNT; j++) {
    const b = j * 16, p = PARENTS[j] * 16;
    for (let column = 0; column < 3; column++) for (let axis = 0; axis < 3; axis++) {
      const r = p + axis * 4, c = b + column * 4;
      local[c + axis] = bind[r] * bind[c] + bind[r + 1] * bind[c + 1] + bind[r + 2] * bind[c + 2];
    }
    for (let axis = 0; axis < 3; axis++) { const r = p + axis * 4; local[b + 12 + axis] = bind[r] * (bind[b + 12] - bind[p + 12]) + bind[r + 1] * (bind[b + 13] - bind[p + 13]) + bind[r + 2] * (bind[b + 14] - bind[p + 14]); }
    local[b + 15] = 1;
  }
  return local;
}

/** Explicit desktop preview only; the caller owns the visible synthetic-mode label. */
export function syntheticJoints(rig, time, side = rig.side, target = new Float32Array(JOINT_COUNT * 16)) {
  checkSide(side);
  if (side !== rig.side || !Number.isFinite(time) || !(target instanceof Float32Array) || target.length !== JOINT_COUNT * 16) throw new Error('Invalid synthetic hand input');
  const sign = side === 'left' ? 1 : -1, bind = rig.bindJointMatrices, local = rig.previewLocalMatrices;
  // Bind fingers extend along ±X, while the palm spans X–Z. Roll makes the
  // fingers upright; yaw presents the palm, and pitch aims it toward the viewer.
  const roll = sign * Math.PI / 2 + .08 * Math.sin(time * .7), yaw = -Math.PI / 2 + .16 * Math.sin(time * .43), pitch = -.65 + .06 * Math.sin(time * .55);
  const cr = Math.cos(roll), sr = Math.sin(roll), cy = Math.cos(yaw), sy = Math.sin(yaw), cp = Math.cos(pitch), sp = Math.sin(pitch), wrist = 16;
  const r00 = cy * cr, r01 = -cy * sr, r02 = sy;
  const r10 = cp * sr + sp * sy * cr, r11 = cp * cr - sp * sy * sr, r12 = -sp * cy;
  const r20 = sp * sr - cp * sy * cr, r21 = sp * cr + cp * sy * sr, r22 = cp * cy;
  for (let column = 0; column < 3; column++) {
    const b = wrist + column * 4, x = bind[b], y = bind[b + 1], z = bind[b + 2];
    target[b] = r00 * x + r01 * y + r02 * z; target[b + 1] = r10 * x + r11 * y + r12 * z; target[b + 2] = r20 * x + r21 * y + r22 * z; target[b + 3] = 0;
  }
  target[wrist + 12] = -sign * .18 + .012 * Math.sin(time * .6); target[wrist + 13] = 1.15 + .015 * Math.sin(time * .8); target[wrist + 14] = -.47 + .015 * Math.cos(time * .5); target[wrist + 15] = 1;
  for (let k = 0; k < 16; k++) target[k] = target[wrist + k];
  const closure = .5 - .5 * Math.cos(time * .65);
  for (let j = 2; j < JOINT_COUNT; j++) {
    const b = j * 16, p = PARENTS[j] * 16;
    const finger = j < 6 ? 0 : Math.floor((j - 6) / 5) + 1;
    const isRoot = j === 2 || j === 6 || j === 11 || j === 16 || j === 21;
    const isTip = j === 5 || j === 10 || j === 15 || j === 20 || j === 25;
    const flex = isRoot || isTip ? 0 : .72 * closure * (.95 + finger * .015);
    const c = Math.cos(flex), s = Math.sin(flex);
    for (let axis = 0; axis < 3; axis++) {
      const px = target[p + axis], py = target[p + 4 + axis], pz = target[p + 8 + axis];
      target[b + axis] = px * local[b] + py * local[b + 1] + pz * local[b + 2];
      target[b + 4 + axis] = px * (local[b + 4] * c + local[b + 8] * s) + py * (local[b + 5] * c + local[b + 9] * s) + pz * (local[b + 6] * c + local[b + 10] * s);
      target[b + 8 + axis] = px * (local[b + 8] * c - local[b + 4] * s) + py * (local[b + 9] * c - local[b + 5] * s) + pz * (local[b + 10] * c - local[b + 6] * s);
      target[b + 12 + axis] = px * local[b + 12] + py * local[b + 13] + pz * local[b + 14] + target[p + 12 + axis];
    }
    target[b + 3] = 0; target[b + 7] = 0; target[b + 11] = 0; target[b + 15] = 1;
  }
  return target;
}
