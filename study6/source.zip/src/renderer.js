import * as THREE from 'three';
import { movementGlsl } from './dynamics/index.js';

const vertexShader = `
uniform sampler2D uPhases;
uniform int uPhaseWidth;
uniform float uDynamic;
uniform float uElapsed;
uniform float uDisplacement;
uniform float uHalfSize;
uniform vec3 uNoise;
attribute vec3 aOrigin;
attribute vec3 aTangent;
attribute vec3 aBitangent;
attribute vec3 aNormal;
attribute float aIndex;
varying vec2 vUv;
varying vec4 vColor;
vec3 stimulusSrgbToLinear(vec3 encoded) {
  return mix(pow((encoded + .055) / 1.055,vec3(2.4)),encoded / 12.92,lessThanEqual(encoded,vec3(.04045)));
}
${movementGlsl}
void main() {
  vec3 center = aOrigin;
  vColor = vec4(1.0);
  if (uDynamic > .5) {
    int id = int(aIndex);
    vec3 phases = texelFetch(uPhases, ivec2(id % uPhaseWidth, id / uPhaseWidth), 0).xyz;
    vec3 driver = stimulusDriver(phases);
    vec3 offset = driver * uDisplacement + stimulusNoise(driver, uElapsed, uNoise);
    center += aTangent * offset.x + aBitangent * offset.y + aNormal * offset.z;
    vec3 encoded=floor(clamp(.5 + .5 * driver, 0.0, 1.0)*255.0+.5)/255.0;
    vColor = vec4(stimulusSrgbToLinear(encoded),235.0/255.0);
  }
  vec4 viewCenter = modelViewMatrix * vec4(center, 1.0);
  viewCenter.xy += position.xy * uHalfSize;
  gl_Position = projectionMatrix * viewCenter;
  vUv = uv;
}
`;
const fragmentShader = `
out vec4 stimulusColor;
#define gl_FragColor stimulusColor
uniform sampler2D uMask;
varying vec2 vUv;
varying vec4 vColor;
void main() {
  float coverage = texture(uMask, vUv).r;
  if (coverage < (1.0 / 255.0)) discard;
  gl_FragColor = vec4(vColor.rgb, coverage * vColor.a);
  #include <colorspace_fragment>
}
`;

export function makeMask(bytes) {
  const texture = new THREE.DataTexture(bytes,512,512,THREE.RedFormat,THREE.UnsignedByteType);
  texture.minFilter = texture.magFilter = THREE.LinearFilter;
  texture.wrapS = texture.wrapT = THREE.ClampToEdgeWrapping;
  texture.colorSpace = THREE.NoColorSpace;
  texture.generateMipmaps = false;
  texture.unpackAlignment = 1;
  texture.needsUpdate = true;
  return texture;
}
export class ParticleCloud {
  constructor(frames, engine, mask, halfSize) {
    this.frames = frames;
    this.engine = engine;
    const geometry = new THREE.InstancedBufferGeometry();
    geometry.setAttribute('position',new THREE.Float32BufferAttribute([-1,-1,0,1,-1,0,1,1,0,-1,1,0],3));
    geometry.setAttribute('uv',new THREE.Float32BufferAttribute([0,0,1,0,1,1,0,1],2));
    geometry.setIndex([0,1,2,0,2,3]);
    for (const [name,values] of [['aOrigin',frames.origins],['aTangent',frames.tangents],['aBitangent',frames.bitangents],['aNormal',frames.anchorNormals]]) {
      geometry.setAttribute(name,new THREE.InstancedBufferAttribute(values,3).setUsage(THREE.DynamicDrawUsage));
    }
    const count = frames.origins.length/3;
    geometry.setAttribute('aIndex',new THREE.InstancedBufferAttribute(Float32Array.from({length:count},(_,i)=>i),1));
    geometry.instanceCount = count;
    this.material = new THREE.ShaderMaterial({
      glslVersion:THREE.GLSL3,vertexShader,fragmentShader,transparent:true,depthWrite:true,
      depthTest:true,depthFunc:THREE.LessEqualDepth,toneMapped:false,
      uniforms:{uPhases:{value:engine.phaseTexture},uPhaseWidth:{value:engine.textureSize},uMask:{value:mask},uDynamic:{value:1},uElapsed:{value:0},uDisplacement:{value:0},uHalfSize:{value:halfSize},uNoise:{value:new THREE.Vector3()}}
    });
    this.mesh = new THREE.Mesh(geometry,this.material);
    this.mesh.frustumCulled = false;
  }
  update(dynamic, anchorsChanged=true) {
    const p=this.engine.parameters,u=this.material.uniforms;
    u.uPhases.value=this.engine.phaseTexture;
    u.uPhaseWidth.value=this.engine.textureSize;
    u.uElapsed.value=this.engine.elapsed;
    u.uDynamic.value=dynamic ? 1 : 0;
    u.uDisplacement.value=p.displacementScaleMeters;
    u.uNoise.value.set(p.noiseFrequency,p.noiseAmplitudeMeters,p.noiseSpeedHz);
    if(anchorsChanged) for(const name of ['aOrigin','aTangent','aBitangent','aNormal']) this.mesh.geometry.attributes[name].needsUpdate=true;
  }
  dispose(){this.mesh.geometry.dispose();this.material.dispose();}
}
