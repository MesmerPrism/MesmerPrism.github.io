const variants = new Set(['DHS', 'SHD']);
const conditions = new Set(['LC_LE', 'LC_HE', 'HC_LE', 'HC_HE']);
const inputs = new Set(['preview', 'live']);
export function parseSettings(value = {}) {
  for (const key of Object.keys(value)) if (!['variant','condition','input'].includes(key)) throw new Error('Unsupported setting: ' + key);
  const result = { variant:'DHS', condition:'HC_HE', input:'preview', ...value };
  if (!variants.has(result.variant)) throw new Error('Invalid variant');
  if (!conditions.has(result.condition)) throw new Error('Invalid condition');
  if (!inputs.has(result.input)) throw new Error('Invalid input');
  return result;
}
export class FrameClock {
  constructor() { this.last = null; this.paused = false; }
  setPaused(paused) { if (this.paused !== paused) this.last = null; this.paused = paused; }
  reset() { this.last = null; }
  tick(milliseconds) {
    if (!Number.isFinite(milliseconds)) return 0;
    const previous = this.last;
    this.last = milliseconds;
    if (this.paused || previous === null) return 0;
    return Math.min(.05, Math.max(0, (milliseconds - previous) / 1000));
  }
}
export function shouldRecenter(center, head) {
  return Math.hypot(center[0]-head[0], center[1]-head[1], center[2]-head[2]) > .3;
}

export function placeSphere(center, orientation, head, heading, captureHeading) {
  center.set(head);
  if (captureHeading) orientation.set(heading);
}

export class HandConfiguration {
  constructor() { this.invalidate(); }
  invalidate() { this.pending={left:true,right:true}; }
  ready(side) { return this.pending[side]===false; }
  capture(side, valid, apply) {
    if (!valid || !this.pending[side]) return false;
    apply();
    this.pending[side]=false;
    return true;
  }
}
