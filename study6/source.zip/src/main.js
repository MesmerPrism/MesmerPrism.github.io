import * as THREE from 'three';
import {loadHandRig,createHandState,updateHand,syntheticJoints,readWebXrJoints} from './hands/index.js';
import {loadStimulusAssets,GpuOscillators} from './dynamics/index.js';
import {ParticleCloud,makeMask} from './renderer.js';
import {FrameClock,parseSettings,shouldRecenter,placeSphere,HandConfiguration} from './session.js';
import './style.css';

const el=id=>document.getElementById(id);
const canvas=el('stimulus'), stage=el('stage'), loading=el('loading');
const clock=new FrameClock();
const handConfiguration=new HandConfiguration();
let settings=parseSettings(), userPaused=false, supportedXR=false, activeSession=null;
let renderer,scene,camera,assets,handStates,engines,clouds,mask;
let initialized=false,failed=false,frames=0,lastStatus=0,frameCost=0,modeBeforeVR='preview',sphereCaptured=false;
const sphereCenter=new Float32Array([0,1.6,0]), head=new Float32Array(3);
const sphereOrientation=new Float32Array([0,0,0,1]);
const headOrientation=new THREE.Quaternion();
const inputMatrices={left:new Float32Array(26*16),right:new Float32Array(26*16)};
const yawPitch={yaw:0,pitch:-.35};
function status(message){el('input-status').textContent=message;}
function fatal(error){
  failed=true;
  console.error(error);
  loading.hidden=false;loading.textContent=error.message || String(error);
  stage.classList.add('fatal');
  el('render-status').textContent='Rendering stopped';
  for(const control of document.querySelectorAll('button,select'))control.disabled=true;
}
function resetMotion(){
  if(!initialized)return;
  handConfiguration.invalidate();
  engines.sphere.reset(settings.condition,assets.sphere.positions);
  clock.reset();
}
function updatePause(){
  const sessionHidden=activeSession && activeSession.visibilityState!=='visible';
  clock.setPaused(userPaused || document.hidden || Boolean(sessionHidden));
}
function configure(){
  settings=parseSettings({variant:el('variant').value,condition:el('coherence').value+'_'+el('energy').value,input:el('input').value});
  resetMotion();
}
function recenter(captureHeading){
  placeSphere(sphereCenter,sphereOrientation,head,headOrientation.toArray(),captureHeading);
  clouds.sphere.mesh.position.fromArray(sphereCenter);
  clouds.sphere.mesh.quaternion.fromArray(sphereOrientation);sphereCaptured=true;
}
function resize(){
  if(!renderer || renderer.xr.isPresenting)return;
  const width=stage.clientWidth,height=stage.clientHeight;
  renderer.setSize(width,height,false);camera.aspect=width/height;camera.updateProjectionMatrix();
}
function getHead(frame){
  if(renderer.xr.isPresenting && frame){
    const pose=frame.getViewerPose(renderer.xr.getReferenceSpace());
    if(!pose)return false;
    const p=pose.transform.position,q=pose.transform.orientation;
    head[0]=p.x;head[1]=p.y;head[2]=p.z;
    headOrientation.set(q.x,q.y,q.z,q.w);
  }else{
    camera.getWorldPosition(temporaryPosition);head[0]=temporaryPosition.x;head[1]=temporaryPosition.y;head[2]=temporaryPosition.z;
    headOrientation.copy(camera.quaternion);
  }
  return true;
}
const temporaryPosition=new THREE.Vector3();
function updateHands(frame,time){
  const visible={left:false,right:false};
  if(settings.input==='preview' && !renderer.xr.isPresenting){
    for(const side of ['left','right']){
      syntheticJoints(handStates[side].rig,time/1000,side,inputMatrices[side]);
      visible[side]=updateHand(handStates[side],inputMatrices[side]);
    }
  }else if(frame && activeSession){
    const space=renderer.xr.getReferenceSpace();
    for(const input of activeSession.inputSources){
      if(input.hand && (input.handedness==='left'||input.handedness==='right')){
        const side=input.handedness;
        visible[side]=readWebXrJoints(frame,input,space,inputMatrices[side]) && updateHand(handStates[side],inputMatrices[side]);
      }
    }
  }
  for(const side of ['left','right']){handStates[side].valid=visible[side];clouds[side].mesh.visible=visible[side];}
  return visible;
}
function animate(time,frame){
  if(!initialized)return;
  const start=performance.now();
  try{
    updatePause();
    const hasHead=getHead(frame);
    const visible=updateHands(frame,time);
    for(const side of ['left','right'])handConfiguration.capture(side,visible[side],()=>engines[side].reset(settings.condition,handStates[side].origins));
    if(hasHead && !sphereCaptured)recenter(true);
    else if(hasHead && shouldRecenter(sphereCenter,head))recenter(false);
    const dt=clock.tick(time);
    if(dt>0 && hasHead){
      if(settings.variant==='DHS'){
        for(const side of ['left','right'])if(visible[side]&&handConfiguration.ready(side))engines[side].step(dt);
      }else engines.sphere.step(dt);
    }
    for(const side of ['left','right'])clouds[side].update(settings.variant==='DHS',visible[side]);
    clouds.sphere.update(settings.variant==='SHD',false);
    renderer.render(scene,camera);
    frames++;frameCost=performance.now()-start;
    if(time-lastStatus>200){
      if(renderer.xr.isPresenting){
        const tracked=Number(visible.left)+Number(visible.right);
        status('Live WebXR hands · '+tracked+'/2 tracked'+(tracked<2?' · missing hands hidden':''));
      }else if(settings.input==='preview')status('Synthetic preview · not live hand tracking');
      else status('Live hands selected · enter VR to track your hands');
      el('render-status').textContent='4,610 particles · '+settings.variant+' · '+settings.condition+(userPaused?' · motion paused':'');
      lastStatus=time;
    }
  }catch(error){renderer.setAnimationLoop(null);fatal(error);}
}
async function enterVR(){
  if(activeSession){await activeSession.end();return;}
  el('enter-vr').disabled=true;
  modeBeforeVR=settings.input;
  let requested;
  try{
    requested=await navigator.xr.requestSession('immersive-vr',{requiredFeatures:['local-floor','hand-tracking']});
    requested.addEventListener('end',()=>{
      activeSession=null;settings.input=modeBeforeVR;el('input').value=modeBeforeVR;
      el('input').disabled=failed;el('enter-vr').textContent='Enter VR';
      sphereCaptured=false;clock.reset();updatePause();resize();
      resetMotion();
    },{once:true});
    requested.addEventListener('visibilitychange',updatePause);
    activeSession=requested;settings.input='live';el('input').value='live';el('input').disabled=true;
    await renderer.xr.setSession(requested);
    resetMotion();
    renderer.xr.getReferenceSpace()?.addEventListener('reset',()=>{sphereCaptured=false;resetMotion();});
    el('enter-vr').textContent='Exit VR';sphereCaptured=false;clock.reset();
  }catch(error){
    if(requested)await requested.end().catch(()=>{});
    activeSession=null;
    settings.input=modeBeforeVR;el('input').value=modeBeforeVR;el('input').disabled=failed;
    status('VR could not start: '+(error.message || error));
  }finally{el('enter-vr').disabled=failed||!supportedXR;}
}
async function init(){
  if(!globalThis.isSecureContext || !globalThis.crypto?.subtle)throw new Error('Open the stimulus over HTTPS or localhost. A plain HTTP network address cannot access WebXR.');
  renderer=new THREE.WebGLRenderer({canvas,antialias:true,alpha:false,powerPreference:'high-performance'});
  renderer.setClearColor(0x000000,1);renderer.setPixelRatio(Math.min(devicePixelRatio,1.75));
  renderer.outputColorSpace=THREE.SRGBColorSpace;renderer.toneMapping=THREE.NoToneMapping;
  renderer.xr.enabled=true;renderer.xr.setReferenceSpaceType('local-floor');
  renderer.debug.onShaderError=(gl,program,vertex,fragment)=>{
    window.__study6ShaderError=[gl.getProgramInfoLog(program),gl.getShaderInfoLog(vertex),gl.getShaderInfoLog(fragment)];
    console.error(...window.__study6ShaderError);
    throw new Error('A particle shader could not compile. Check WebGL2 support.');
  };
  scene=new THREE.Scene();camera=new THREE.PerspectiveCamera(70,1,.01,10);
  camera.position.set(0,1.6,0);
  camera.quaternion.setFromEuler(new THREE.Euler(yawPitch.pitch,yawPitch.yaw,0,'YXZ'));
  const [left,right,stimulus]=await Promise.all([loadHandRig('left',{baseUrl:new URL('assets/hands/',document.baseURI).href}),loadHandRig('right',{baseUrl:new URL('assets/hands/',document.baseURI).href}),loadStimulusAssets({baseUrl:new URL('assets/particles/',document.baseURI).href})]);
  assets=stimulus;handStates={left:createHandState(left),right:createHandState(right)};
  for(const side of ['left','right']){
    syntheticJoints(handStates[side].rig,0,side,inputMatrices[side]);
    updateHand(handStates[side],inputMatrices[side]);
  }
  engines={};
  for(const side of ['left','right'])engines[side]=new GpuOscillators(renderer,assets.graphs[side],handStates[side].origins,settings.condition);
  engines.sphere=new GpuOscillators(renderer,assets.graphs.sphere,assets.sphere.positions,settings.condition);
  mask=makeMask(assets.mask);
  const sphereFrames={origins:assets.sphere.positions,tangents:assets.sphere.tangents,bitangents:assets.sphere.bitangents,anchorNormals:assets.sphere.normals};
  clouds={left:new ParticleCloud(handStates.left,engines.left,mask,.0015),right:new ParticleCloud(handStates.right,engines.right,mask,.0015),sphere:new ParticleCloud(sphereFrames,engines.sphere,mask,.00375)};
  for(const cloud of Object.values(clouds))scene.add(cloud.mesh);
  for(const id of ['variant','coherence','energy','input'])el(id).addEventListener('change',configure);
  el('pause').addEventListener('click',()=>{
    userPaused=!userPaused;el('pause').setAttribute('aria-pressed',String(userPaused));
    el('pause').textContent=userPaused?'Resume motion':'Pause motion';updatePause();
  });
  el('reset').addEventListener('click',resetMotion);el('recenter').addEventListener('click',()=>{sphereCaptured=false;});
  el('enter-vr').addEventListener('click',()=>{void enterVR();});
  el('fullscreen').addEventListener('click',async()=>{
    try{if(document.fullscreenElement)await document.exitFullscreen();else await stage.requestFullscreen();}
    catch(error){status('Fullscreen unavailable: '+error.message);}
  });
  let pointer=null;
  canvas.addEventListener('pointerdown',event=>{pointer={x:event.clientX,y:event.clientY};canvas.setPointerCapture(event.pointerId);});
  canvas.addEventListener('pointermove',event=>{
    if(!pointer||renderer.xr.isPresenting)return;
    yawPitch.yaw-=(event.clientX-pointer.x)*.003;yawPitch.pitch-= (event.clientY-pointer.y)*.003;
    yawPitch.pitch=Math.max(-1.3,Math.min(1.3,yawPitch.pitch));
    camera.quaternion.setFromEuler(new THREE.Euler(yawPitch.pitch,yawPitch.yaw,0,'YXZ'));
    pointer.x=event.clientX;pointer.y=event.clientY;
  });
  canvas.addEventListener('pointerup',()=>{pointer=null;});canvas.addEventListener('pointercancel',()=>{pointer=null;});
  new ResizeObserver(resize).observe(stage);
  document.addEventListener('fullscreenchange',()=>{resize();el('fullscreen').textContent=document.fullscreenElement?'Exit fullscreen':'Fullscreen';});document.addEventListener('visibilitychange',updatePause);
  canvas.addEventListener('webglcontextlost',event=>{
    event.preventDefault();renderer.setAnimationLoop(null);void activeSession?.end().catch(()=>{});
    fatal(new Error('Graphics context lost. Reload this page to restart the stimulus.'));
  });
  initialized=true;loading.hidden=true;resize();
  for(const control of document.querySelectorAll('.controls select,.actions button'))control.disabled=false;
  renderer.setAnimationLoop(animate);
  try{supportedXR=Boolean(navigator.xr && await navigator.xr.isSessionSupported('immersive-vr'));}
  catch{supportedXR=false;}
  el('enter-vr').disabled=failed||!supportedXR;el('enter-vr').textContent=supportedXR?'Enter VR':'VR unavailable here';
  if(new URLSearchParams(location.search).has('debug'))window.__study6={
    renderer,engines,handStates,clouds,assets,three:{WebGLRenderTarget:THREE.WebGLRenderTarget,BufferGeometry:THREE.BufferGeometry,Float32BufferAttribute:THREE.Float32BufferAttribute,RawShaderMaterial:THREE.RawShaderMaterial,Scene:THREE.Scene,Mesh:THREE.Mesh,Camera:THREE.Camera,PerspectiveCamera:THREE.PerspectiveCamera,DataTexture:THREE.DataTexture,FloatType:THREE.FloatType,UnsignedByteType:THREE.UnsignedByteType,RGBAFormat:THREE.RGBAFormat,RedFormat:THREE.RedFormat,GLSL3:THREE.GLSL3,NoBlending:THREE.NoBlending},
    snapshot:()=>({frames,frameCost,settings:{...settings},paused:userPaused,particles:4610,leftVisible:clouds.left.mesh.visible,rightVisible:clouds.right.mesh.visible,inputStatus:el('input-status').textContent}),
    resetMotion
  };
}
init().catch(fatal);
