import { validateGraph } from './cpu.js';

const HAND_COUNT = 1024;
const SPHERE_COUNT = 2562;
const f = Math.fround;
const MAX_DISTANCE = f(.025);
const TIER1_DISTANCE = f(MAX_DISTANCE / 3);
const TIER2_DISTANCE = f(f(MAX_DISTANCE * 2) / 3);

function flatten(adjacency) {
  const offsets = new Uint32Array(adjacency.length + 1);
  for (let i = 0; i < adjacency.length; i++) offsets[i + 1] = offsets[i] + adjacency[i].length;
  const indices = new Uint32Array(offsets.at(-1));
  const weights = new Float32Array(indices.length);
  for (let i = 0; i < adjacency.length; i++) {
    adjacency[i].forEach(([target, weight], edge) => {
      indices[offsets[i] + edge] = target;
      weights[offsets[i] + edge] = weight;
    });
  }
  return validateGraph({ count: adjacency.length, offsets, indices, weights });
}

function handGraph(edgeBuffer, distanceBuffer, expectedEdges) {
  const edges = uints(edgeBuffer), distances = floats(distanceBuffer);
  if (distances.length !== expectedEdges || edges.length !== expectedEdges * 2) throw new Error('Hand graph asset shape mismatch');
  const adjacency = Array.from({ length: HAND_COUNT }, () => []);
  for (let i = 0; i < distances.length; i++) {
    const from = edges[i * 2], to = edges[i * 2 + 1], distance = distances[i];
    if (from >= HAND_COUNT || to >= HAND_COUNT || !Number.isFinite(distance) || distance < 0) throw new Error('Invalid hand graph edge');
    if (distance > MAX_DISTANCE) continue;
    adjacency[from].push([to, distance <= TIER1_DISTANCE ? .5 : distance <= TIER2_DISTANCE ? .3 : .1]);
  }
  return flatten(adjacency);
}

function sphereGraph() {
  let vertexCount = 12;
  let faces = [[0,11,5],[0,5,1],[0,1,7],[0,7,10],[0,10,11],[1,5,9],[5,11,4],[11,10,2],[10,7,6],[7,1,8],[3,9,4],[3,4,2],[3,2,6],[3,6,8],[3,8,9],[4,9,5],[2,4,11],[6,2,10],[8,6,7],[9,8,1]];
  for (let level = 0; level < 4; level++) {
    const midpoints = new Map();
    const midpoint = (a, b) => {
      const key = `${Math.min(a,b)},${Math.max(a,b)}`;
      if (!midpoints.has(key)) midpoints.set(key, vertexCount++);
      return midpoints.get(key);
    };
    const next = [];
    for (const [a,b,c] of faces) {
      const ab = midpoint(a,b), bc = midpoint(b,c), ca = midpoint(c,a);
      next.push([a,ab,ca], [b,bc,ab], [c,ca,bc], [ab,bc,ca]);
    }
    faces = next;
  }
  if (vertexCount !== SPHERE_COUNT || faces.length !== 5120) throw new Error('Sphere topology mismatch');
  const neighbors = Array.from({length:vertexCount}, () => new Set());
  for (const [a,b,c] of faces) {
    neighbors[a].add(b).add(c);
    neighbors[b].add(a).add(c);
    neighbors[c].add(a).add(b);
  }
  const tier1 = neighbors.map((set, i) => {
    if (set.size !== (i < 12 ? 5 : 6)) throw new Error('Sphere vertex degree mismatch');
    return [...set].sort((a,b) => a-b);
  });
  const adjacency = tier1.map((_, i) => {
    const visited = new Set([i]);
    let ring = [i];
    const result = [];
    for (const weight of [.5,.3,.1]) {
      const next = new Set();
      for (const node of ring) for (const target of tier1[node]) {
        if (!visited.has(target)) { visited.add(target); next.add(target); }
      }
      ring = [...next].sort((a,b) => a-b);
      for (const target of ring) result.push([target,weight]);
    }
    return result;
  });
  return flatten(adjacency);
}

function floats(buffer) {
  if (buffer.byteLength % 4) throw new Error('Invalid float asset length');
  const view = new DataView(buffer);
  return Float32Array.from({length:buffer.byteLength / 4}, (_,i) => view.getFloat32(i*4,true));
}
function uints(buffer) {
  if (buffer.byteLength % 4) throw new Error('Invalid integer asset length');
  const view = new DataView(buffer);
  return Uint32Array.from({length:buffer.byteLength / 4}, (_,i) => view.getUint32(i*4,true));
}
function sphereFrames(positionBuffer, normalBuffer) {
  const positions4 = floats(positionBuffer), normals4 = floats(normalBuffer);
  if (positions4.length !== SPHERE_COUNT * 4 || normals4.length !== positions4.length) throw new Error('Sphere asset shape mismatch');
  const positions = new Float32Array(SPHERE_COUNT * 3), normals = new Float32Array(positions.length);
  const tangents = new Float32Array(positions.length), bitangents = new Float32Array(positions.length);
  for (let i = 0; i < SPHERE_COUNT; i++) {
    const p = i*4, at = i*3;
    const px = positions4[p], py = positions4[p+1], pz = positions4[p+2];
    if (Math.abs(Math.hypot(px,py,pz)-1) >= .00001 || Math.abs(positions4[p+3]-.012) >= .000001 || Math.abs(normals4[p+3]-1) >= .000001) throw new Error('Invalid sphere coordinate');
    positions.set([px,py,pz],at);
    const length = Math.hypot(normals4[p],normals4[p+1],normals4[p+2]);
    if (!Number.isFinite(length) || length < 1e-8) throw new Error('Invalid sphere normal');
    const x = normals4[p]/length, y = normals4[p+1]/length, z = normals4[p+2]/length;
    normals.set([x,y,z],at);
    // Native basis: helper Y unless the normal is too close to Y; then X.
    let tx,ty,tz;
    if (Math.abs(y) < .92) { tx=z; ty=0; tz=-x; } else { tx=0; ty=-z; tz=y; }
    const tlen = Math.hypot(tx,ty,tz); tx/=tlen; ty/=tlen; tz/=tlen;
    tangents.set([tx,ty,tz],at);
    bitangents.set([y*tz-z*ty,z*tx-x*tz,x*ty-y*tx],at);
  }
  return {positions,normals,tangents,bitangents};
}

export async function loadStimulusAssets({baseUrl='/assets/particles/', fetch=globalThis.fetch} = {}) {
  if (typeof fetch !== 'function') throw new Error('An asset fetch function is required');
  const names = ['icosphere-l4-positions.f32.bin','icosphere-l4-normals.f32.bin','left-surface-distance-edges.u32.bin','left-surface-distance-meters.f32.bin','right-surface-distance-edges.u32.bin','right-surface-distance-meters.f32.bin','particle-mask-512.r8.bin'];
  const buffers = await Promise.all(names.map(async name => {
    const url = baseUrl instanceof URL ? new URL(name,baseUrl) : `${String(baseUrl).replace(/\/?$/, '/')}${name}`;
    const response = await fetch(url);
    if (!response.ok) throw new Error(`Failed to load particle asset: ${name}`);
    return response.arrayBuffer();
  }));
  const mask = new Uint8Array(buffers[6]);
  if (mask.length !== 512*512) throw new Error('Particle mask shape mismatch');
  return {
    sphere:sphereFrames(buffers[0],buffers[1]),
    graphs:{left:handGraph(buffers[2],buffers[3],98510),right:handGraph(buffers[4],buffers[5],99592),sphere:sphereGraph()},
    mask,
  };
}
