import * as THREE from 'three';
import { DEFAULT_SEED, initialPhases, naturalFrequencies, makeCondition, validateGraph, validateParameters } from './cpu.js';

const vertexShader = /* glsl */`
precision highp float;
in vec3 position;
void main() { gl_Position = vec4(position,1.0); }
`;
// Each fragment integrates all three independent oscillator components from the
// same immutable source texture; only the completed target is exposed to draws.
const fragmentShader = /* glsl */`
precision highp float;
precision highp int;
uniform highp sampler2D phaseSource;
uniform highp sampler2D frequencies;
uniform highp sampler2D ranges;
uniform highp sampler2D edges;
uniform int phaseWidth;
uniform int edgeTextureSize;
uniform int particleCount;
uniform float deltaSeconds;
uniform float coupling;
out vec4 result;
ivec2 coordinate(int index, int width) { return ivec2(index % width,index / width); }
void main() {
  ivec2 pixel = ivec2(gl_FragCoord.xy);
  int index = pixel.y * phaseWidth + pixel.x;
  if (index >= particleCount) { result=vec4(0.0,0.0,0.0,1.0); return; }
  vec3 prior = texelFetch(phaseSource,pixel,0).xyz;
  vec3 frequency = texelFetch(frequencies,pixel,0).xyz;
  vec3 weightedSum=vec3(0.0);
  float activeCount=0.0;
  if (coupling != 0.0) {
    vec2 range = texelFetch(ranges,pixel,0).xy;
    for (int e=int(range.x);e<int(range.y);e++) {
      vec2 edge = texelFetch(edges,coordinate(e,edgeTextureSize),0).xy;
      if (edge.y != 0.0) {
        vec3 neighbor = texelFetch(phaseSource,coordinate(int(edge.x),phaseWidth),0).xyz;
        weightedSum += edge.y * sin(neighbor-prior);
        activeCount += 1.0;
      }
    }
  }
  vec3 pull = activeCount == 0.0 ? vec3(0.0) : weightedSum / activeCount;
  vec3 next = prior + (frequency + coupling * 16.0 * pull) * deltaSeconds;
  next -= floor(next / 6.283185307179586) * 6.283185307179586;
  result=vec4(next,1.0);
}
`;

function dataTexture(data, size) {
  const texture = new THREE.DataTexture(data,size,size,THREE.RGBAFormat,THREE.FloatType);
  texture.minFilter=texture.magFilter=THREE.NearestFilter;
  texture.generateMipmaps=false;
  texture.colorSpace=THREE.NoColorSpace;
  texture.needsUpdate=true;
  return texture;
}
function packRows(rows,size) {
  const result = new Float32Array(size*size*4);
  for (let i=0;i<rows.length/3;i++) {
    result.set(rows.subarray(i*3,i*3+3),i*4);
    result[i*4+3]=1;
  }
  return result;
}

export class GpuOscillators {
  constructor(renderer,graph,origins,condition,seed=DEFAULT_SEED) {
    if (!renderer?.capabilities?.isWebGL2) throw new Error('WebGL2 is required for GPU oscillators');
    if (!renderer.extensions.has('EXT_color_buffer_float')) throw new Error('EXT_color_buffer_float is required for GPU oscillators');
    condition=typeof condition === 'string' ? makeCondition(condition) : condition;
    validateGraph(graph);
    validateParameters(condition);
    if (origins.length !== graph.count*3) throw new Error('Origin count does not match graph');
    this.renderer=renderer;
    this.graph=graph;
    this.textureSize=Math.ceil(Math.sqrt(graph.count));
    this.edgeTextureSize=Math.max(1,Math.ceil(Math.sqrt(graph.indices.length)));
    if (Math.max(this.textureSize,this.edgeTextureSize)>renderer.capabilities.maxTextureSize) throw new Error('Particle graph exceeds GPU texture limits');
    const rangeRows=new Float32Array(this.textureSize*this.textureSize*4);
    for (let i=0;i<graph.count;i++) rangeRows.set([graph.offsets[i],graph.offsets[i+1]],i*4);
    const edgeRows=new Float32Array(this.edgeTextureSize*this.edgeTextureSize*4);
    for (let i=0;i<graph.indices.length;i++) edgeRows.set([graph.indices[i],graph.weights[i]],i*4);
    this.rangeTexture=dataTexture(rangeRows,this.textureSize);
    this.edgeTexture=dataTexture(edgeRows,this.edgeTextureSize);
    this.targets=[0,1].map(() => new THREE.WebGLRenderTarget(this.textureSize,this.textureSize,{
      format:THREE.RGBAFormat,type:THREE.FloatType,internalFormat:'RGBA32F',
      minFilter:THREE.NearestFilter,magFilter:THREE.NearestFilter,
      depthBuffer:false,stencilBuffer:false,generateMipmaps:false,
    }));
    this.material=new THREE.RawShaderMaterial({
      glslVersion:THREE.GLSL3,vertexShader,fragmentShader,depthTest:false,depthWrite:false,blending:THREE.NoBlending,
      uniforms:{phaseSource:{value:null},frequencies:{value:null},ranges:{value:this.rangeTexture},edges:{value:this.edgeTexture},phaseWidth:{value:this.textureSize},edgeTextureSize:{value:this.edgeTextureSize},particleCount:{value:graph.count},deltaSeconds:{value:0},coupling:{value:condition.movementCoupling}},
    });
    this.geometry=new THREE.BufferGeometry();
    this.geometry.setAttribute('position',new THREE.Float32BufferAttribute([-1,-1,0,3,-1,0,-1,3,0],3));
    this.mesh=new THREE.Mesh(this.geometry,this.material);
    this.mesh.frustumCulled=false;
    this.scene=new THREE.Scene();
    this.scene.add(this.mesh);
    this.camera=new THREE.Camera();
    this.disposed=false;
    this.reset(condition,origins,seed);
  }

  get phaseTexture() { return this._phaseTexture; }
  get size() { return this.textureSize; }

  reset(condition,origins,seed=DEFAULT_SEED) {
    if (this.disposed) throw new Error('Oscillators have been disposed');
    condition=typeof condition === 'string' ? makeCondition(condition) : condition;
    validateParameters(condition);
    if (origins.length !== this.graph.count*3) throw new Error('Origin count does not match graph');
    // Frequencies are captured once for this reset, rather than resampled as a
    // tracked hand moves. This is also the native engine configuration boundary.
    const frequencies=naturalFrequencies(origins,condition);
    const phases=initialPhases(this.graph.count,seed);
    this.initialTexture?.dispose();
    this.frequencyTexture?.dispose();
    this.initialTexture=dataTexture(packRows(phases,this.textureSize),this.textureSize);
    this.frequencyTexture=dataTexture(packRows(frequencies,this.textureSize),this.textureSize);
    this.parameters=Object.freeze({...condition});
    this.material.uniforms.frequencies.value=this.frequencyTexture;
    this.material.uniforms.coupling.value=condition.movementCoupling;
    this._phaseTexture=this.initialTexture;
    this._currentTarget=null;
    this._writeIndex=0;
    this.elapsed=0;
    return this;
  }

  step(dt) {
    if (this.disposed) throw new Error('Oscillators have been disposed');
    if (!Number.isFinite(dt)||dt<=0) throw new Error('Delta time must be finite and positive');
    const renderer=this.renderer;
    const previousTarget=renderer.getRenderTarget();
    const previousFace=renderer.getActiveCubeFace();
    const previousMip=renderer.getActiveMipmapLevel();
    const autoClear=renderer.autoClear;
    const xrEnabled=renderer.xr.enabled;
    const target=this.targets[this._writeIndex];
    try {
      renderer.xr.enabled=false;
      renderer.autoClear=false;
      // setRenderTarget applies this target's physical-pixel viewport and scissor.
      // setViewport would incorrectly multiply these dimensions by canvas DPR.
      renderer.setRenderTarget(target);
      this.material.uniforms.phaseSource.value=this._phaseTexture;
      this.material.uniforms.deltaSeconds.value=Math.fround(dt);
      renderer.render(this.scene,this.camera);
    } finally {
      renderer.setRenderTarget(previousTarget,previousFace,previousMip);
      renderer.autoClear=autoClear;
      renderer.xr.enabled=xrEnabled;
    }
    this._phaseTexture=target.texture;
    this._currentTarget=target;
    this._writeIndex=1-this._writeIndex;
    this.elapsed=Math.fround(this.elapsed+Math.fround(dt));
    return this;
  }

  // Explicit diagnostic readback; never used by step or the production renderer.
  readPhases() {
    if (this.disposed) throw new Error('Oscillators have been disposed');
    const rows=this._currentTarget ? new Float32Array(this.textureSize*this.textureSize*4) : this.initialTexture.image.data;
    if (this._currentTarget) {
      const xrEnabled=this.renderer.xr.enabled;
      try {
        this.renderer.xr.enabled=false;
        // Three restores the currently bound framebuffer in its readback finally.
        this.renderer.readRenderTargetPixels(this._currentTarget,0,0,this.textureSize,this.textureSize,rows);
      } finally { this.renderer.xr.enabled=xrEnabled; }
    }
    const phases=new Float32Array(this.graph.count*3);
    for (let i=0;i<this.graph.count;i++) phases.set(rows.subarray(i*4,i*4+3),i*3);
    return phases;
  }

  dispose() {
    if (this.disposed) return;
    this.disposed=true;
    this.initialTexture.dispose();
    this.frequencyTexture.dispose();
    this.rangeTexture.dispose();
    this.edgeTexture.dispose();
    this.targets.forEach(target => target.dispose());
    this.material.dispose();
    this.geometry.dispose();
  }
}
