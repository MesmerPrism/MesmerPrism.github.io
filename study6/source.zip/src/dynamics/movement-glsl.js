// Shared with the particle vertex material. All offsets are local-frame meters.
export const movementGlsl = /* glsl */`
vec3 stimulusLimit(vec3 value) {
  float lengthSquared = dot(value, value);
  return lengthSquared > 1.0 ? value * inversesqrt(lengthSquared) : value;
}
vec3 stimulusDriver(vec3 phases) {
  return stimulusLimit(sin(phases));
}
uint stimulusHash(uint seed, ivec3 cell) {
  uint value = seed ^ (uint(cell.x) * 0x8da6b343u) ^ (uint(cell.y) * 0xd8163841u) ^ (uint(cell.z) * 0xcb1ab31fu);
  value = (value ^ (value >> 16u)) * 0x7feb352du;
  value = (value ^ (value >> 15u)) * 0x846ca68bu;
  return value ^ (value >> 16u);
}
float stimulusGrad(uint hash, vec3 p) {
  uint h = hash & 15u;
  if (h == 0u || h == 12u) return p.x + p.y;
  if (h == 1u || h == 13u) return -p.x + p.y;
  if (h == 2u) return p.x - p.y;
  if (h == 3u) return -p.x - p.y;
  if (h == 4u) return p.x + p.z;
  if (h == 5u) return -p.x + p.z;
  if (h == 6u) return p.x - p.z;
  if (h == 7u) return -p.x - p.z;
  if (h == 8u) return p.y + p.z;
  if (h == 9u) return -p.y + p.z;
  if (h == 10u || h == 14u) return p.y - p.z;
  return -p.y - p.z;
}
float stimulusLerp(float a, float b, float t) { return a + (b - a) * t; }
float stimulusPerlin(uint seed, vec3 p) {
  ivec3 cell = ivec3(floor(p));
  vec3 q = p - vec3(cell);
  vec3 fade = q*q*q*(q*(q*6.0-15.0)+10.0);
  float x00 = stimulusLerp(stimulusGrad(stimulusHash(seed,cell),q),stimulusGrad(stimulusHash(seed,cell+ivec3(1,0,0)),q-vec3(1,0,0)),fade.x);
  float x10 = stimulusLerp(stimulusGrad(stimulusHash(seed,cell+ivec3(0,1,0)),q-vec3(0,1,0)),stimulusGrad(stimulusHash(seed,cell+ivec3(1,1,0)),q-vec3(1,1,0)),fade.x);
  float x01 = stimulusLerp(stimulusGrad(stimulusHash(seed,cell+ivec3(0,0,1)),q-vec3(0,0,1)),stimulusGrad(stimulusHash(seed,cell+ivec3(1,0,1)),q-vec3(1,0,1)),fade.x);
  float x11 = stimulusLerp(stimulusGrad(stimulusHash(seed,cell+ivec3(0,1,1)),q-vec3(0,1,1)),stimulusGrad(stimulusHash(seed,cell+ivec3(1,1,1)),q-vec3(1,1,1)),fade.x);
  return clamp(stimulusLerp(stimulusLerp(x00,x10,fade.y),stimulusLerp(x01,x11,fade.y),fade.z),-1.0,1.0);
}
// settings = (spatial frequency, amplitude in meters, temporal speed in Hz).
vec3 stimulusNoise(vec3 driver, float elapsed, vec3 settings) {
  if (settings.x <= 0.0 || settings.y <= 0.0) return vec3(0.0);
  float phase = elapsed * settings.z * 6.283185307179586;
  vec3 temporal = vec3(sin(phase)*0.47*4.0,sin(phase*1.37)*0.31*4.0,sin(phase*0.73)*0.59*4.0);
  vec3 p = driver * settings.x + temporal;
  vec3 noise = vec3(stimulusPerlin(0x234a712fu,p),stimulusPerlin(0x9e3779b9u,p+vec3(19.17,-37.43,11.29)),stimulusPerlin(0xd1b54a32u,p+vec3(-53.71,7.31,29.53)));
  return stimulusLimit(noise) * settings.y;
}
`;
