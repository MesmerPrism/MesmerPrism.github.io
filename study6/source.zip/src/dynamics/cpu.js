// Study 6 same-axis oscillator reference. Float rounding follows the native
// Kotlin Float setup; the phase update always reads a complete prior snapshot.
export const TAU = Math.fround(2 * Math.PI);
export const DEFAULT_SEED = 0x9e3779b9de569c14n;
const f = Math.fround;
const add = (a, b) => f(a + b);
const sub = (a, b) => f(a - b);
const mul = (a, b) => f(a * b);

export function makeCondition(token) {
  if (!['LC_LE', 'LC_HE', 'HC_LE', 'HC_HE'].includes(token)) throw new Error(`Unknown condition: ${token}`);
  const highEnergy = token.endsWith('HE');
  const highCoherence = token.startsWith('HC');
  return Object.freeze({
    baseFrequencyHz: f(highEnergy ? .88 : .44),
    frequencySpreadHz: f(highCoherence ? .03 : .62),
    movementCoupling: highCoherence ? 1 : 0,
    displacementScaleMeters: f(highEnergy ? .004 : .002),
    noiseFrequency: f(highEnergy ? 6.7 : 0),
    noiseAmplitudeMeters: f(highEnergy ? .004 : 0),
    noiseSpeedHz: highEnergy ? .5 : 0,
  });
}

export function validateParameters(parameters) {
  const allowed = ['baseFrequencyHz', 'frequencySpreadHz', 'movementCoupling', 'displacementScaleMeters', 'noiseFrequency', 'noiseAmplitudeMeters', 'noiseSpeedHz'];
  if (!parameters || Object.keys(parameters).some(key => !allowed.includes(key)) || allowed.some(key => !Number.isFinite(parameters[key]) || parameters[key] < 0)) {
    throw new Error('Unsupported oscillator parameters');
  }
  return parameters;
}

export function initialPhases(count, seed = DEFAULT_SEED) {
  if (!Number.isInteger(count) || count <= 0) throw new Error('Particle count must be positive');
  if (typeof seed === 'number' && !Number.isSafeInteger(seed)) throw new Error('Seed must be an exact integer');
  let state = BigInt.asUintN(64, BigInt(seed));
  const phases = new Float32Array(count * 3);
  for (let i = 0; i < phases.length; i++) {
    state = BigInt.asUintN(64, state * 6364136223846793005n + 1442695040888963407n);
    phases[i] = mul(Number(state >> 40n) / 16777216, TAU);
  }
  return phases;
}

function hash3(seed, x, y, z) {
  let value = seed ^ Math.imul(x, 0x8da6b343) ^ Math.imul(y, 0xd8163841) ^ Math.imul(z, 0xcb1ab31f);
  value = Math.imul(value ^ (value >>> 16), 0x7feb352d);
  value = Math.imul(value ^ (value >>> 15), 0x846ca68b);
  return value ^ (value >>> 16);
}
function grad(hash, x, y, z) {
  switch (hash & 15) {
    case 0: case 12: return add(x, y);
    case 1: case 13: return add(-x, y);
    case 2: return sub(x, y);
    case 3: return sub(-x, y);
    case 4: return add(x, z);
    case 5: return add(-x, z);
    case 6: return sub(x, z);
    case 7: return sub(-x, z);
    case 8: return add(y, z);
    case 9: return add(-y, z);
    case 10: case 14: return sub(y, z);
    default: return sub(-y, z);
  }
}
const fade = value => mul(mul(mul(value, value), value), add(mul(value, sub(mul(value, 6), 15)), 10));
const lerp = (left, right, t) => add(left, mul(sub(right, left), t));

export function perlinSample(seed, positionX, positionY, positionZ) {
  const ix = Math.floor(positionX), iy = Math.floor(positionY), iz = Math.floor(positionZ);
  const x = sub(positionX, ix), y = sub(positionY, iy), z = sub(positionZ, iz);
  const u = fade(x), v = fade(y), w = fade(z);
  const at = (dx, dy, dz) => grad(hash3(seed, ix + dx, iy + dy, iz + dz), sub(x, dx), sub(y, dy), sub(z, dz));
  const x00 = lerp(at(0, 0, 0), at(1, 0, 0), u);
  const x10 = lerp(at(0, 1, 0), at(1, 1, 0), u);
  const x01 = lerp(at(0, 0, 1), at(1, 0, 1), u);
  const x11 = lerp(at(0, 1, 1), at(1, 1, 1), u);
  return Math.max(-1, Math.min(1, lerp(lerp(x00, x10, v), lerp(x01, x11, v), w)));
}

export function naturalFrequencies(origins, parameters) {
  validateParameters(parameters);
  if (!origins || origins.length === 0 || origins.length % 3 !== 0 || !origins.every(Number.isFinite)) throw new Error('Invalid xyz origins');
  const seeds = [0x4f3a9b21, 0xb7c15d83, 0x29e46f5d];
  const result = new Float32Array(origins.length);
  for (let i = 0; i < origins.length; i += 3) {
    for (let axis = 0; axis < 3; axis++) {
      const noise = perlinSample(seeds[axis], mul(origins[i], 18), mul(origins[i + 1], 18), mul(origins[i + 2], 18));
      result[i + axis] = mul(Math.max(0, add(parameters.baseFrequencyHz, mul(parameters.frequencySpreadHz, noise))), TAU);
    }
  }
  return result;
}

export function validateGraph(graph) {
  if (!graph || !Number.isInteger(graph.count) || graph.count <= 0 || graph.offsets?.length !== graph.count + 1 || graph.indices?.length !== graph.weights?.length || graph.offsets[0] !== 0 || graph.offsets[graph.count] !== graph.indices.length) throw new Error('Invalid particle graph shape');
  for (let i = 0; i < graph.count; i++) if (graph.offsets[i] > graph.offsets[i + 1]) throw new Error('Invalid graph range');
  for (let i = 0; i < graph.indices.length; i++) if (!Number.isInteger(graph.indices[i]) || graph.indices[i] >= graph.count || graph.indices[i] < 0 || !Number.isFinite(graph.weights[i])) throw new Error('Invalid graph edge');
  return graph;
}

export function stepPhases(source, frequencies, graph, parameters, dt, output = new Float32Array(source.length)) {
  validateGraph(graph);
  validateParameters(parameters);
  if (!Number.isFinite(dt) || dt <= 0) throw new Error('Delta time must be finite and positive');
  if (source.length !== graph.count * 3 || frequencies.length !== source.length || output.length !== source.length || !source.every(Number.isFinite) || !frequencies.every(Number.isFinite)) throw new Error('Invalid phase/frequency rows');
  // Any overlapping view needs a snapshot, including shifted views of one buffer.
  const prior = source.buffer === output.buffer ? source.slice() : source;
  const delta = f(dt);
  for (let coordinate = 0; coordinate < graph.count; coordinate++) {
    for (let axis = 0; axis < 3; axis++) {
      const index = coordinate * 3 + axis;
      const own = prior[index];
      let weightedSum = 0, activeCount = 0;
      if (parameters.movementCoupling !== 0) {
        for (let e = graph.offsets[coordinate]; e < graph.offsets[coordinate + 1]; e++) {
          const weight = graph.weights[e];
          if (weight !== 0) {
            weightedSum = add(weightedSum, mul(weight, f(Math.sin(sub(prior[graph.indices[e] * 3 + axis], own)))));
            activeCount++;
          }
        }
      }
      const pull = activeCount ? f(weightedSum / activeCount) : 0;
      const derivative = add(frequencies[index], mul(mul(parameters.movementCoupling, 16), pull));
      const value = add(own, mul(derivative, delta));
      output[index] = sub(value, mul(Math.floor(f(value / TAU)), TAU));
    }
  }
  return output;
}
