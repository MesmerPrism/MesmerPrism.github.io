await page.addInitScript(()=>{
  Object.defineProperty(navigator,'xr',{configurable:true,value:{
    isSessionSupported:async()=>true,
    requestSession:()=>new Promise((resolve,reject)=>{window.__rejectPendingXr=reject;})
  }});
});
await page.goto('http://127.0.0.1:5176/study6/?debug=1');
await page.waitForFunction(()=>window.__study6?.snapshot().frames>5 && !document.getElementById('enter-vr').disabled);
await page.getByRole('button',{name:'Enter VR',exact:true}).click();
await page.evaluate(()=>window.__study6.renderer.getContext().getExtension('WEBGL_lose_context').loseContext());
await page.waitForFunction(()=>document.querySelector('.fatal'));
await page.evaluate(()=>window.__rejectPendingXr(new Error('Test: request rejected after graphics loss')));
await page.waitForFunction(()=>document.getElementById('input-status').textContent.startsWith('VR could not start:'));
const state=await page.evaluate(()=>({
  allDisabled:Array.from(document.querySelectorAll('button,select')).every(el=>el.disabled),
  inputDisabled:document.getElementById('input').disabled,
  vrDisabled:document.getElementById('enter-vr').disabled,
  message:document.getElementById('loading').textContent
}));
if(!state.allDisabled)throw new Error('Fatal graphics state re-enabled controls: '+JSON.stringify(state));
await writeArtifact('context-loss-check.json',new TextEncoder().encode(JSON.stringify(state,null,2)),'application/json');
return state;
