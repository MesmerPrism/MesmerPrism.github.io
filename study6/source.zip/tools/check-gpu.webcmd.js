await page.goto('http://127.0.0.1:5176/?debug=1');
await page.waitForFunction(()=>window.__study6?.snapshot().frames>5);
const checks=await page.evaluate(async()=>{
  const d=await import('/src/dynamics/index.js'),{ParticleCloud}=await import('/src/renderer.js');
  const {renderer,three:T}=window.__study6, previous=renderer.getRenderTarget(),xr=renderer.xr.enabled;
  renderer.xr.enabled=false;
  const target=new T.WebGLRenderTarget(3,1,{type:T.FloatType,format:T.RGBAFormat,internalFormat:'RGBA32F',depthBuffer:false});
  const geometry=new T.BufferGeometry();
  geometry.setAttribute('position',new T.Float32BufferAttribute([-1,-1,0,3,-1,0,-1,3,0],3));
  const fragment='precision highp float;precision highp int;out vec4 result;'+d.movementGlsl+'void main(){vec3 driver=stimulusDriver(vec3(.3,1.1,2.6));int i=int(gl_FragCoord.x);if(i==0)result=vec4(driver,1.0);else if(i==1)result=vec4(stimulusNoise(driver,1.25,vec3(6.7,.004,.5)),1.0);else result=vec4(stimulusPerlin(0x234a712fu,vec3(.31,-1.27,2.53)),stimulusPerlin(0x9e3779b9u,vec3(-3.1,.75,.22)),stimulusPerlin(0xd1b54a32u,vec3(.4,1.7,-.8)),1.0);}';
  const material=new T.RawShaderMaterial({glslVersion:T.GLSL3,vertexShader:'in vec3 position;void main(){gl_Position=vec4(position,1.0);}',fragmentShader:fragment,depthTest:false,depthWrite:false});
  const scene=new T.Scene(),mesh=new T.Mesh(geometry,material);mesh.frustumCulled=false;scene.add(mesh);
  const values=new Float32Array(12);
  let result;
  try{
    renderer.setRenderTarget(target);renderer.render(scene,new T.Camera());renderer.readRenderTargetPixels(target,0,0,3,1,values);
    const f=Math.fround,mul=(a,b)=>f(a*b),add=(a,b)=>f(a+b),phase=mul(mul(1.25,.5),d.TAU);
    const driver=Array.from(values.slice(0,3));
    const temporal=[mul(mul(f(Math.sin(phase)),f(.47)),4),mul(mul(f(Math.sin(mul(phase,f(1.37)))),f(.31)),4),mul(mul(f(Math.sin(mul(phase,f(.73)))),f(.59)),4)];
    const p=driver.map((v,i)=>add(mul(v,f(6.7)),temporal[i]));
    const sample=[d.perlinSample(0x234a712f,...p),d.perlinSample(0x9e3779b9,add(p[0],f(19.17)),add(p[1],f(-37.43)),add(p[2],f(11.29))),d.perlinSample(0xd1b54a32,add(p[0],f(-53.71)),add(p[1],f(7.31)),add(p[2],f(29.53)))];
    const length=Math.hypot(...sample),expected=sample.map(v=>mul(length>1?v/length:v,f(.004)));
    const noiseError=Math.max(...expected.map((v,i)=>Math.abs(v-values[i+4])));
    const perlin=[d.perlinSample(0x234a712f,f(.31),f(-1.27),f(2.53)),d.perlinSample(0x9e3779b9,f(-3.1),f(.75),f(.22)),d.perlinSample(0xd1b54a32,f(.4),f(1.7),f(-.8))];
    const perlinError=Math.max(...perlin.map((v,i)=>Math.abs(v-values[i+8])));
    const initialDriver=[Math.sin(.3),Math.sin(1.1),Math.sin(2.6)],magnitude=Math.hypot(...initialDriver),expectedDriver=initialDriver.map(v=>magnitude>1?v/magnitude:v);
    const driverError=Math.max(...expectedDriver.map((v,i)=>Math.abs(v-values[i])));
    const phaseTexture=new T.DataTexture(new Float32Array([0,0,0,1]),1,1,T.RGBAFormat,T.FloatType);phaseTexture.needsUpdate=true;
    const mask=new T.DataTexture(new Uint8Array(512*512).fill(255),512,512,T.RedFormat,T.UnsignedByteType);mask.needsUpdate=true;
    const engine={phaseTexture,textureSize:1,elapsed:0,parameters:d.makeCondition('HC_LE')};
    const frames={origins:new Float32Array([0,0,-1]),tangents:new Float32Array([1,0,0]),bitangents:new Float32Array([0,1,0]),anchorNormals:new Float32Array([0,0,1])};
    const cloud=new ParticleCloud(frames,engine,mask,.25);cloud.material.blending=T.NoBlending;cloud.update(true);
    const colorTarget=new T.WebGLRenderTarget(1,1,{type:T.FloatType,format:T.RGBAFormat,internalFormat:'RGBA32F'});
    const colorScene=new T.Scene();colorScene.add(cloud.mesh);
    const camera=new T.PerspectiveCamera(70,1,.1,10),color=new Float32Array(4);
    renderer.setRenderTarget(colorTarget);renderer.render(colorScene,camera);renderer.readRenderTargetPixels(colorTarget,0,0,1,1,color);
    const encoded=128/255,linear=Math.pow((encoded+.055)/1.055,2.4);
    const colorError=Math.max(...Array.from(color.slice(0,3),v=>Math.abs(v-linear)),Math.abs(color[3]-235/255));
    result={driverError,noiseError,perlinError,colorError,colorLinear:Array.from(color),finite:Array.from(values).every(Number.isFinite),glError:renderer.getContext().getError()};
    cloud.dispose();phaseTexture.dispose();mask.dispose();colorTarget.dispose();
  }finally{
    renderer.setRenderTarget(previous);renderer.xr.enabled=xr;target.dispose();geometry.dispose();material.dispose();
  }
  return result;
});
if(!checks.finite||checks.glError!==0||checks.noiseError>1e-6||checks.perlinError>1e-5||checks.driverError>1e-5||checks.colorError>1e-6)throw new Error(JSON.stringify(checks));
await writeArtifact('gpu-noise-color.json',new TextEncoder().encode(JSON.stringify(checks,null,2)),'application/json');
return checks;
