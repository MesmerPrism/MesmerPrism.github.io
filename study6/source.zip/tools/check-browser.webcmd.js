await page.addInitScript(()=>{
  window.__qaErrors=[];
  const original=console.error;
  console.error=(...args)=>{window.__qaErrors.push(args.map(String).join(' '));original.apply(console,args);};
  window.addEventListener('error',event=>window.__qaErrors.push(event.message));
});
await page.setViewportSize({width:1280,height:850});
await page.goto('http://127.0.0.1:5176/?debug=1');
await page.waitForFunction(()=>window.__study6?.snapshot().frames>8 || window.__study6ShaderError,null,{timeout:30000});
const initial=await page.evaluate(()=>window.__study6.snapshot());
const gpu=await page.evaluate(async()=>{
  const d=await import('/src/dynamics/index.js');
  const renderer=window.__study6.renderer;
  const graph={count:2,offsets:new Uint32Array([0,1,2]),indices:new Uint32Array([1,0]),weights:new Float32Array([.5,.3])};
  const origins=new Float32Array([0,0,0,.03,0,0]),p=d.makeCondition('HC_HE');
  const engine=new d.GpuOscillators(renderer,graph,origins,p);
  let cpu=d.initialPhases(2),frequency=d.naturalFrequencies(origins,p);
  const initialGpu=engine.readPhases();
  const initialError=Math.max(...cpu.map((v,i)=>Math.abs(v-initialGpu[i])));
  for(let i=0;i<30;i++){engine.step(1/90);cpu=d.stepPhases(cpu,frequency,graph,p,1/90);}
  const actual=engine.readPhases();
  const maxError=Math.max(...cpu.map((v,i)=>Math.abs(v-actual[i])));
  const finite=Array.from(actual).every(Number.isFinite);
  const restored=renderer.getRenderTarget()===null;
  engine.dispose();
  return {initialError,maxError,finite,renderTargetRestored:restored};
});
await page.getByRole('button',{name:'Pause motion',exact:true}).click();
const pausedA=await page.evaluate(()=>({frame:window.__study6.snapshot().frames,values:Array.from(window.__study6.engines.left.readPhases().slice(0,12))}));
await page.waitForFunction(frame=>window.__study6.snapshot().frames>frame+4,pausedA.frame);
const pausedB=await page.evaluate(()=>Array.from(window.__study6.engines.left.readPhases().slice(0,12)));
const pauseStable=JSON.stringify(pausedA.values)===JSON.stringify(pausedB);
await page.getByRole('button',{name:'Reset motion',exact:true}).click();
const resetFrame=await page.evaluate(()=>window.__study6.snapshot().frames);
await page.waitForFunction(frame=>window.__study6.snapshot().frames>frame+2,resetFrame);
const resetElapsed=await page.evaluate(()=>Object.values(window.__study6.engines).map(e=>e.elapsed));
await page.getByRole('button',{name:'Resume motion',exact:true}).click();
const variants=[];
for(const variant of ['DHS','SHD']){
  for(const condition of ['HC_HE','HC_LE','LC_HE','LC_LE']){
    await page.locator('#variant').selectOption(variant);
    await page.locator('#coherence').selectOption(condition.slice(0,2));
    await page.locator('#energy').selectOption(condition.slice(3));
    const before=await page.evaluate(()=>window.__study6.snapshot().frames);
    await page.waitForFunction(frame=>window.__study6.snapshot().frames>frame+2,before);
    variants.push(await page.evaluate(()=>({state:window.__study6.snapshot().settings,dynamic:Object.values(window.__study6.clouds).map(c=>c.material.uniforms.uDynamic.value)})));
  }
}
await page.locator('#input').selectOption('live');
await page.waitForFunction(()=>!window.__study6.clouds.left.mesh.visible&&!window.__study6.clouds.right.mesh.visible);
const liveHidesMissing=await page.evaluate(()=>!window.__study6.snapshot().leftVisible&&!window.__study6.snapshot().rightVisible);
await page.locator('#input').selectOption('preview');
await page.locator('#variant').selectOption('DHS');
await page.locator('#coherence').selectOption('HC');
await page.locator('#energy').selectOption('HE');
await page.waitForFunction(()=>window.__study6.snapshot().leftVisible&&window.__study6.snapshot().rightVisible);
await page.waitForFunction(()=>document.getElementById('render-status').textContent.includes('DHS · HC_HE'));
await page.screenshot({path:'study6-desktop.png'});
await page.setViewportSize({width:390,height:844});
await page.screenshot({path:'study6-mobile.png'});
const final=await page.evaluate(()=>({state:window.__study6.snapshot(),errors:window.__qaErrors,glError:window.__study6.renderer.getContext().getError(),overflow:document.documentElement.scrollWidth>window.innerWidth,loadingHidden:document.getElementById('loading').hidden,title:document.title,url:location.href}));
if(!pauseStable || resetElapsed.some(value=>value!==0) || !liveHidesMissing || final.errors.length || final.glError || final.overflow || !final.loadingHidden || !gpu.finite || gpu.maxError>1e-4 || gpu.initialError>1e-5 || !gpu.renderTargetRestored) throw new Error(JSON.stringify({gpu,pauseStable,resetElapsed,liveHidesMissing,final}));
for(const item of variants)if(JSON.stringify(item.dynamic)!==JSON.stringify(item.state.variant==='DHS'?[1,1,0]:[0,0,1]))throw new Error('Incorrect particle role: '+JSON.stringify(item));
await writeArtifact('browser-check.json',new TextEncoder().encode(JSON.stringify({initial,gpu,pauseStable,resetElapsed,variants,liveHidesMissing,final},null,2)),'application/json');
return {initial,gpu,pauseStable,resetElapsed,variants,liveHidesMissing,final};
