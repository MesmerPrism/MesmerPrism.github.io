import {createHash} from 'node:crypto';
import {spawnSync} from 'node:child_process';
import {lstat, mkdir, readFile, readdir, realpath, writeFile} from 'node:fs/promises';
import {basename, dirname, isAbsolute, join, relative, resolve, sep} from 'node:path';
import {pathToFileURL} from 'node:url';

const forbidden = /movementCrossAxisCoupling|cross_axis_pull|crossAxisPull|cross_axis_coupling/;
const manifestName = 'export-manifest.json';
const buildRecipe = ['node', 'node_modules/vite/bin/vite.js', 'build'];
const digest = bytes => createHash('sha256').update(bytes).digest('hex');
const portable = path => path.split(sep).join('/');
const within = (parent, child) => {
  const path = relative(parent, child);
  return path === '' || (!isAbsolute(path) && path !== '..' && !path.startsWith(`..${sep}`));
};
function run(command, args, root) {
  const result = spawnSync(command, args, {
    cwd: root, encoding: null, maxBuffer: 128 * 1024 * 1024,
    windowsHide: true, env: {...process.env, GIT_OPTIONAL_LOCKS: '0'}
  });
  if (result.error || result.status !== 0) {
    throw new Error(`${basename(command)} failed (${result.status ?? result.error?.code}): ${result.stderr?.toString().trim() || result.error?.message || ''}`);
  }
  return result.stdout;
}
const git = (root, ...args) => run('git', args, root);
const gitText = (root, ...args) => git(root, ...args).toString('utf8').trim();
async function statOrMissing(path) {
  try { return await lstat(path); }
  catch (error) { if (error.code === 'ENOENT') return undefined; throw error; }
}
async function rejectLinkedAncestors(path) {
  for (let current = path; ; current = dirname(current)) {
    const info = await statOrMissing(current);
    if (info?.isSymbolicLink()) throw new Error('Symlink/reparse destination or input ancestor is not allowed');
    if (info && !info.isDirectory()) throw new Error('Destination or input ancestor must be a directory');
    if (dirname(current) === current) break;
  }
}
async function regularBytes(path, boundary) {
  const info = await lstat(path);
  if (info.isSymbolicLink() || !info.isFile()) throw new Error(`Linked/reparse or non-regular file is not allowed: ${portable(relative(boundary, path))}`);
  const actual = await realpath(path);
  if (!within(boundary, actual) || relative(resolve(path), actual) !== '') throw new Error('Input path escapes its expected directory');
  return readFile(path);
}
async function collectFiles(directory, boundary = directory) {
  const info = await lstat(directory);
  if (info.isSymbolicLink() || !info.isDirectory()) throw new Error('Linked/reparse or non-directory input is not allowed');
  const actual = await realpath(directory);
  if (!within(boundary, actual) || relative(resolve(directory), actual) !== '') throw new Error('Input directory escapes its expected directory');
  const result = [];
  for (const entry of (await readdir(directory)).sort()) {
    const path = join(directory, entry);
    const details = await lstat(path);
    if (details.isDirectory() && !details.isSymbolicLink()) result.push(...await collectFiles(path, boundary));
    else result.push({path: portable(relative(boundary, path)), bytes: await regularBytes(path, boundary)});
  }
  return result;
}
function scanImplementation(files, label) {
  for (const file of files) {
    if (forbidden.test(file.bytes.toString('utf8'))) throw new Error(`Forbidden excluded implementation identifier in ${label}/${file.path}`);
  }
}
function committedState(root) {
  if (gitText(root, 'status', '--porcelain=v1', '--untracked-files=all')) throw new Error('Export requires clean committed source; dirty or untracked files are present');
  return {commit: gitText(root, 'rev-parse', 'HEAD'), tree: gitText(root, 'rev-parse', 'HEAD^{tree}')};
}
function sameState(root, expected) {
  const actual = committedState(root);
  if (actual.commit !== expected.commit || actual.tree !== expected.tree) throw new Error('Committed source changed during the build/export');
}
async function validateDestination(root, destination) {
  if (within(destination, root)) throw new Error('Destination must not be the source root or its ancestor');
  if (destination.split(sep).some(part => part.toLowerCase() === '.git')) throw new Error('Destination must not enter Git metadata');
  if (within(root, destination)) {
    const path = portable(relative(root, destination));
    if (!path.startsWith('local/')) throw new Error('An in-source destination must be beneath ignored local/');
    git(root, 'check-ignore', '--quiet', '--no-index', '--', path);
  }
  await rejectLinkedAncestors(destination);
  const info = await statOrMissing(destination);
  if (info && (await readdir(destination)).length) throw new Error('Destination must be a new or empty directory');
}
function fileRecord(file) {
  return {path: file.path, bytes: file.bytes.length, sha256: digest(file.bytes)};
}

/** Export a clean committed source tree after a successful production build.
 * buildCommand is a Node argv recipe for controlled integrations; the CLI always uses Vite.
 */
export async function exportSite({root = process.cwd(), destination, buildCommand = buildRecipe} = {}) {
  if (typeof destination !== 'string' || !destination) throw new Error('A destination directory is required');
  root = resolve(root);
  await rejectLinkedAncestors(root);
  root = await realpath(root);
  if (relative(root, await realpath(gitText(root, 'rev-parse', '--show-toplevel'))) !== '') throw new Error('Run the exporter from the Git source root');
  destination = resolve(root, destination);
  await validateDestination(root, destination);
  const source = committedState(root);
  const initialBuild = await collectFiles(join(root, 'dist'));
  if (!initialBuild.some(file => file.path === 'index.html')) throw new Error('An existing dist/index.html build is required');
  scanImplementation(await collectFiles(join(root, 'src')), 'src');
  const command = [...buildCommand];
  if (command[0] !== 'node' || command.length < 2 || command.some(arg => typeof arg !== 'string' || isAbsolute(arg) || /[\r\n\0]|^[a-z]:/i.test(arg))) {
    throw new Error('Build command must be a portable Node argv recipe without absolute paths');
  }
  try { run(process.execPath, command.slice(1), root); }
  catch (error) { throw new Error(`Production build failed: ${error.message}`); }
  sameState(root, source);
  scanImplementation(await collectFiles(join(root, 'src')), 'src');
  const files = await collectFiles(join(root, 'dist'));
  if (!files.some(file => file.path === 'index.html')) throw new Error('Completed build must contain dist/index.html');
  scanImplementation(files.filter(file => /\.(?:js|mjs|cjs)$/i.test(file.path)), 'dist');
  for (const path of ['LICENSE.txt', 'NOTICE.md', 'source.zip', manifestName]) {
    if (files.some(file => file.path === path || file.path.startsWith(path + '/'))) throw new Error(`Build output collides with reserved export file: ${path}`);
  }
  for (const path of ['LICENSE.txt', 'NOTICE.md']) files.push({path, bytes: await regularBytes(join(root, path), root)});
  files.push({path: 'source.zip', bytes: git(root, 'archive', '--format=zip', source.commit)});
  files.sort((a, b) => a.path < b.path ? -1 : a.path > b.path ? 1 : 0);
  const manifest = {
    schema_version: 1,
    source: {...source, archive: 'source.zip'},
    build: {command, completed: true},
    same_axis_only: true,
    physical_headset_qualified: false,
    files: files.map(fileRecord)
  };
  sameState(root, source);
  await validateDestination(root, destination);
  // Every input is validated and buffered before the first destination mutation.
  // Exclusive writes preserve a concurrently created file; failures leave reviewable partial output.
  await mkdir(destination, {recursive: true});
  for (const file of files) {
    const path = join(destination, file.path);
    await mkdir(dirname(path), {recursive: true});
    await writeFile(path, file.bytes, {flag: 'wx'});
  }
  await writeFile(join(destination, manifestName), JSON.stringify(manifest, null, 2) + '\n', {flag: 'wx'});
  return manifest;
}

/** Verify the exact file set, sizes and SHA-256 values of an existing export. */
export async function checkExport({directory} = {}) {
  if (typeof directory !== 'string' || !directory) throw new Error('An export directory is required');
  directory = resolve(directory);
  await rejectLinkedAncestors(directory);
  const manifest = JSON.parse(await regularBytes(join(directory, manifestName), directory));
  if (manifest.schema_version !== 1 || manifest.same_axis_only !== true || manifest.physical_headset_qualified !== false || manifest.build?.completed !== true ||
      !/^[0-9a-f]{40,64}$/.test(manifest.source?.commit) || !/^[0-9a-f]{40,64}$/.test(manifest.source?.tree) ||
      manifest.source?.archive !== 'source.zip' || !Array.isArray(manifest.files)) throw new Error('Invalid export manifest');
  const expected = new Map();
  for (const file of manifest.files) {
    if (typeof file.path !== 'string' || file.path === manifestName || file.path.includes('\\') || file.path.split('/').some(part => !part || part === '.' || part === '..') ||
        isAbsolute(file.path) || /^[a-z]:/i.test(file.path) || expected.has(file.path) || !Number.isSafeInteger(file.bytes) || file.bytes < 0 || !/^[0-9a-f]{64}$/.test(file.sha256)) {
      throw new Error('Invalid manifest file list');
    }
    expected.set(file.path, file);
  }
  for (const path of ['index.html', 'source.zip', 'LICENSE.txt', 'NOTICE.md']) if (!expected.has(path)) throw new Error(`Missing required manifest file: ${path}`);
  const actual = (await collectFiles(directory)).filter(file => file.path !== manifestName);
  if (actual.length !== expected.size || actual.some(file => !expected.has(file.path))) throw new Error('Unexpected export file list');
  for (const file of actual) {
    const record = expected.get(file.path);
    if (file.bytes.length !== record.bytes || digest(file.bytes) !== record.sha256) throw new Error(`Export bytes or SHA-256 digest mismatch: ${file.path}`);
  }
  scanImplementation(actual.filter(file => /\.(?:js|mjs|cjs)$/i.test(file.path)), 'export');
  return manifest;
}

async function main(args) {
  if (args.length !== 2 || !['--destination', '--check'].includes(args[0])) throw new Error('Usage: node tools/export-site.mjs --destination <new-or-empty-directory> | --check <existing-export-directory>');
  const manifest = args[0] === '--check' ? await checkExport({directory: args[1]}) : await exportSite({destination: args[1]});
  console.log(`${args[0] === '--check' ? 'Verified' : 'Exported'} ${manifest.files.length} files from ${manifest.source.commit}`);
}
if (process.argv[1] && import.meta.url === pathToFileURL(resolve(process.argv[1])).href) {
  main(process.argv.slice(2)).catch(error => { console.error(error.message); process.exitCode = 1; });
}
