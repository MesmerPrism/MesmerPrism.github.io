# Validation

Validation is limited to the implementation and environments described here. It is not physical headset acceptance.

## Source and numerical checks

Run `npm test`. Tests cover exact runtime SHA-256 values and shapes, bind-pose skinning and pinned sample order, tip reconstruction, WebXR joint-name mapping, invalid/overflow tracking rejection, deterministic synthetic input, synchronous same-axis integration, independent component evolution, deterministic 64-bit phase initialization, native condition constants, graph edge counts, parameter rejection, pause/hidden-time clocks, sphere drift orientation and deferred per-hand configuration capture.

Run `npm run build` to generate the static production directory. No remote build or deployment is involved. The hand, dynamics, lifecycle and public-boundary matrix currently contains 29 passing tests.

## Rendered checks on 5 November 2026

The app was exercised in the local Webcmd desktop Chromium runtime at 1280 by 850 and 390 by 844. The checks used actual WebGL2 draws and GPU readback for diagnostics, not mocked graphics.

The run covered all eight DHS/SHD and condition combinations, correct dynamic/static target selection, exact 4,610-particle composition, pause stability, deterministic reset, hiding missing live hands, restoring explicitly selected synthetic preview, mobile overflow, shader compilation and console/WebGL error state. A two-particle analytic graph matched CPU and GPU initial states and 30 steps at 1/90 second with maximum observed phase difference zero on this runtime. This limited comparison does not imply bitwise agreement on other drivers or long trajectories.

A production build was also opened at the `/study6/` subdirectory with successful asset loading and role changes. A separate regression injects a real WebGL context loss while a simulated XR permission request is pending, then rejects that request; all controls remain disabled after asynchronous cleanup. This checks browser failure handling, not an actual headset session. The regression program is `tools/check-context-loss.webcmd.js`, targeting the production preview at port 5176 and base `/study6/`.

Quantitative shader checks observed maximum driver difference 4.21e-8, movement-noise and Perlin difference zero for the selected samples, and linear colour/alpha difference 1.58e-8. These are selected numerical fixtures on one driver, not a long-run tolerance guarantee. Diagnostic GPU reads are excluded from the production loop.

With the development server running on port 5176, create a Webcmd session and run `tools/check-browser.webcmd.js` and `tools/check-gpu.webcmd.js` through `webcmd --session <session-id> browser run --file <file> --no-snapshot-diff`. Each program opens its own debug URL and throws if the selected checks fail. Screenshots and JSON receipts are returned as Webcmd artifacts. The numeric program requires development module routes; it is not intended for a production-only static server.

## Pending physical qualification

- Actual browser-to-rig live joint alignment on the selected headset.
- Pointer/system gesture interaction, reference-space resets and repeated real session entry/exit.
- Wearer-visible particle size, colour, depth, mask and all stimulus conditions.
- Sustained full-count frame cadence, thermals and tracking interruption behavior on Quest.

Both headsets were in use by another task during this implementation. No headset operation, APK change, device takeover or hardware acceptance claim occurred.
