# Study 6 WebXR Implementation Plan

> For agentic workers: use Superpowers subagent-driven development with meaningful tests, focused review and one writer per module. The three phases below use fresh contexts and bounded GSD-style continuation inside this owner plan.

**Goal:** Deliver the approved browser-only stimulus with same-axis coupling and a usable desktop preview.
**Architecture:** Hand and particle asset modules feed a WebXR scene. A ping-pong GPU phase engine feeds a neutral instanced billboard renderer. Native and other source repositories are read-only references.
**Tech Stack:** JavaScript ES modules, Three.js 0.184.0, WebGL2, Vite, Node test runner.
**Spec:** docs/DESIGN.md

## Global constraints

- Only same-axis neighbor coupling; no cross-axis implementation or configuration.
- 1,024 pinned samples per hand and 2,562 sphere particles, exact runtime assets.
- Native source stays unchanged; no research data, audio, experiments, signing material or private history.
- Synthetic preview is explicitly labeled; live tracking loss never invokes synthetic input.
- One simulation update per frame, independent of stereo eye count.

## Phase 1: Hand surface pipeline

Files: src/hands/*.js, public/assets/hands/*, tests/hands.test.js. Implement loadHandRig(side), createHandState(rig), updateHand(state, jointMatrices), syntheticJoints(rig,time,side), and readWebXrJoints(frame,input,space,target). updateHand fills positions/normals and 1,024 origins/tangents/bitangents/normals in preallocated arrays. Browser joint input is a 26-row Float32Array of column-major 4x4 matrices in one reference space; the unmeasured unused palm row is explicitly derived from wrist.

- [x] Write tests for bind-pose skinning, normalized surface frames, same-frame invalid pose rejection and left/right joint-name mapping; run failing tests.
- [x] Port accepted skinning/sampling and minimal asset loading, then run tests to green.
- [x] Validate exact rig/sample asset counts and hashes; record source provenance.

## Phase 2: Same-axis particle engine

Files: src/dynamics/*.js, public/assets/particles/*, tests/dynamics.test.js. Export loadStimulusAssets(), makeCondition(token), a CPU synchronous phase step, deterministic seeds/frequencies, and GpuOscillators(renderer,graph,origins,condition,seed). Graph rows are offsets/counts plus indices/weights; GpuOscillators exposes step(dt), phaseTexture, elapsed, parameters, reset(condition,origins,seed), dispose(). Supply reusable GLSL driver/noise helpers for the renderer.

- [x] Write tests for an analytic two-oscillator step, axis independence, previous-complete-state updates, deterministic seeds and unsupported configuration rejection; run failing tests.
- [x] Implement the exact same-axis kernel, asset graphs and GPU ping-pong path, then run focused tests.
- [x] Export exact sphere normals/positions, hand graphs and mask; preserve graph order and profile constants.

## Phase 3: XR scene and verification

Files: index.html, src/main.js, src/renderer.js, src/session.js, src/style.css, tests/session.test.js, README.md, NOTICE.md. Root owns these files. Compose live/synthetic hands, DHS/SHD and four conditions. Use the XR frame to locate joints, update skin/anchors and advance GPU state once; render per-eye billboards from current-view matrices. Hide stale live hands. Reset simulation on explicit configuration/reset; recenter sphere after 0.3 m head drift preserving captured orientation.

- [x] Test configuration/lifecycle/clock behavior before implementation.
- [x] Build a compact responsive control surface and real rendering path with explicit input/status states.
- [x] Run unit tests, build and rendered desktop/mobile checks; compare GPU output to the CPU reference on a small seeded graph.
- [x] Review source and dist for excluded material, record asset/source provenance and exact validation limits, and commit the coherent local result.
