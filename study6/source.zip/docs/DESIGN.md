# Study 6 browser stimulus

Approved scope: a browser WebXR stimulus with two tracked particle hands and a particle sphere, DHS/SHD selection, four coherence/energy conditions, pause/reset/recenter, and an explicitly labeled desktop synthetic-hand preview. There is no experiment allocation, questionnaire, physiology or data collection. All three oscillator axes use only same-axis neighbor coupling; cross-axis behavior is absent. The remaining implementation is permitted to be public.

Use a standalone source repository so private native history is excluded. Preserve the native rig and exact 1,024 surface samples per hand, 2,562 sphere vertices, feather mask and original billboard sizes. Browser joints are mapped by name to the rig in one WebXR reference space; do not copy Spatial mirror/origin compensation. Hide missing live hands, with visible tracking status; synthetic input is an explicit preview mode.

The implementation uses Vite, native JavaScript modules and Three.js WebGL2/WebXR. Reuse the existing mesh browser's instanced-quad approach, Hollow Face's XR session lifecycle pattern, and Optics' neutral position/color/size render boundary. Reuse Viscereality's separated GPU state and draw pattern without importing its mixed private shader. GPU phase integration uses complete previous-state ping-pong float textures and same-axis adjacency. A CPU reference validates phase math and determinism. Skinning and pinned sampling use preallocated typed arrays.

The UI is a practical research tool: a black stimulus canvas with a compact neutral toolbar, clear mode/status text, labeled native controls and mobile wrapping. No decorative graphics or overlays in the stimulus. Enter VR requires a secure supported browser. Browser restarts/visibility and tracking loss do not fabricate live input. Stereo draws consume one simulation update per XR frame, with no synchronous GPU readback in the production loop.

Acceptance: numerical same-axis independence and synchronous integration tests, hand bind/surface/sample and invalid-tracking tests, exact asset counts/digests, WebGL GPU/CPU comparison, responsive browser interaction and console health, build and public-boundary checks. Actual live-hand alignment and sustained headset performance remain separately reported until exercised on a headset.

