# Same-axis stimulus dynamics

This module adapts the Study 6 particle core by Till Holzapfel / MesmerPrism. The reference runtime revision is `c5c2d4982bced5aeaf2d312f8fc31acd95134a20`; reference source was read without modification. Numerical source files were `KuramotoDynamics.kt`, `PrivateParticleAssetLoader.kt`, `PackedParticleRender.kt`, and the native oscillator compute shader. Only the approved same-axis neighbor model is implemented here. The standalone project's license and attribution also apply to these adaptations.

For particle `i` and component `a`, one explicit Euler update is:

```text
pull(i,a) = sum(weight(i,j) * sin(previous(j,a)-previous(i,a))) / activeEdgeCount(i)
next(i,a) = wrap(previous(i,a) + dt * (naturalFrequency(i,a) + 16 * movementCoupling * pull(i,a)))
```

An empty active neighborhood has zero pull. All components read the same completed previous state. Weights are `0.5`, `0.3`, `0.1` for the first three neighbor tiers; normalization divides by the number of nonzero edges, preserving the native average. Phase units are radians and frequency setup converts Hz with a float32 value of tau.

`makeCondition(token)` accepts exactly `LC_LE`, `LC_HE`, `HC_LE`, `HC_HE`. Low/high coherence gives frequency spread `0.62`/`0.03` Hz and movement coupling `0`/`1`. Low/high energy gives base frequency `0.44`/`0.88` Hz and displacement scale `0.002`/`0.004` m. High energy adds movement noise with spatial frequency `6.7`, amplitude `0.004` m and speed `0.5` Hz; low energy disables this noise. The returned object contains only the seven documented movement settings.

Initial phase rows use the native 64-bit LCG, implemented with `BigInt` and unsigned 64-bit wrap. Its default state is `0x9e3779b9de569c14`, multiplier `6364136223846793005`, increment `1442695040888963407`; the top 24 bits seed each component in row order. Natural frequencies use the native 32-bit integer hash, gradient field, per-axis seeds and spatial scale `18`. They are sampled from the supplied origins once per reset. Moving tracked anchors does not resample the frequency field.

The movement driver is `sin(phases)` clamped to maximum magnitude one. The noise uses the native gradient hash, temporal offsets, spatial offsets and the same magnitude clamp. Color can use `0.5 + 0.5 * driver`. Driver displacement and noise are local vectors applied through the particle's tangent, bitangent and normal.

## Assets

The seven binaries in `public/assets/particles` are byte-exact copies of the native runtime's `particle-role-parity` assets. `manifest.json` records names, byte counts and SHA-256 digests. No unused adjacency assets are bundled.

- Hand graphs retain the native 1,024 sample indices, file ordering and float32 distance thresholds. Source edge counts are 98,510 left and 99,592 right. Filtering distances above `0.025` m leaves 20,647 left and 20,834 right runtime edges. Tier boundaries are one-third and two-thirds of the float32 maximum distance.
- Sphere position/normal files each contain 2,562 four-float rows. Exported position xyz values remain the unit sphere; the source position fourth component is the `0.012` m particle radius. The normal fourth component is `1`. Normalized local frames use the native Y-or-X helper selection at `abs(normal.y) < 0.92`.
- Sphere topology is regenerated in the native face/subdivision order, four subdivisions from 12 vertices and 20 faces. Sorted breadth-first rings produce 15,360 first-tier, 30,660 second-tier and 45,840 third-tier directed edges, totaling 91,860. No sphere coordinates are regenerated.
- The feather mask is the unchanged 512 by 512 R8 binary.

## Module API

All public imports are from `src/dynamics/index.js`.

```js
await loadStimulusAssets({ baseUrl: '/assets/particles/', fetch: globalThis.fetch });
// { sphere: { positions, normals, tangents, bitangents }, graphs: { left, right, sphere }, mask }
// graph = { count, offsets: Uint32Array(count+1), indices: Uint32Array, weights: Float32Array }

makeCondition('HC_HE');
initialPhases(count, seed = DEFAULT_SEED); // Float32Array, interleaved xyz
naturalFrequencies(origins, parameters); // Float32Array, interleaved xyz radians/sec
stepPhases(previous, frequencies, graph, parameters, dt, optionalOutput); // synchronous CPU reference
perlinSample(seed32, x, y, z); // float32 native gradient-field reference

new GpuOscillators(renderer, graph, origins, conditionOrToken, seed = DEFAULT_SEED);
// .step(dt), .reset(conditionOrToken, origins, seed), .dispose()
// .phaseTexture (RGBA float texture; phase xyz, alpha 1), .textureSize (square width)
// .elapsed (seconds), .parameters (normalized settings)
// .readPhases() is an explicit synchronous diagnostic; no production loop calls it.
```

`movementGlsl` exports GLSL ES 3 helpers `vec3 stimulusDriver(vec3 phases)` and `vec3 stimulusNoise(vec3 driver, float elapsed, vec3 settings)`. Noise settings are `(noiseFrequency, noiseAmplitudeMeters, noiseSpeedHz)`.

The GPU engine requires WebGL2 and `EXT_color_buffer_float` and fails explicitly if unavailable. Nearest-sampled RGBA32F ping-pong textures retain phase state on the GPU. A fullscreen pass updates all independent components, then swaps the completed target. It disables XR only during the compute pass and restores the previous render target, cube face, mip level, `autoClear`, and XR enabled state in `finally`. Render-target viewport/scissor selection uses Three.js target state, avoiding canvas device-pixel-ratio scaling. Construction and reset upload data without rendering. Diagnostic readback restores the XR enabled state, while Three.js restores the bound framebuffer internally.

## Validation boundary

`node --test tests/dynamics.test.js` covers analytic integration, active-edge normalization, axis independence, aliased-output snapshot behavior, phase wrapping, exact initial seed fixtures, deterministic frequency setup, unsupported settings/capabilities and asset shapes/digests. Actual shader execution, CPU/GPU tolerance comparison, shader-driver/noise appearance and XR performance require rendered browser/device validation; Node tests do not establish those outcomes.
