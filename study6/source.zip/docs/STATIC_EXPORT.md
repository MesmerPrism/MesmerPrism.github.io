# Static publication export

The exporter prepares a generated-only static subtree for HTTPS hosting, including
the corresponding committed source and license notices. Publication is authorized
separately from physical Quest Browser qualification. The manifest explicitly
records `same_axis_only: true` and `physical_headset_qualified: false`.

From the repository root, after committing the complete source:

```powershell
node tools/export-site.mjs --destination local/site-export
node tools/export-site.mjs --check local/site-export
```

The destination must be new or empty. Inside the source repository it must be
beneath ignored `local/`. An absolute path to a new or empty directory in a
separate hosting checkout is also supported, including that checkout's `study6/`
directory. The exporter rejects the source root, its ancestors, source directories,
Git metadata, linked destination ancestors and nonempty destinations. It never
deletes an existing destination. If an output write fails, partial output remains
for inspection; choose a fresh empty destination for another attempt.

An existing `dist/index.html` is required. For a first export without any prior
build, run `npm run build` first. Each export then runs the local pinned Vite CLI
again as the final production build:

```powershell
node node_modules/vite/bin/vite.js build
```

Node is launched through the current Node executable, without a shell. The portable
argv above is recorded in the manifest without a machine-specific executable path.
A nonzero build result stops export. The worktree must be clean, including staged
and untracked source files; ignored build output, dependencies and `local/` are
permitted. HEAD, its tree and worktree cleanliness are checked before the build,
after the build and immediately before output creation. Do not edit source or
destinations concurrently with export.

Before building, the existing build tree is checked for links or escaping paths.
The completed build is checked again. Only regular build files and direct root
`LICENSE.txt` and `NOTICE.md` files are copied. Implementation files under `src/`
and completed JavaScript bundles are scanned for the excluded coupling identifiers
enforced by the public-boundary tests. Exclusion tests may name those identifiers;
they are source tests, rather than shipped implementation.

The output contains:

- The exact completed `dist/` file bytes, preserving relative paths.
- `LICENSE.txt` and `NOTICE.md` from the clean committed root.
- `source.zip`, produced by `git archive --format=zip <exact-HEAD-commit>`. It
  contains that source snapshot, without `.git/`, deleted historical files,
  untracked files, ignored local files, dependencies or native repository history.
- `export-manifest.json`, with schema version, exact source commit and tree,
  completed build command, semantic qualification flags, and each output file's
  relative path, byte count and SHA-256 digest. The manifest excludes itself from
  its file list. No machine paths or timestamps are inserted into it.

All inputs are validated and buffered before the destination is created. Reserved
root export filenames in build output are rejected, and output files use exclusive
creation so an existing file is never overwritten.

`--check` is read-only. It verifies manifest structure, required files, the exact
file set, regular-file paths, byte counts, SHA-256 digests and the JavaScript
exclusion scan. It needs no source checkout or build dependencies. It checks
integrity relative to the supplied manifest; it does not authenticate a publisher,
replace source review or imply physical headset testing.

The module also exports `exportSite({root, destination, buildCommand})` and
`checkExport({directory})`. Both return the manifest. The optional programmatic
`buildCommand` is a portable Node argv array; the CLI always uses the Vite recipe.
Tests use a committed tiny builder in temporary Git repositories to exercise the
real Git archive and filesystem boundaries without rebuilding the live app:

```powershell
node --test tests/export-site.test.js
```

This tool prepares files only. HTTPS hosting, publication of the subtree and
wearer validation remain separate actions.
