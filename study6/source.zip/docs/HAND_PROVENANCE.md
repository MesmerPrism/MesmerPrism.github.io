# Hand surface provenance and contract

The hand pipeline ports the project-authored `HandSkinner.kt`, runtime-rig portion of `RecordedHandAssetLoader.kt`, and compact row mapping in `OpenXrHandRowsAdapter.kt` from the accepted Spatial Study 6 runtime revision `c5c2d4982bced5aeaf2d312f8fc31acd95134a20`. The read-only reference checkout was at documentation revision `7f442a9645aebb2f8c8cb74b31bfabbff29d7c38`. The skinner's latest source commit is `85fdefedead2dbf09f55f800a361c6fae181afb7`, authored by Till Holzapfel. The source repository declares AGPL-3.0-only; the JavaScript port retains that license. No Meta SDK source or runtime dependency is included.

The project owner's 2026-11-05 authorization permits the runtime rig assets and pinned samples in this standalone WebXR stimulus port. The original assets describe Meta Quest OpenXR provider geometry and the Study 6 / Rusty Kuramoto Mesh distribution. This record preserves those origins and the specific authorization; it does not assert a separate general-purpose Meta asset license.

## Included assets

`public/assets/hands/left.manifest.json` and `right.manifest.json` are explicit inventories. Every binary is copied byte-for-byte from the accepted runtime-only `spatial-ecs-live-rig` asset set. The upstream inventory identifies rig lineage `2d00b3d5259b6208ab6082734335217d91e919ae`. All 18 copied files match that inventory's SHA-256 digests. Both manifests list file names, scalar types, counts and SHA-256 values; the loader checks every file's byte count and digest before exposing a rig.

For the left hand, the file prefix is `recorded-meta-quest-hand`. For the right hand, it is `recorded-meta-quest-right-hand`. The following nine suffixes are included for each prefix:

| Suffix | Values | Meaning |
| --- | ---: | --- |
| `skinning-bind-vertices.f32.bin` | 4,080 | 1,360 bind positions |
| `skinning-bind-normals.f32.bin` | 4,080 | 1,360 bind normals |
| `mesh-triangles.u32.bin` | 6,942 | 2,314 triangles, original winding/order |
| `skinning-vertex-joint-indices.u32.bin` | 5,440 | Four bind-joint indices per vertex |
| `skinning-vertex-joint-weights.f32.bin` | 5,440 | Four original skin weights per vertex |
| `skinning-bind-joint-poses.f32.bin` | 182 | 26 translation + XYZW quaternion poses |
| `skinning-bind-joint-sources.u32.bin` | 104 | 26 original compact/tip source records |
| `samples-1024-coordinate-triangles.u32.bin` | 1,024 | Pinned triangle selection and sample order |
| `samples-1024-coordinate-barycentric.f32.bin` | 3,072 | Three pinned barycentric coordinates per sample |

The two hands total 242,912 binary bytes. There are no raw joint captures, replay clips, validation meshes, pre-skinned animation frames or participant records. The 512-sample distribution and original replay manifest are omitted because this port uses only 1,024 samples and does not provide replay.

Pinned 1,024-sample digests:

| Hand | Triangle indices SHA-256 | Barycentric SHA-256 |
| --- | --- | --- |
| Left | `d709b9d00839bade80dad0ce17d3bd01a0877b6937380f5ba2c02d5ec26b3e7f` | `5f6ce2027fe8f700430077587c3453bafeea103339ae2ed47934a6dc04f5fa9b` |
| Right | `a2cce4c173b1d23a9c082cb6766b4b4521581e0589b91fe579d8f8c1c35d5b92` | `72544c47c9b8972ac005781afd1450aa1aab244f384e2dbea71eb52782387663` |

## Coordinate and validity contract

`readWebXrJoints(frame, inputSource, referenceSpace, target)` reads each of the 25 joints by its fixed WebXR name from the same input source and reference space. The mapping follows the [W3C WebXR Hand Input joint definitions](https://www.w3.org/TR/2026/WD-webxr-hand-input-1-20261029/#skeleton-joints). WebXR wrist is OpenXR row 1; the remaining named WebXR joints occupy OpenXR rows 2–25 in order. There is no WebXR palm joint. Row 0 is explicitly copied from wrist and is unused by all positive rig weights. Handedness selects the appropriate input source and rig; no side receives a coordinate reflection or quaternion sign compensation.

The result is 26 column-major 4×4 world-pose matrices. Quaternions are normalized when converting bind or WebXR poses to matrices. Non-finite values, unusable quaternions, absent joints and unavailable poses fail closed. A failed WebXR read fills its output buffer with NaNs, preventing later consumers from treating a stale locate as current tracking.

The original bind-source records address a compact 21-pose layout. Its OpenXR rows are `[0,1,2,3,4,6,7,8,9,11,12,13,14,16,17,18,19,21,22,23,24]`. The five tip bind poses retain the distal joint's orientation and offset along its local −Z by the measured distal-to-tip distance. This preserves the accepted adapter rather than treating compact source indices as WebXR indices or using tip quaternions as distal quaternions.

Skinning applies `currentPose × inverse(bindPose)` to each vertex influence in the common scene basis. Influence vectors are precomputed once. Finite nonnegative weights are normalized without modifying the original asset bytes. A vertex with zero total weight preserves the accepted bind-position/bind-normal fallback; a degenerate normal falls back to the normalized bind normal, then +Z. Invalid weights are rejected when creating a state. Live input matrices must be finite proper rigid transforms. There is no Spatial mirror-X or captured-origin registration stage in the browser path.

The exact triangle indices and barycentric values are evaluated against that frame's skinned positions. The tangent is normalized edge A→B, the normal is normalized barycentric interpolation of skinned vertex normals with a triangle-normal fallback, and the bitangent is normalized `normal × tangent`. These are the native frame rules: the tangent is not reprojected onto the smoothed normal's plane. Degenerate vectors preserve the native +X tangent, +Z triangle normal and +Y bitangent fallbacks.

`createHandState` allocates mesh and 1,024-anchor output buffers once. `updateHand` and the sample loop reuse them. Every update first sets `state.valid = false`, then validates the same-frame input before marking a complete surface valid. Callers must hide a state whose update returns false or whose `valid` flag is false; its buffers can retain prior geometry. No path substitutes synthetic data for invalid live input.

`syntheticJoints` is an explicit desktop preview helper. It applies a visible wrist motion and hierarchical local-X finger flexion to the actual bind rig while preserving segment lengths. The wrist presents the bind X–Z palm plane toward the desktop viewer with gentle yaw/roll and a fully open-to-closed finger cycle. Its generated motion is mathematical, not recorded data. The caller owns the synthetic-mode label and can reuse a supplied 26×16 target buffer. The hand state itself carries no live/synthetic claim.

## Verification

Focused command: `node --test tests/hands.test.js`.

- Initial red run: exit 1 because the hand module did not yet exist.
- Behavioral red regression: exit 1, 9 passing / 1 failing. A finite JavaScript position outside Float32 range was incorrectly accepted by the WebXR reader (`true !== false`).
- After rejecting Float32 overflow: exit 0, 10 passing / 0 failing.
- Preview orientation regression: exit 1, 10 passing / 1 failing. A Z-only wrist rotation left both palms nearly edge-on; the absolute palm-normal/view-direction dot products were 0.368 (left) and 0.329 (right).
- After presenting the X–Z bind palm plane toward the desktop viewer and adding an open/close cycle: exit 0, 11 passing / 0 failing. Tests require the open palm/view alignment to exceed 0.85, retain bind-pose finger straightness while open, and bend during closure. Existing bind/live checks remain unchanged.

Tests cover both hands' complete binary digests and counts, bind skinning, pinned sample ordering, frame normalization, common-space translation, output-buffer reuse, invalid/missing/malformed same-frame poses, quaternion/weight normalization, zero-weight and invalid-weight handling, compact/tip adaptation, explicit named left/right mapping, missing-joint failure, Float32 overflow and synthetic segment lengths/motion.

These are host numerical and boundary checks. They do not establish live WebXR hand alignment, headset rendering, sustained performance or browser/device acceptance. Those remain the integrating application's validation responsibilities.
