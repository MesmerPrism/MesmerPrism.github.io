import test from 'node:test';
import assert from 'node:assert/strict';
import {mkdtemp, mkdir, writeFile, readFile, readdir, rm, symlink, unlink} from 'node:fs/promises';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import {spawnSync} from 'node:child_process';
import {createHash} from 'node:crypto';
import {inflateRawSync} from 'node:zlib';

const modulePath = new URL('../tools/export-site.mjs', import.meta.url);
const sha256 = bytes => createHash('sha256').update(bytes).digest('hex');
function git(root, ...args) {
  const result = spawnSync('git', args, {cwd: root, encoding: null});
  assert.equal(result.status, 0, result.stderr?.toString());
  return result.stdout;
}
async function exporter() {
  const module = await import(modulePath).catch(error => {
    if (error.code === 'ERR_MODULE_NOT_FOUND' && error.url === modulePath.href) return {};
    throw error;
  });
  assert.equal(typeof module.exportSite, 'function', 'the static exporter must expose exportSite');
  return module;
}
async function fixture(t) {
  const base = await mkdtemp(join(tmpdir(), 'study6-export-'));
  t.after(() => rm(base, {recursive: true, force: true}));
  const root = join(base, 'source');
  await mkdir(root);
  git(root, 'init', '--quiet');
  git(root, 'config', 'user.name', 'Export test');
  git(root, 'config', 'user.email', 'export@example.invalid');
  git(root, 'config', 'core.autocrlf', 'false');
  await writeFile(join(root, 'private-native.js'), 'PRIVATE_OLD_NATIVE_IMPLEMENTATION');
  git(root, 'add', '.');
  git(root, 'commit', '--quiet', '-m', 'Private historical fixture');
  git(root, 'rm', '--quiet', 'private-native.js');
  await mkdir(join(root, 'src'));
  await mkdir(join(root, 'tests'));
  await mkdir(join(root, 'local'));
  await writeFile(join(root, '.gitignore'), 'dist/\nlocal/\n');
  await writeFile(join(root, 'src/app.js'), 'console.log("same axis");\n');
  await writeFile(join(root, 'tests/exclusion.test.js'), '// cross_axis_pull is excluded from implementation\n');
  await writeFile(join(root, 'LICENSE.txt'), 'Fixture license\n');
  await writeFile(join(root, 'NOTICE.md'), 'Fixture notice\n');
  await writeFile(join(root, 'build.mjs'), [
    "import {mkdirSync,readFileSync,writeFileSync} from 'node:fs';",
    "mkdirSync('dist/assets',{recursive:true});",
    "writeFileSync('dist/index.html','<!doctype html><script src=\"./assets/app.js\"></script>');",
    "writeFileSync('dist/assets/app.js',readFileSync('src/app.js'));",
    "writeFileSync('dist/assets/pixel.bin',Buffer.from([0,1,254,255]));"
  ].join('\n'));
  git(root, 'add', '.');
  git(root, 'commit', '--quiet', '-m', 'Public snapshot');
  await writeFile(join(root, 'local/private.txt'), 'IGNORED_PRIVATE_CONTENT');
  await mkdir(join(root, 'dist'));
  await writeFile(join(root, 'dist/index.html'), 'stale initial build');
  return {root, base, destination: join(base, 'public-site', 'study6'), buildCommand: ['node', 'build.mjs']};
}
function zipContents(bytes) {
  const files = new Map();
  let cursor = bytes.lastIndexOf(Buffer.from([0x50, 0x4b, 0x05, 0x06]));
  const count = bytes.readUInt16LE(cursor + 10);
  cursor = bytes.readUInt32LE(cursor + 16);
  for (let i = 0; i < count; i++) {
    assert.equal(bytes.readUInt32LE(cursor), 0x02014b50);
    const method = bytes.readUInt16LE(cursor + 10);
    const compressedSize = bytes.readUInt32LE(cursor + 20);
    const nameSize = bytes.readUInt16LE(cursor + 28);
    const extraSize = bytes.readUInt16LE(cursor + 30);
    const commentSize = bytes.readUInt16LE(cursor + 32);
    const offset = bytes.readUInt32LE(cursor + 42);
    const name = bytes.subarray(cursor + 46, cursor + 46 + nameSize).toString();
    const start = offset + 30 + bytes.readUInt16LE(offset + 26) + bytes.readUInt16LE(offset + 28);
    const payload = bytes.subarray(start, start + compressedSize);
    files.set(name, method === 8 ? inflateRawSync(payload) : payload);
    cursor += 46 + nameSize + extraSize + commentSize;
  }
  return files;
}

test('exports the completed build and exact committed source with a verifiable manifest', async t => {
  const options = await fixture(t);
  const {exportSite, checkExport} = await exporter();
  const manifest = await exportSite(options);
  assert.equal(manifest.source.commit, git(options.root, 'rev-parse', 'HEAD').toString().trim());
  assert.equal(manifest.source.tree, git(options.root, 'rev-parse', 'HEAD^{tree}').toString().trim());
  assert.equal(manifest.source.archive, 'source.zip');
  assert.deepEqual(manifest.build.command, ['node', 'build.mjs']);
  assert.equal(manifest.build.completed, true);
  assert.equal(manifest.same_axis_only, true);
  assert.equal(manifest.physical_headset_qualified, false);
  assert.deepEqual(manifest.files.map(file => file.path), [
    'LICENSE.txt', 'NOTICE.md', 'assets/app.js', 'assets/pixel.bin', 'index.html', 'source.zip'
  ]);
  for (const file of manifest.files) {
    const bytes = await readFile(join(options.destination, file.path));
    assert.equal(file.bytes, bytes.length);
    assert.equal(file.sha256, sha256(bytes));
  }
  assert.equal(await readFile(join(options.destination, 'assets/app.js'), 'utf8'), 'console.log("same axis");\n');
  const archive = await readFile(join(options.destination, 'source.zip'));
  assert.deepEqual(archive, git(options.root, 'archive', '--format=zip', 'HEAD'));
  const contents = zipContents(archive);
  assert.ok(contents.has('src/app.js'));
  assert.ok(contents.has('tests/exclusion.test.js'));
  assert.ok(![...contents.keys()].some(name => /^(?:\.git\/|local\/|dist\/|private-native)/.test(name)));
  assert.ok(![...contents.values()].some(bytes => /PRIVATE_OLD_NATIVE|IGNORED_PRIVATE/.test(bytes.toString())));
  assert.deepEqual(await checkExport({directory: options.destination}), manifest);
  assert.deepEqual(JSON.parse(await readFile(join(options.destination, 'export-manifest.json'), 'utf8')), manifest);
});

test('refuses changed, staged or untracked source before creating output', async t => {
  const {exportSite} = await exporter();
  for (const kind of ['changed', 'staged', 'untracked']) {
    const options = await fixture(t);
    if (kind === 'untracked') await writeFile(join(options.root, 'private.txt'), 'UNTRACKED_PRIVATE');
    else {
      await writeFile(join(options.root, 'src/app.js'), 'changed');
      if (kind === 'staged') git(options.root, 'add', 'src/app.js');
    }
    await assert.rejects(exportSite(options), /clean.*committed|dirty/i);
    await assert.rejects(readdir(options.destination), {code: 'ENOENT'});
  }
});

test('refuses forbidden implementation identifiers in source or completed JavaScript', async t => {
  const {exportSite} = await exporter();
  for (const identifier of ['movementCrossAxisCoupling', 'cross_axis_pull', 'crossAxisPull', 'cross_axis_coupling']) {
    const options = await fixture(t);
    await writeFile(join(options.root, 'src/app.js'), `const ${identifier} = 1;`);
    git(options.root, 'add', '.');
    git(options.root, 'commit', '--quiet', '-m', 'Forbidden source fixture');
    await assert.rejects(exportSite(options), /forbidden|excluded/i);
    await assert.rejects(readdir(options.destination), {code: 'ENOENT'});
  }
  const options = await fixture(t);
  await writeFile(join(options.root, 'build.mjs'), "import {writeFileSync} from 'node:fs'; writeFileSync('dist/hidden.js','const crossAxisPull = 1;');");
  git(options.root, 'add', '.');
  git(options.root, 'commit', '--quiet', '-m', 'Forbidden bundle fixture');
  await assert.rejects(exportSite(options), /forbidden|excluded/i);
  await assert.rejects(readdir(options.destination), {code: 'ENOENT'});
});

test('refuses nonempty or source-sensitive destinations without changing their bytes', async t => {
  const options = await fixture(t);
  const {exportSite} = await exporter();
  await mkdir(options.destination, {recursive: true});
  await writeFile(join(options.destination, 'keep.txt'), 'keep exact bytes');
  await assert.rejects(exportSite(options), /empty/i);
  assert.equal(await readFile(join(options.destination, 'keep.txt'), 'utf8'), 'keep exact bytes');
  for (const destination of [options.root, options.base, join(options.root, 'src/new-site'), join(options.root, '.git/new-site'), join(options.root, 'dist/site')]) {
    await assert.rejects(exportSite({...options, destination}), /destination|local/i);
  }
  await exportSite({...options, destination: join(options.root, 'local/site-export')});
  assert.ok((await readdir(join(options.root, 'local/site-export'))).includes('source.zip'));
});

test('requires an existing build and refuses a failed build or source mutation during it', async t => {
  const {exportSite} = await exporter();
  const missing = await fixture(t);
  await unlink(join(missing.root, 'dist/index.html'));
  await assert.rejects(exportSite(missing), /dist.*index|existing.*build/i);
  for (const script of ['process.exit(7);', "import {writeFileSync} from 'node:fs'; writeFileSync('src/app.js','changed by build');"]) {
    const options = await fixture(t);
    await writeFile(join(options.root, 'build.mjs'), script);
    git(options.root, 'add', '.');
    git(options.root, 'commit', '--quiet', '-m', 'Build failure fixture');
    await assert.rejects(exportSite(options), /build|clean|dirty/i);
    await assert.rejects(readdir(options.destination), {code: 'ENOENT'});
  }
});

test('rejects linked build files and linked destination ancestors', async t => {
  const options = await fixture(t);
  const {exportSite} = await exporter();
  const outside = join(options.base, 'outside');
  await mkdir(outside);
  await writeFile(join(outside, 'secret.js'), 'private');
  // Junctions are available without Windows developer-mode symlink privileges.
  await symlink(outside, join(options.root, 'dist/escaped'), process.platform === 'win32' ? 'junction' : 'dir');
  await assert.rejects(exportSite(options), /link|escape|reparse/i);
  await assert.rejects(readdir(options.destination), {code: 'ENOENT'});
  const linkedParent = join(options.base, 'linked-site');
  await symlink(outside, linkedParent, process.platform === 'win32' ? 'junction' : 'dir');
  await assert.rejects(exportSite({...options, destination: join(linkedParent, 'study6')}), /link|escape|reparse/i);
  assert.deepEqual(await readdir(outside), ['secret.js']);
});

test('verification detects tampered files and unexpected additions', async t => {
  const options = await fixture(t);
  const {exportSite, checkExport} = await exporter();
  await exportSite(options);
  const file = join(options.destination, 'index.html');
  const original = await readFile(file);
  await writeFile(file, 'tampered');
  await assert.rejects(checkExport({directory: options.destination}), /hash|digest|bytes/i);
  await writeFile(file, original);
  await writeFile(join(options.destination, 'unlisted.txt'), 'unexpected');
  await assert.rejects(checkExport({directory: options.destination}), /unexpected|file list/i);
});

test('rejects reserved export names used as build directories before creating output', async t => {
  const options = await fixture(t);
  const {exportSite} = await exporter();
  await mkdir(join(options.root, 'dist/source.zip'));
  await writeFile(join(options.root, 'dist/source.zip/hidden.txt'), 'unexpected');
  await assert.rejects(exportSite(options), /reserved|collid/i);
  await assert.rejects(readdir(options.destination), {code: 'ENOENT'});
});
