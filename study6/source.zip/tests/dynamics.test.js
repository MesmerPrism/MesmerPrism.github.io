import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import * as dynamics from '../src/dynamics/index.js';

// Each expectation below is analytic or a fixed native-model/asset fixture.
const pair = { count: 2, offsets: new Uint32Array([0, 1, 2]), indices: new Uint32Array([1, 0]), weights: new Float32Array([0.5, 0.5]) };
const tau = Math.fround(2 * Math.PI);
const close = (a, b, tolerance = 2e-6) => assert.ok(Math.abs(a - b) <= tolerance, `${a} != ${b}`);

test('four native profiles set frequency, neighbor coupling and visible movement', () => {
  assert.equal(typeof dynamics.makeCondition, 'function');
  const expected = [
    ['LC_LE', .44, .62, 0, .002, 0, 0, 0],
    ['LC_HE', .88, .62, 0, .004, 6.7, .004, .5],
    ['HC_LE', .44, .03, 1, .002, 0, 0, 0],
    ['HC_HE', .88, .03, 1, .004, 6.7, .004, .5],
  ];
  const fields = ['baseFrequencyHz', 'frequencySpreadHz', 'movementCoupling', 'displacementScaleMeters', 'noiseFrequency', 'noiseAmplitudeMeters', 'noiseSpeedHz'];
  for (const [token, ...values] of expected) {
    const profile = dynamics.makeCondition(token);
    assert.deepEqual(Object.keys(profile).sort(), fields.toSorted());
    fields.forEach((field, i) => close(profile[field], values[i]));
  }
  assert.throws(() => dynamics.makeCondition('hc_he'), /condition/i);
});

test('two oscillators advance with weighted same-axis sine pull and active edge normalization', () => {
  assert.equal(typeof dynamics.stepPhases, 'function');
  const source = new Float32Array([0, .3, .6, Math.PI / 2, .3, .6]);
  const out = dynamics.stepPhases(source, new Float32Array(6), pair, dynamics.makeCondition('HC_LE'), .1);
  close(out[0], .8); // 16 * .5 * sin(pi/2) * .1
  close(out[3], Math.PI / 2 - .8);
  close(out[1], .3);
  assert.equal(source[0], 0);
  const weighted = { count: 3, offsets: new Uint32Array([0, 2, 2, 2]), indices: new Uint32Array([1, 2]), weights: new Float32Array([.5, .1]) };
  const rows = new Float32Array([0,0,0, Math.PI/2,0,0, Math.PI/2,0,0]);
  close(dynamics.stepPhases(rows, new Float32Array(9), weighted, dynamics.makeCondition('HC_LE'), .1)[0], .48);
});

test('changing both other axes leaves the selected axis step identical', () => {
  assert.equal(typeof dynamics.stepPhases, 'function');
  const a = new Float32Array([.1, .2, .3, 1.5, 2.5, 3.5]);
  const b = new Float32Array([.1, 6, 4, 1.5, 0, .1]);
  const frequencies = new Float32Array([.7,.8,.9,.6,.5,.4]);
  const profile = dynamics.makeCondition('HC_HE');
  const x = dynamics.stepPhases(a, frequencies, pair, profile, .02);
  const y = dynamics.stepPhases(b, frequencies, pair, profile, .02);
  assert.equal(x[0], y[0]);
  assert.equal(x[3], y[3]);
});

test('aliased output still integrates from a complete previous snapshot and wraps phases', () => {
  assert.equal(typeof dynamics.stepPhases, 'function');
  const input = new Float32Array([0,0,0,Math.PI/2,0,0]);
  const original = input.slice();
  dynamics.stepPhases(input, new Float32Array(6), pair, dynamics.makeCondition('HC_LE'), .1, input);
  close(input[3], Math.PI/2 - .8);
  const free = dynamics.stepPhases(original, new Float32Array([100,0,0,100,0,0]), pair, dynamics.makeCondition('LC_LE'), .1);
  close(free[0], 10 - tau);
  assert.throws(() => dynamics.stepPhases(original,new Float32Array(6),pair,dynamics.makeCondition('HC_LE'),NaN), /delta/i);
});

test('64-bit initial state is reproducible and different reset seeds change it', () => {
  assert.equal(typeof dynamics.initialPhases, 'function');
  const phases = dynamics.initialPhases(3);
  assert.equal(phases.length, 9);
  assert.deepEqual(Array.from(phases), [2.0779402256011963,3.0282223224639893,1.8498045206069946,3.8898367881774902,2.7382588386535645,3.4196581840515137,5.048030853271484,4.133963108062744,6.108479022979736]);
  assert.deepEqual(phases, dynamics.initialPhases(3));
  assert.notDeepEqual(phases, dynamics.initialPhases(3, 42n));
  assert.ok(phases.every(value => value >= 0 && value < tau));
});

test('natural frequencies sample the seeded spatial field once from xyz origins', () => {
  assert.equal(typeof dynamics.naturalFrequencies, 'function');
  const origins = new Float32Array([0,0,0, .01,.02,.03]);
  const frequencies = dynamics.naturalFrequencies(origins, dynamics.makeCondition('HC_LE'));
  assert.equal(frequencies.length, 6);
  for (const value of frequencies.slice(0,3)) close(value, Math.fround(Math.fround(.44) * tau), 1e-7);
  assert.equal(new Set(frequencies.slice(3)).size, 3);
  assert.deepEqual(frequencies, dynamics.naturalFrequencies(origins, dynamics.makeCondition('HC_LE')));
});

test('unsupported GPU capability fails explicitly before allocating a simulation', () => {
  assert.equal(typeof dynamics.GpuOscillators, 'function');
  const renderer = { capabilities:{isWebGL2:true}, extensions:{has:() => false} };
  assert.throws(() => new dynamics.GpuOscillators(renderer,pair,new Float32Array(6),dynamics.makeCondition('HC_LE')), /EXT_color_buffer_float/);
});

test('GPU accepts exact condition tokens and rejects unsupported tokens before allocating textures', () => {
  const renderer = {capabilities:{isWebGL2:true,maxTextureSize:4096},extensions:{has:() => true}};
  assert.throws(() => new dynamics.GpuOscillators(renderer,pair,new Float32Array(6),'INVALID'), /condition/);
  // A malformed origin row must be the next failure after a valid token resolves.
  assert.throws(() => new dynamics.GpuOscillators(renderer,pair,new Float32Array(3),'HC_HE'), /Origin count/);
});

test('CPU configuration rejects unknown settings instead of enabling extra behavior', () => {
  const profile = {...dynamics.makeCondition('HC_LE'), unknownSetting:1};
  assert.throws(() => dynamics.naturalFrequencies(new Float32Array(6),profile), /Unsupported/);
  assert.throws(() => dynamics.stepPhases(new Float32Array(6),new Float32Array(6),pair,profile,.01), /Unsupported/);
});

test('exact runtime assets load with pinned counts, tier neighborhoods and verified bytes', async () => {
  assert.equal(typeof dynamics.loadStimulusAssets, 'function');
  const baseUrl = new URL('../public/assets/particles/', import.meta.url);
  const files = await readFile(new URL('manifest.json',baseUrl), 'utf8').then(JSON.parse);
  for (const file of files.files) {
    const bytes = await readFile(new URL(file.name,baseUrl));
    assert.equal(bytes.byteLength,file.bytes);
    assert.equal(createHash('sha256').update(bytes).digest('hex'),file.sha256);
  }
  const fetch = async url => {
    const bytes = await readFile(url);
    return { ok:true, arrayBuffer:async () => bytes.buffer.slice(bytes.byteOffset,bytes.byteOffset+bytes.byteLength) };
  };
  const assets = await dynamics.loadStimulusAssets({baseUrl,fetch});
  assert.equal(assets.mask.length,512*512);
  assert.equal(assets.sphere.positions.length,2562*3);
  assert.equal(assets.sphere.normals.length,2562*3);
  for (const [name,count,edges] of [['left',1024,20647],['right',1024,20834],['sphere',2562,91860]]) {
    const graph = assets.graphs[name];
    assert.equal(graph.count,count);
    assert.equal(graph.offsets.length,count+1);
    assert.equal(graph.indices.length,edges);
    assert.equal(graph.weights.length,edges);
    assert.equal(graph.offsets[count],edges);
    assert.ok(graph.indices.every(index => index < count));
  }
  const sphere = assets.graphs.sphere;
  const tiers = [.5,.3,.1].map(weight => sphere.weights.filter(value => Math.abs(value-weight)<1e-7).length);
  assert.deepEqual(tiers,[15360,30660,45840]);
  for (let i=0;i<2562;i++) {
    const at = i*3;
    const normal = assets.sphere.normals.subarray(at,at+3);
    const tangent = assets.sphere.tangents.subarray(at,at+3);
    close(Math.hypot(...normal),1);
    close(Math.hypot(...tangent),1);
    close(normal.reduce((sum,v,j) => sum+v*tangent[j],0),0);
  }
});
