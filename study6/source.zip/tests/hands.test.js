import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { loadHandRig, createHandState, updateHand, syntheticJoints, readWebXrJoints } from '../src/hands/index.js';

const root = new URL('../public/assets/hands/', import.meta.url);
const fetcher = async url => {
  const data = await readFile(new URL(url.replace('/assets/hands/', ''), root));
  return new Response(data);
};
const near = (actual, expected, epsilon = 3e-6) => assert.ok(Math.abs(actual - expected) < epsilon, `${actual} != ${expected}`);
const joints = ['wrist', 'thumb-metacarpal', 'thumb-phalanx-proximal', 'thumb-phalanx-distal', 'thumb-tip',
  'index-finger-metacarpal', 'index-finger-phalanx-proximal', 'index-finger-phalanx-intermediate', 'index-finger-phalanx-distal', 'index-finger-tip',
  'middle-finger-metacarpal', 'middle-finger-phalanx-proximal', 'middle-finger-phalanx-intermediate', 'middle-finger-phalanx-distal', 'middle-finger-tip',
  'ring-finger-metacarpal', 'ring-finger-phalanx-proximal', 'ring-finger-phalanx-intermediate', 'ring-finger-phalanx-distal', 'ring-finger-tip',
  'pinky-finger-metacarpal', 'pinky-finger-phalanx-proximal', 'pinky-finger-phalanx-intermediate', 'pinky-finger-phalanx-distal', 'pinky-finger-tip'];

for (const side of ['left', 'right']) {
  test(`${side}: exact rig digests, counts and bind-pose skinning preserve pinned sample order`, async () => {
    const rig = await loadHandRig(side, { fetcher });
    assert.equal(rig.vertexCount, 1360);
    assert.equal(rig.triangles.length, 2314 * 3);
    assert.equal(rig.bindJointPoses.length, 26 * 7);
    assert.equal(rig.sampleTriangles.length, 1024);
    for (const entry of Object.values(rig.manifest.files)) {
      const bytes = await readFile(new URL(entry.file, root));
      assert.equal(bytes.length, entry.count * 4);
      assert.equal(createHash('sha256').update(bytes).digest('hex'), entry.sha256);
    }
    const state = createHandState(rig);
    assert.equal(state.valid, false);
    assert.equal(updateHand(state, rig.bindJointMatrices), true);
    for (let i = 0; i < rig.bindVertices.length; i++) near(state.positions[i], rig.bindVertices[i]);
    for (let i = 0; i < 1024; i++) {
      const triangle = rig.sampleTriangles[i] * 3;
      for (let axis = 0; axis < 3; axis++) {
        const expected = [0, 1, 2].reduce((v, j) => v + rig.bindVertices[rig.triangles[triangle + j] * 3 + axis] * rig.sampleBarycentric[i * 3 + j], 0);
        near(state.origins[i * 3 + axis], expected);
      }
      for (const frame of [state.normals, state.tangents, state.bitangents, state.anchorNormals]) {
        if (frame === state.normals) continue;
        near(Math.hypot(frame[i * 3], frame[i * 3 + 1], frame[i * 3 + 2]), 1);
      }
      const dot = state.bitangents[i * 3] * state.anchorNormals[i * 3] + state.bitangents[i * 3 + 1] * state.anchorNormals[i * 3 + 1] + state.bitangents[i * 3 + 2] * state.anchorNormals[i * 3 + 2];
      near(dot, 0);
    }
    // A common-space translation must affect all vertices and anchors identically.
    const translated = rig.bindJointMatrices.slice();
    for (let j = 0; j < 26; j++) { translated[j * 16 + 12] += .3; translated[j * 16 + 13] += .2; translated[j * 16 + 14] -= .4; }
    const positionBuffer = state.positions, anchorBuffer = state.origins;
    assert.equal(updateHand(state, translated), true);
    for (let v = 0; v < 1360; v++) { near(state.positions[v * 3], rig.bindVertices[v * 3] + .3); near(state.positions[v * 3 + 1], rig.bindVertices[v * 3 + 1] + .2); near(state.positions[v * 3 + 2], rig.bindVertices[v * 3 + 2] - .4); }
    assert.equal(state.positions, positionBuffer);
    assert.equal(state.origins, anchorBuffer);
  });
}

test('same-frame missing, non-finite and malformed poses invalidate a previously valid hand', async () => {
  const rig = await loadHandRig('left', { fetcher });
  const state = createHandState(rig);
  for (const invalid of [null, new Float32Array(25 * 16), new Float32Array(26 * 16), (() => { const m = rig.bindJointMatrices.slice(); m[7 * 16] = NaN; return m; })()]) {
    assert.equal(updateHand(state, rig.bindJointMatrices), true);
    assert.equal(updateHand(state, invalid), false);
    assert.equal(state.valid, false);
  }
});

test('bind quaternions and influence weights normalize; zero weights use the accepted bind fallback', async () => {
  const rig = await loadHandRig('left', { fetcher });
  const poses = rig.bindJointPoses.slice(), weights = rig.vertexJointWeights.slice();
  for (let j = 0; j < 26; j++) for (let k = 3; k < 7; k++) poses[j * 7 + k] *= 5;
  for (let k = 0; k < weights.length; k++) weights[k] *= 2;
  const state = createHandState({ ...rig, bindJointPoses: poses, vertexJointWeights: weights });
  assert.equal(updateHand(state, rig.bindJointMatrices), true);
  for (let k = 0; k < state.positions.length; k++) near(state.positions[k], rig.bindVertices[k]);
  weights.fill(0, 0, 4);
  const zero = createHandState({ ...rig, vertexJointWeights: weights });
  assert.equal(updateHand(zero, rig.bindJointMatrices), true);
  for (let k = 0; k < 3; k++) near(zero.positions[k], rig.bindVertices[k]);
  weights[0] = NaN;
  assert.throws(() => createHandState({ ...rig, vertexJointWeights: weights }), /weight/i);
  poses.fill(0, 3, 7);
  assert.throws(() => createHandState({ ...rig, bindJointPoses: poses }), /quaternion/i);
});

test('live tips use measured lengths and distal orientation instead of tip orientation', async () => {
  const rig = await loadHandRig('left', { fetcher });
  const baseline = createHandState(rig), changed = createHandState(rig);
  const poses = rig.bindJointMatrices.slice();
  for (const row of [5, 10, 15, 20, 25]) for (let column = 0; column < 3; column++) for (let axis = 0; axis < 3; axis++) poses[row * 16 + column * 4 + axis] = column === axis ? 1 : 0;
  assert.equal(updateHand(baseline, rig.bindJointMatrices), true);
  assert.equal(updateHand(changed, poses), true);
  assert.deepEqual(changed.positions, baseline.positions);
});

for (const side of ['left', 'right']) test(`${side}: named WebXR mapping ignores iteration order and derives unused palm from wrist`, () => {
  const hand = new Map([...joints].reverse().map(name => [name, { name }]));
  const space = {};
  const frame = { getJointPose(joint, reference) { assert.equal(reference, space); const index = joints.indexOf(joint.name); return { transform: { position: { x: index + (side === 'left' ? -40 : 40), y: 2, z: -3 }, orientation: { x: 0, y: 0, z: 2, w: 2 } }, radius: .01 }; } };
  const target = new Float32Array(26 * 16);
  assert.equal(readWebXrJoints(frame, { hand, handedness: side }, space, target), true);
  for (let i = 0; i < 25; i++) {
    near(target[(i + 1) * 16 + 12], i + (side === 'left' ? -40 : 40));
    near(target[(i + 1) * 16 + 0], 0);
    near(target[(i + 1) * 16 + 1], 1);
  }
  assert.deepEqual(target.slice(0, 16), target.slice(16, 32));
  hand.delete('index-finger-tip');
  assert.equal(readWebXrJoints(frame, { hand, handedness: side }, space, target), false);
  assert.ok(target.every(Number.isNaN), 'a failed locate cannot expose a stale valid buffer');
});

test('invalid XR poses and missing sources fail closed without a synthetic substitute', () => {
  const target = new Float32Array(26 * 16), hand = new Map(joints.map(name => [name, { name }]));
  for (const value of [null, { transform: { position: { x: NaN, y: 0, z: 0 }, orientation: { x: 0, y: 0, z: 0, w: 1 } } }, { transform: { position: { x: 1e100, y: 0, z: 0 }, orientation: { x: 0, y: 0, z: 0, w: 1 } } }, { transform: { position: { x: 0, y: 0, z: 0 }, orientation: { x: 0, y: 0, z: 0, w: 0 } } }]) {
    assert.equal(readWebXrJoints({ getJointPose: () => value }, { hand, handedness: 'left' }, {}, target), false);
    assert.ok(target.every(Number.isNaN));
  }
  assert.equal(readWebXrJoints({}, {}, {}, target), false);
});

test('explicit synthetic preview uses the bind rig, animates finger articulation and reuses its output', async () => {
  for (const side of ['left', 'right']) {
    const rig = await loadHandRig(side, { fetcher }), state = createHandState(rig), target = new Float32Array(26 * 16);
    assert.equal(syntheticJoints(rig, 0, side, target), target);
    assert.equal(updateHand(state, target), true);
    const first = state.positions.slice();
    syntheticJoints(rig, 2, side, target);
    assert.equal(updateHand(state, target), true);
    assert.ok(first.some((p, i) => Math.abs(p - state.positions[i]) > .005));
    for (const [parent, child] of [[7, 8], [8, 9], [9, 10], [12, 13], [13, 14], [14, 15]]) {
      const length = m => Math.hypot(...[12, 13, 14].map(a => m[parent * 16 + a] - m[child * 16 + a]));
      near(length(target), length(rig.bindJointMatrices));
    }
    assert.equal('synthetic' in state, false);
  }
});

test('synthetic open palms face the desktop viewer and cycle through finger closure', async () => {
  const subtract = (a, b) => a.map((value, i) => value - b[i]);
  const unit = a => { const length = Math.hypot(...a); return a.map(value => value / length); };
  const cross = (a, b) => [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]];
  const dot = (a, b) => a.reduce((sum, value, i) => sum + value * b[i], 0);
  const position = (m, row) => Array.from(m.slice(row * 16 + 12, row * 16 + 15));
  const straightness = (m, a, b, c) => dot(unit(subtract(position(m, b), position(m, a))), unit(subtract(position(m, c), position(m, b))));
  for (const side of ['left', 'right']) {
    const rig = await loadHandRig(side, { fetcher }), open = syntheticJoints(rig, 0, side), closed = syntheticJoints(rig, Math.PI / .65, side);
    const wrist = position(open, 1), palmNormal = unit(cross(subtract(position(open, 12), wrist), subtract(position(open, 22), position(open, 7))));
    const toViewer = unit(subtract([0, 1.6, 0], wrist));
    assert.ok(Math.abs(dot(palmNormal, toViewer)) > .85, `${side} palm should be broadside to desktop viewer`);
    // The open pose retains the recorded open-hand finger direction; closing must bend it.
    near(straightness(open, 12, 13, 14), straightness(rig.bindJointMatrices, 12, 13, 14));
    assert.ok(straightness(closed, 12, 13, 14) < straightness(open, 12, 13, 14) - .15);
    assert.deepEqual(syntheticJoints(rig, 0, side), open, 'preview poses remain deterministic');
  }
});

test('asset corruption and unsupported sides are rejected instead of generating substitute rigs', async () => {
  await assert.rejects(loadHandRig('other', { fetcher }), /side/i);
  await assert.rejects(loadHandRig('left', { fetcher: async url => {
    const response = await fetcher(url);
    if (url.endsWith('.json')) return response;
    const data = new Uint8Array(await response.arrayBuffer()); data[0] ^= 255; return new Response(data);
  } }), /digest/i);
});
