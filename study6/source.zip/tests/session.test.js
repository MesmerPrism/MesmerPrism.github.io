import test from 'node:test';
import assert from 'node:assert/strict';
import { FrameClock, parseSettings, shouldRecenter, placeSphere, HandConfiguration } from '../src/session.js';

test('sphere drift updates its centre without rotating the captured particle field', () => {
  const center = new Float32Array([0,1.6,0]), orientation = new Float32Array([0,0,0,1]);
  placeSphere(center,orientation,[0,1.6,0],[0,.5,0,Math.sqrt(.75)],true);
  const captured=Array.from(orientation);
  placeSphere(center,orientation,[.4,1.6,0],[0,0,0,1],false);
  assert.deepEqual(Array.from(center),Array.from(new Float32Array([.4,1.6,0])));
  assert.deepEqual(Array.from(orientation),captured);
  placeSphere(center,orientation,[.4,1.6,0],[0,0,0,1],true);
  assert.deepEqual(Array.from(orientation),[0,0,0,1]);
});

test('frame clock pauses and resumes without accumulating hidden time', () => {
  const clock = new FrameClock();
  assert.equal(clock.tick(1000), 0);
  assert.ok(Math.abs(clock.tick(1010) - .01) < 1e-12);
  clock.setPaused(true);
  assert.equal(clock.tick(40000), 0);
  clock.setPaused(false);
  assert.equal(clock.tick(80000), 0);
  assert.ok(Math.abs(clock.tick(80010) - .01) < 1e-12);
});
test('frame clock bounds stalls and rejects non-monotonic time', () => {
  const clock = new FrameClock();
  clock.tick(1000);
  assert.equal(clock.tick(9000), .05);
  assert.equal(clock.tick(8990), 0);
});
test('settings accept only the four stimulus conditions and two roles', () => {
  assert.deepEqual(parseSettings({variant:'DHS',condition:'HC_HE',input:'preview'}), {variant:'DHS',condition:'HC_HE',input:'preview'});
  assert.throws(() => parseSettings({variant:'other'}), /variant/);
  assert.throws(() => parseSettings({condition:'other'}), /condition/);
  assert.throws(() => parseSettings({input:'recorded'}), /input/);
  assert.throws(() => parseSettings({extraControl:1}), /Unsupported/);
});
test('sphere drift threshold is measured in metres', () => {
  assert.equal(shouldRecenter([0,1.6,0],[.29,1.6,0]), false);
  assert.equal(shouldRecenter([0,1.6,0],[.301,1.6,0]), true);
});

test('live configuration waits for each current hand and never captures preview or missing input', () => {
  const binding=new HandConfiguration();
  const captured=[];
  binding.capture('left',true,()=>captured.push('preview-left'));
  binding.capture('right',true,()=>captured.push('preview-right'));
  binding.invalidate();
  binding.capture('left',false,()=>captured.push('stale-left'));
  binding.capture('right',true,()=>captured.push('live-right'));
  assert.equal(binding.ready('left'),false);
  assert.equal(binding.ready('right'),true);
  binding.capture('right',true,()=>captured.push('duplicate-right'));
  binding.capture('left',true,()=>captured.push('live-left'));
  assert.deepEqual(captured,['preview-left','preview-right','live-right','live-left']);
  binding.invalidate();
  assert.equal(binding.ready('left'),false);
  assert.equal(binding.ready('right'),false);
});
