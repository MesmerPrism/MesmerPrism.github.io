import test from 'node:test';
import assert from 'node:assert/strict';
import {readdirSync,readFileSync} from 'node:fs';
import {resolve,relative,join} from 'node:path';
const root=resolve(import.meta.dirname,'..');
function walk(directory) {
  return readdirSync(directory,{withFileTypes:true}).flatMap(entry=>entry.isDirectory()?walk(join(directory,entry.name)):[join(directory,entry.name)]);
}
test('public implementation excludes the disallowed phase machinery and local machine paths',()=>{
  const excluded=/movementCrossAxisCoupling|cross_axis_pull|crossAxisPull|cross_axis_coupling/;
  const machine=/(?<![a-z])[a-z]:[\\/]/i;
  for(const file of walk(join(root,'src'))) {
    const text=readFileSync(file,'utf8');
    assert.ok(!excluded.test(text),relative(root,file)+' contains excluded oscillator behavior');
    assert.ok(!machine.test(text),relative(root,file)+' contains a machine path');
  }
});
test('public assets contain only the enumerated runtime binaries and manifests',()=>{
  const base=join(root,'public/assets'),allowed=new Set();
  for(const side of ['left','right']) {
    const file='hands/'+side+'.manifest.json';
    allowed.add(file);
    const manifest=JSON.parse(readFileSync(join(base,file),'utf8'));
    for(const entry of Object.values(manifest.files))allowed.add('hands/'+entry.file);
  }
  allowed.add('particles/manifest.json');
  for(const entry of JSON.parse(readFileSync(join(base,'particles/manifest.json'),'utf8')).files)allowed.add('particles/'+entry.name);
  const actual=walk(base).map(file=>relative(base,file).replaceAll('\\','/'));
  assert.equal(actual.filter(name=>name.endsWith('.bin')).length,25);
  assert.deepEqual(new Set(actual),allowed);
});
